"""Local persistent logo cache, independent of Nebelflix widget snapshots."""
import hashlib
import json
import os
import time
from pathlib import Path
from urllib.parse import urlparse
from .common import DATA, canonical, download, load_json, save_json, log

LOGO_API = 'https://iptv-org.github.io/api/logos.json'
LOGODIR = DATA / 'logos'


def index(force=False):
    cache=load_json('logo-index.json', {})
    if not force and cache.get('expires',0) > time.time():
        return cache.get('items', {})
    if not force and cache.get('tried',0) > time.time()-3600:
        return cache.get('items', {})
    cache['tried'] = time.time()
    save_json('logo-index.json',cache)
    try:
        rows=json.loads(download(LOGO_API,18*1024*1024,timeout=16).decode('utf-8'))
        result={}
        for row in rows:
            if not isinstance(row,dict) or not row.get('in_use'):
                continue
            channel = str(row.get('channel') or '')
            if not channel.endswith('.de') or row.get('format','').upper() not in ('PNG','JPEG','WEBP'):
                continue
            url=str(row.get('url') or '')
            if not url.startswith('https://'):
                continue
            key=canonical(channel[:-3])
            if key and key not in result:
                result[key]=url
        save_json('logo-index.json',{'expires':time.time()+7*86400,'tried':time.time(),'items':result})
        return result
    except Exception as exc:
        log('Logo-Verzeichnis nicht erreichbar: %s' % exc)
        return cache.get('items', {})


def cached_url(url):
    if not url:
        return ''
    hash_=hashlib.sha256(url.encode('utf-8')).hexdigest()
    for ext in ('.png','.jpg','.webp'):
        path = LOGODIR / (hash_ + ext)
        if path.is_file() and path.stat().st_size > 100:
            return str(path)
    return ''


def logo_for(ch, program=None, lookup=None):
    program=program or {}
    overrides=load_json('logo-overrides.json',{})
    url=overrides.get(ch['id']) or ch.get('logo') or program.get('logo') or (lookup or {}).get(ch.get('normalized','')) or ''
    return cached_url(url) or url or ''


def cache_logo(url):
    if not url or cached_url(url):
        return False
    p=urlparse(url)
    if p.scheme!='https' or not p.hostname or p.hostname in ('localhost','127.0.0.1'):
        return False
    try:
        data=download(url, 1024*1024, timeout=10)
        if data.startswith(b'\x89PNG\r\n\x1a\n'):
            ext='.png'
        elif data.startswith(b'\xff\xd8\xff'):
            ext='.jpg'
        elif data.startswith(b'RIFF') and data[8:12]==b'WEBP':
            ext='.webp'
        else:
            return False
        LOGODIR.mkdir(parents=True,exist_ok=True)
        name=hashlib.sha256(url.encode('utf-8')).hexdigest()+ext
        path=LOGODIR/name
        tmp=LOGODIR/(name+'.tmp')
        with tmp.open('wb') as stream:
            stream.write(data)
        os.replace(str(tmp),str(path))
        return True
    except Exception:
        return False


def cache_batch(channels, limit=35):
    from . import epg
    lookup=index()
    total=0
    with epg.connect() as conn:
        idx=epg.guide_index(conn)
        attempted=0
        for channel in channels:
            match=epg.match_channel(channel,idx,conn)
            meta=next((match[s] for s,_,_ in epg.available() if s in match),None)
            url=channel.get('logo') or (meta[2] if meta else '') or lookup.get(channel['normalized'],'')
            if url and not cached_url(url):
                attempted += 1
                if cache_logo(url):
                    total += 1
            if total>=limit or attempted>=max(12,limit*2):
                break
    return total
