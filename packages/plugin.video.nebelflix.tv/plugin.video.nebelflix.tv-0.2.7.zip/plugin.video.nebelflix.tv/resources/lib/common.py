"""Shared paths, conservative persistence and name normalization (Kodi Omega)."""
import hashlib
import json
import os
import re
import time
import unicodedata
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.nebelflix.tv')
DATA = Path(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')))
DATA.mkdir(parents=True, exist_ok=True)
ASSETS = Path(ADDON.getAddonInfo('path'))

EPG_SOURCES = [
    ('free', 'FreeEPG Deutschland', 'https://free-epg.de/api/epg/de.xml.gz'),
    ('open', 'Open-EPG Deutschland', 'https://www.open-epg.com/files/germany.xml.gz'),
    ('share', 'EPGshare Deutschland', 'https://epgshare01.online/epgshare01/epg_ripper_DE1.xml.gz'),
]

DEFAULTS = {'sources': ['free', 'open', 'share'], 
            'sync_started': False, 'channel_refresh_hours': 6, 'epg_refresh_hours': 6}


def vavoo_epg_url():
    """Read Vavoo TV Plus' *live* XMLTV configuration; never modify it."""
    try:
        url = str(xbmcaddon.Addon('plugin.video.vavoo.tv.plus').getSetting('epg_url') or '').strip()
        parsed = urlparse(url)
        if parsed.scheme == 'https' and parsed.hostname and len(url) <= 2048:
            # Match Vavoo's selected URL against our sources below.
            return url
    except Exception:
        pass
    return ''


def epg_catalog():
    """Native feeds plus the configured Vavoo source when not already included."""
    result = list(EPG_SOURCES)
    vavoo = vavoo_epg_url()
    if vavoo and not any(vavoo.rstrip('/') == url.rstrip('/') for _,_,url in result):
        result.append(('vavoo', 'Vavoo TV Plus (eigene EPG-Quelle)', vavoo))
    return result


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[NebelflixTV] %s' % message, level)


def load_json(name, default=None):
    try:
        with (DATA / name).open('r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError, TypeError):
        return {} if default is None else default


def save_json(name, obj):
    target = DATA / name
    tmp = DATA / (name + '.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, separators=(',', ':'))
    os.replace(str(tmp), str(target))


def settings():
    data = load_json('config.json', {})
    if not isinstance(data, dict):
        data = {}
    # One-time non-destructive upgrade: opt in to an additional XMLTV feed
    # explicitly configured by the installed Vavoo TV Plus add-on. If both
    # use the same URL, existing source already covers it.
    available = epg_catalog()
    vavoo_present = any(k == 'vavoo' for k,_,_ in available)
    if vavoo_present and not data.get('vavoo_epg_initialized', False):
        data['sources'] = list(dict.fromkeys(list(data.get('sources', DEFAULTS['sources'])) + ['vavoo']))
        data['vavoo_epg_initialized'] = True
        save_json('config.json', data)
    return dict(DEFAULTS, **data)


def change_settings(**kwargs):
    data = settings()
    data.update(kwargs)
    save_json('config.json', data)


def clean(value):
    return re.sub(r'\s+', ' ', re.sub(r'\[/?(?:COLOR|B|I)[^]]*\]', '',
           str(value or ''), flags=re.I)).strip()


def canonical(value):
    """Normalize provider names for EPG only; never change playback URLs.

    Vavoo sometimes appends source identifiers e.g. 'ProSieben HD (6)'.
    Those describe stream variants, not different TV channels.
    """
    s = clean(value).casefold()
    s = s.replace('ä', 'ae').replace('ö', 'oe').replace('ü', 'ue').replace('ß', 'ss')
    s = unicodedata.normalize('NFKD', s)
    s = ''.join(x for x in s if not unicodedata.combining(x))
    # Remove ONLY terminal bracketed provider-source variants. Internal numerals
    # are essential: 3sat, RTL 2, SAT.1, 1-2-3.TV must never be stripped.
    s = re.sub(r'(?:\s*[\(\[]\s*(?:stream\s*)?\d{1,3}\s*[\)\]])+\s*$', '', s)
    s = re.sub(r'(?<![a-z0-9])(?:hd|sd|fhd|uhd)\s*\+?(?![a-z0-9])', ' ', s)
    s = re.sub(r'\b(?:germany|deutschland|de|ger|4k|1080p|720p|backup|alternative|alt|stream\s*\d+)\b', ' ', s)
    s = s.replace('&', 'und').replace('+', 'plus')
    s = re.sub(r'^[\s|\-:.]+|[\s|\-:.]+$', '', s)
    s = re.sub(r'[^a-z0-9]+', '', s)
    aliases = {'arddaserste': 'daserste', 'ard1': 'daserste', 'ard': 'daserste',
               'dasersteard': 'daserste', 'rtl2': 'rtlzwei', 'rtlzwei': 'rtlzwei',
               'pro7': 'prosieben', 'prosieben': 'prosieben', 'pro7maxx': 'prosiebenmaxx',
               'kabel1': 'kabeleins', 'kabel1doku': 'kabeleinsdoku',
               'kabeleinsdoku': 'kabeleinsdoku', 'sat1': 'sat1',
               'ntv': 'ntv', 'n24': 'welt'}
    return aliases.get(s, s)


def short_id(s):
    return hashlib.sha1(str(s).encode('utf-8')).hexdigest()[:16]


def download(url, max_bytes=28*1024*1024, timeout=14):
    parsed = urlparse(url)
    if parsed.scheme != 'https' or not parsed.hostname:
        raise ValueError('Nur HTTPS-Quellen sind zugelassen')
    req = Request(url, headers={'User-Agent': 'NebelflixTV/0.1 Kodi', 'Accept-Encoding': 'identity'})
    with urlopen(req, timeout=timeout) as resp:
        if urlparse(resp.geturl()).scheme != 'https':
            raise ValueError('Unsichere Weiterleitung')
        data = bytearray()
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            data.extend(chunk)
            if len(data) > max_bytes:
                raise ValueError('Quelle zu gross')
    return bytes(data)


def rpc(method, params):
    raw = xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1,
                                           'method': method, 'params': params}))
    res = json.loads(raw)
    if res.get('error'):
        raise RuntimeError('%s: %s' % (method, res['error']))
    return res.get('result') or {}


def friendly_time(ts):
    return time.strftime('%H:%M', time.localtime(ts))


def notify(msg, icon='info'):
    import xbmcgui
    flag = {'info': xbmcgui.NOTIFICATION_INFO,
            'warning': xbmcgui.NOTIFICATION_WARNING,
            'error': xbmcgui.NOTIFICATION_ERROR}.get(icon, xbmcgui.NOTIFICATION_INFO)
    xbmcgui.Dialog().notification('Nebelflix TV', str(msg), flag, 4000)
