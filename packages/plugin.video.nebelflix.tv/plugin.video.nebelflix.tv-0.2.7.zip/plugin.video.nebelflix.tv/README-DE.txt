NEBELFLIX TV 0.1.7 – VAVOO-ONLY

- Sender, Sendergruppen und Abspielwege aus installiertem Vavoo TV Plus 2.0.8 oder neuer.
- Keine MovieScout-Live-TV-Abfragen und kein Import fremder M3U-Senderlisten.
- Eigener Guide mit zusammengeführten XMLTV-Daten einschließlich Vavoo EPG.
- EPG-Speicher, Senderfavoriten, Logos und manuelle Zuordnungen bleiben
  im Profil von Nebelflix TV erhalten.
- Die Kacheln 'Alle deutschen Sender' und 'Favoriten' sind aus der
  Sendergruppenauswahl entfernt. Die Favoritenfunktion im Kontextmenü bleibt.
- Die importierten Senderlisten, Einstellungen und Fav-Gruppen in Vavoo TV Plus
  werden ausschließlich gelesen, niemals überschrieben.
- Alte gemischte Sender-Caches werden nicht mehr für die Wiedergabe genutzt.
- Skin-Update 0.5.67 nötig für die neue, reine Vavoo-Sendergruppen-Ansicht.
