"""UI for source selection and channel/EPG/bitmap caches."""
import time
import xbmc
import xbmcgui
from . import channels, epg, art
from .common import epg_catalog, vavoo_epg_url, load_json, save_json, settings, change_settings, notify, friendly_time, DATA


def _dialog():
    return xbmcgui.Dialog()


def _sources():
    dialog=_dialog()
    while True:
        conf=settings()
        selected=set(conf['sources'])
        choices=[('[ON] ' if k in selected else '[OFF] ')+label for k,label,_ in epg_catalog()]
        idx=dialog.select('EPG-Quellen kombinieren (inkl. Vavoo, falls eingestellt)',
                          choices+['Zurück'])
        if idx<0 or idx>=len(epg_catalog()):
            return
        key=epg_catalog()[idx][0]
        if key in selected and len(selected)==1:
            dialog.ok('Nebelflix TV','Mindestens eine EPG-Quelle muss aktiv bleiben.')
            continue
        selected.remove(key) if key in selected else selected.add(key)
        change_settings(sources=[k for k,_,_ in epg_catalog() if k in selected])


def _coverage():
    dialog=_dialog()
    items=channels.channel_list()
    stats=epg.coverage(items)
    missing=sorted(set(stats['missing']))
    text='%d von %d Sendereinträgen eindeutig zugeordnet.\n\nFehlende Zuordnungen (%d):\n%s' % (
      stats['matched'],stats['total'],len(missing),'\n'.join(missing[:120]))
    if len(missing)>120:
        text+='\n... weitere Sender im nächsten Abgleich'
    dialog.textviewer('EPG-Abdeckungsbericht',text)
    save_json('epg-report.json',{'at':time.time(),'total':stats['total'],
                                  'matched':stats['matched'],'missing':missing})


def _manual_epg():
    dialog=_dialog()
    items=channels.channel_list()
    if not items:
        dialog.ok('Nebelflix TV','Keine Sender verfügbar')
        return
    target=dialog.input('Sendername für EPG-Zuordnung suchen',type=xbmcgui.INPUT_ALPHANUM)
    if not target:
        return
    from .common import canonical
    filtered=[x for x in items if canonical(target) in x['normalized']]
    if not filtered:
        dialog.ok('Kein Treffer','Sendername nicht gefunden')
        return
    selected=dialog.select('Welcher Sender?', [x['name'] for x in filtered[:100]])
    if selected<0:
        return
    ch=filtered[selected]
    with epg.connect() as conn:
        guide=list(conn.execute('SELECT source,cid,name FROM guides ORDER BY name'))
    keyword=dialog.input('EPG-Sendername suchen',type=xbmcgui.INPUT_ALPHANUM)
    if not keyword:
        return
    guide=[x for x in guide if canonical(keyword) in canonical(x[2])]
    if not guide:
        dialog.ok('Keine Zuordnung','Dieser Sender existiert in keiner geladenen EPG-Quelle.')
        return
    i=dialog.select('EPG für '+ch['name'],['%s | %s' % (src,name) for src,cid,name in guide[:200]])
    if i>=0:
        src,cid,_=guide[i]
        overrides=load_json('epg-overrides.json',{})
        overrides[ch['id']]={'source':src,'cid':cid}
        save_json('epg-overrides.json',overrides)
        dialog.ok('Zuordnung gespeichert','Die neue EPG-Zuordnung gilt sofort. Deine Senderliste bleibt unverändert.')


def manage():
    dialog=_dialog()
    while True:
        choices=[
            'EPG-Quellen verwalten (inkl. Vavoo)',
            'Vavoo-TV-Plus-Senderliste neu einlesen',
            'Alle aktivierten EPG-Quellen aktualisieren',
            'EPG-Abdeckung / fehlende Sender anzeigen',
            'EPG manuell einem Sender zuordnen',
            'Senderlogos ergänzen und lokal speichern',
            'Aktualisierungsstatus anzeigen',
        ]
        selected=dialog.select('Nebelflix TV · Verwaltung',choices)
        if selected<0:
            return
        if selected==0:
            _sources()
        elif selected==1:
            with _progress('Sender werden aus Vavoo TV Plus aktualisiert'):
                cs=channels.channel_list(force=True)
            info=load_json('channels.json',{}).get('report',{})
            dialog.ok('Senderabgleich', '%d Sender gespeichert\nNeu: %d · Entfernt: %d · Geändert: %d' % (
                len(cs),info.get('added',0),info.get('removed',0),info.get('updated',0)))
        elif selected==2:
            if not dialog.yesno('EPG aktualisieren','Die aktivierten EPG-Dateien sind teilweise groß. '
                 'Das Laden kann länger dauern und verbraucht Internetdaten. Jetzt starten?'):
                continue
            with _progress('EPG-Daten aus mehreren Quellen laden'):
                ok,err=epg.refresh_due(limit=0,force=True,target_channels=channels.channel_list())
            dialog.textviewer('EPG-Abgleich', '\n'.join('%s: %d Sendungen' % x for x in ok) +
                ('\n\nFehler:\n'+'\n'.join(err) if err else ''))
        elif selected==3:
            _coverage()
        elif selected==4:
            _manual_epg()
        elif selected==5:
            if not dialog.yesno('Senderlogos speichern','Senderlogos und Logo-Verzeichnis herunterladen? '
                'Dies kann je nach System länger dauern.'):
                continue
            with _progress('Senderlogos werden geladen'):
                n=art.cache_batch(channels.channel_list(),limit=100)
            dialog.ok('Logo-Cache','%d zusätzliche Logos gespeichert. Bereits vorhandene bleiben erhalten.' % n)
        elif selected==6:
            status=epg.source_status()
            report=load_json('channels.json',{}).get('report',{})
            lines=['Sender: %s' % report.get('total',0),
                   'Letzter Senderabgleich: %s' % (time.strftime('%d.%m.%Y %H:%M', time.localtime(report.get('at',0))) if report.get('at') else 'Noch keiner'), '',
                   'Aktive EPG-Quellen:']
            for sid,title,url in epg.available():
                entry=status.get(sid,{})
                lines.append('%s: %s · %d Sendungen' % (title,
                    time.strftime('%d.%m.%Y %H:%M',time.localtime(entry['last_success'])) if entry.get('last_success') else 'Noch nicht geladen',
                    entry.get('shows',0)))
            vurl=vavoo_epg_url()
            if vurl:
                duplicate=next((title for sid,title,url in epg_catalog()
                                if sid!='vavoo' and url.rstrip('/')==vurl.rstrip('/')),None)
                lines+=['', 'Vavoo-TV-Plus-EPG: '+('Bereits über '+duplicate+' eingebunden' if duplicate
                                   else ('Zusätzliche Quelle '+('aktiv' if 'vavoo' in settings().get('sources',[]) else 'deaktiviert')))]
            else:
                lines+=['', 'Vavoo-TV-Plus-EPG: Nicht konfiguriert / nicht installiert']
            lines+=['','Gespeichert in: '+str(DATA),'Widget-Cache-Reset im Skin löscht diese Daten nicht.']
            dialog.textviewer('Nebelflix TV – Speicherstatus','\n'.join(lines))


class _progress:
    def __init__(self,msg):
        self.msg=msg
        self.dp=None
    def __enter__(self):
        self.dp=xbmcgui.DialogProgressBG()
        self.dp.create('Nebelflix TV',self.msg)
        self.dp.update(10,'Nebelflix TV',self.msg)
        return self
    def __exit__(self,*args):
        self.dp.update(100,'Nebelflix TV','Verarbeitung abgeschlossen')
        self.dp.close()
