"""One station, many provider streams, with conservative startup-only fallback.

Never modify Vavoo TV Plus or transform its plugin URLs. A Kodi VideoPlayer
opening is a heuristic, not proof of end-to-end stream quality. This module
only fails over if playback fails during the initial verification period.
"""
import time
import xbmc
import xbmcgui
from . import channels
from .common import load_json,save_json,log,notify

KEYS=('Channel','Id','Pending','Active','PlayingFile','Now','Next','Plot','Logo','Poster','StartedAt','Direct')


def home():
    return xbmcgui.Window(10000)


def clear():
    win=home()
    for key in KEYS:
        win.clearProperty('NFTV.'+key)


def _url_set(ch):
    return [v for v in ch.get('variants',[]) if v.get('url','').startswith(('plugin://','https://','http://'))]


def play_station(station_id):
    ch=channels.find_channel(station_id)
    if ch is None:
        notify('Sender nicht mehr verfügbar', 'warning')
        return False
    # A Kodi/Timeshift re-invocation shortly after manual Stop is not a new
    # click. Suppress it so a single-source channel cannot enter a restart loop.
    guard = home().getProperty('NFTV.StopGuard').split('|')
    if len(guard)==2 and guard[0]==ch['id']:
        try: blocked = float(guard[1]) > time.time()
        except (TypeError,ValueError): blocked = False
        if blocked:
            log('%s: stopped by user; ignoring automatic replay' % ch['name'])
            return False
    attempts=_url_set(ch)
    if not attempts:
        notify('Für diesen Sender ist keine Quelle hinterlegt', 'warning')
        return False
    monitor=xbmc.Monitor()
    win=home()
    win.clearProperty('NFTV.UserStop')
    clear()
    win.setProperty('NFTV.Channel',ch['name'])
    win.setProperty('NFTV.Id',ch['id'])
    win.setProperty('NFTV.Pending','1')
    # Publish the EPG snapshot before the provider starts Kodi's player.
    # Otherwise VideoInfo can open while the service is still waiting for a
    # stream and show an empty generic video info panel.
    try:
        from . import epg,art
        from .common import friendly_time,ASSETS
        with epg.connect() as c:
            info=epg.programme(ch,conn=c,index=epg.guide_index(c))
        active,following=info.get('now'),info.get('next')
        nowtxt=('%s–%s · %s'%(friendly_time(active[0]),friendly_time(active[1]),active[2])) if active else 'Keine aktuelle Sendung im EPG'
        nexttxt=('%s–%s · %s'%(friendly_time(following[0]),friendly_time(following[1]),following[2])) if following else ''
        win.setProperty('NFTV.Now',nowtxt)
        win.setProperty('NFTV.Next',nexttxt)
        win.setProperty('NFTV.Plot','Jetzt: '+nowtxt+('[CR]Danach: '+nexttxt if nexttxt else ''))
        logo=art.logo_for(ch,info) or str(ASSETS/'icon.png')
        poster=info.get('programme_art','')
        win.setProperty('NFTV.Logo',logo)
        win.setProperty('NFTV.Poster',poster or logo)
    except Exception as exc:
        log('EPG initialisieren: %s'%exc,xbmc.LOGWARNING)
        win.setProperty('NFTV.Now','EPG wird geladen')
        win.setProperty('NFTV.Plot','Jetzt: EPG wird geladen')
    progress=xbmcgui.DialogProgressBG()
    progress.create('Nebelflix TV','Verbinde mit '+ch['name'])
    try:
        try:
            xbmc.Player().stop()  # prevent accidentally accepting the prior channel
        except Exception:
            pass
        for number,var in enumerate(attempts,1):
            if win.getProperty('NFTV.UserStop')=='1':
                log('%s: stop requested, no further source attempts' % ch['name'])
                return False
            if monitor.abortRequested():
                break
            progress.update(int(100*(number-1)/len(attempts)),
                            'Nebelflix TV', '%s · Quelle %d von %d' %(ch['name'],number,len(attempts)))
            try:
                url=var['url']
                # URL comes directly from Vavoo TV Plus and is not rewritten.
                xbmc.executebuiltin('PlayMedia(%s)' % url)
                deadline=time.monotonic()+15
                while time.monotonic()<deadline and not monitor.abortRequested():
                    if win.getProperty('NFTV.UserStop')=='1':
                        return False
                    if xbmc.Player().isPlayingVideo():
                        # Reject videos that open and immediately terminate.
                        start=time.monotonic()
                        while (time.monotonic()-start<3.5 and xbmc.Player().isPlayingVideo()
                               and not monitor.abortRequested()
                               and win.getProperty('NFTV.UserStop')!='1'):
                            xbmc.sleep(500)
                        if (xbmc.Player().isPlayingVideo() and not monitor.abortRequested()
                                and win.getProperty('NFTV.UserStop')!='1'):
                            try: playing=xbmc.Player().getPlayingFile()
                            except Exception: playing=''
                            win.setProperty('NFTV.PlayingFile',playing)
                            win.setProperty('NFTV.StartedAt',str(time.time()))
                            win.setProperty('NFTV.Active','1')
                            win.clearProperty('NFTV.Pending')
                            choices=load_json('stream-preferences.json',{})
                            choices[ch['normalized']]=url
                            save_json('stream-preferences.json',choices)
                            log('%s: Stream %d/%d started (%s)' % (ch['name'],number,len(attempts),var.get('source','')))
                            try:
                                channels.remember_station(ch)
                            except Exception as exc:
                                log('Zuletzt gesehen nicht gespeichert: %s' % exc, xbmc.LOGWARNING)
                            return True
                        break
                    xbmc.sleep(500)
                if win.getProperty('NFTV.UserStop')=='1':
                    return False
                try:xbmc.Player().stop()
                except Exception:pass
                xbmc.sleep(350)
            except Exception as exc:
                log('Quelle %d/%d von %s fehlgeschlagen: %s' % (number,len(attempts),ch['name'],exc),xbmc.LOGWARNING)
        clear()
        xbmcgui.Dialog().ok('Nebelflix TV', 'Aktuell kein Sender verfügbar.\nFür %s konnte keine der %d Quellen gestartet werden.'%(ch['name'],len(attempts)))
        return False
    finally:
        progress.close()
        # Keep the selected station for the service only on verified success.
        if win.getProperty('NFTV.Active')!='1':
            clear()
