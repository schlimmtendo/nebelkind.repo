"""Kodi folder UI for groups, channels and channel-specific schedule."""
import sys
import time
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin
from . import channels, epg, art
from .common import ASSETS, canonical, friendly_time, notify

ROOT='plugin://plugin.video.nebelflix.tv/'
ICON=str(ASSETS / 'icon.png')
CHANNEL_ICON=str(ASSETS / 'resources/media/channel-placeholder.png')
FANART=str(ASSETS / 'fanart.jpg')
CATEGORY_ASSETS=ASSETS / 'resources' / 'media' / 'categories'

def category_icon(slug):
    art=CATEGORY_ASSETS / (slug+'.png')
    return str(art) if art.is_file() else ICON



def url(action, **params):
    return ROOT+'?'+urlencode(dict(action=action,**params))


def item(label, path, folder, plot='', logo=None, playable=False, context=None):
    li=xbmcgui.ListItem(label=str(label))
    li.setArt({'thumb':logo or ICON,'icon':logo or ICON,'fanart':FANART})
    try:
        tag=li.getVideoInfoTag()
        tag.setTitle(str(label));tag.setPlot(str(plot))
    except (AttributeError,TypeError):
        li.setInfo('video',{'title':str(label),'plot':str(plot)})
    if playable:
        li.setProperty('IsPlayable','true')
        li.setContentLookup(False)
    if context:
        li.addContextMenuItems(context)
    return path,li,folder


def _finish(handle, entries, content='files'):
    xbmcplugin.addDirectoryItems(handle,entries,len(entries))
    xbmcplugin.setContent(handle,content)
    xbmcplugin.endOfDirectory(handle,cacheToDisc=False)


def root(handle):
    n=len(channels.group_catalog())
    entries=[
      item('📺 Programmführer · Jetzt und nächste Sendungen',url('guide'),True,
           'Eigener Nebelflix-TV-Guide mit Sendergruppen und Zeitachse',logo=category_icon('guide')),
      item('🕘 Zuletzt gesehen (TV)',url('list',group='recent'),True,logo=category_icon('all')),
      item('📂 Vavoo-Sendergruppen (%d)' % n,url('groups'),True,logo=category_icon('all')),
      item('🔎 Sender suchen',url('search'),True),
      item('⚙️ TV & EPG verwalten',url('manage'),True),
    ]
    _finish(handle,entries)


def groups(handle):
    entries=[item('🕘 Zuletzt gesehen (TV)',url('list',group='recent'),True,logo=category_icon('all'))]
    for slug,name in channels.group_catalog():
        count = len(channels.list_group(slug))
        entries.append(item('%s  (%d)' % (name,count),url('list',group=slug),True,logo=category_icon(slug)))
    _finish(handle,entries)


def list_channels(handle, group='all', search=''):
    entries=[]
    fav=channels.favorites()
    has_epg=bool(epg.source_status())
    with epg.connect() as c:
        index=epg.guide_index(c)
        # Avoid a huge UI rebuild; large groups are split into 80-channel pages.
        items=channels.list_group(group,search)
        for ch in items[:2500]:
            info=epg.programme(ch,conn=c,index=index)
            now=info['now']; next_=info['next']
            nowstr=('Jetzt: '+now[2]+' (bis '+friendly_time(now[1])+')') if now else ('Kein EPG verfügbar' if has_epg else 'EPG-Daten werden vorbereitet')
            nextstr=(' · Danach: '+next_[2]) if next_ else ''
            label=('[COLOR gold]★[/COLOR] ' if ch['id'] in fav else '')+ch['name']
            icon=art.logo_for(ch,info)
            path=url('play',id=ch['id'])
            toggle=url('favorite',id=ch['id'],back=group)
            schedule=url('schedule',id=ch['id'])
            context=[('EPG für diesen Sender', 'Container.Update(%s)' % schedule),
                     ('Aus Favoriten entfernen' if ch['id'] in fav else 'Zu Favoriten hinzufügen',
                      'RunPlugin(%s)' % toggle)]
            entries.append(item(label,path,True,nowstr+nextstr,icon or CHANNEL_ICON,False,context))
    if not entries:
        entries=[item('Noch kein TV-Sender angesehen' if group == 'recent' else 'Noch keine Sender verfügbar',url('root') if group == 'recent' else url('manage'),True,
                    'Vavoo TV Plus öffnen und Senderliste aktualisieren')]
    _finish(handle,entries)


def schedule(handle, ch):
    channel=channels.find_channel(ch)
    if not channel:
        _finish(handle,[]);return
    source,events=epg.schedule(channel)
    entries=[item('[B]▶ Sender ansehen: %s[/B]' % channel['name'],url('play',id=channel['id']),True,
                 'Wiedergabe über '+channel['source'],channel.get('logo') or CHANNEL_ICON,True)]
    for start,end,title,desc in events:
        entries.append(item('%s–%s  %s' % (friendly_time(start),friendly_time(end),title),
                            url('play',id=channel['id']),True,desc,channel.get('logo') or CHANNEL_ICON,False))
    if not events:
        entries.append(item('Noch keine Programmdaten zugeordnet',url('manage'),True))
    _finish(handle,entries)


def guide():
    from .guide import open_guide
    open_guide()


def search(handle):
    q=xbmcgui.Dialog().input('Deutschen Sender suchen', type=xbmcgui.INPUT_ALPHANUM)
    list_channels(handle,search=q) if q.strip() else _finish(handle,[])
