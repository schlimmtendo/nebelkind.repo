xShip Hybrid + MovieScout | Auto Quality / Auto Update Test 2026-11-07
=====================================================================

- Base: working xShip Hybrid + MovieScout Beta; unchanged xShip player.
- In Settings -> MovieScout: All compatible Scout modules enabled by default,
  including LG1 modules; remote scraper updater enabled by default.
- On Kodi launch a background job checks the pinned GitHub URL and uses HTTPS,
  conditional GET where possible, syntax check and atomic file replacement.
  Prior cached modules remain available if a refresh fails.
- No MovieScout update notifications/dialogs. One Kodi info log line only after
  every manifest scraper is present: [xShip Hybrid] Alle Module geladen.
  Incomplete totals go into plugin.video.xship/movie_scout/state.json.
- Auto-play quality choices: best quality (4K>1440>1080>720>SD), low bandwidth,
  original scrape order, or 1080p preference (MovieScout-inspired).
- Auto-play search and probe run with background progress UI; dialog playback
  retains the xShip stream selection as before.
- Quality labels are scraper estimates unless actually probed; selecting 4K
  cannot guarantee a playable 4K rendition. Failed resolver links are skipped.
- Not every downloaded module implements get_hosters(). Browse-only modules,
  special MovieScout engines, DRM, Debrid, and unsupported APIs remain separate.
- External Python modules can execute arbitrary code and have Kodi user access;
  neither Python syntax validation nor HTTPS signatures make them trustworthy.
  Automatic updates should only be used with a trusted repository. To turn
  off auto update, disable it in the settings; cached modules remain.
- Original xShip BurningSeries Captcha settings and stream header/player
  handling remain unchanged. The same addon ID replaces previous xShip build.
- This is a static/simulated test build. Real MovieScout modules and external
  streams have NOT been fully tested on Kodi.

Network-compatibility adjustment (2026-11-07):
- MovieScout get_hosters() now checks the same maximum of three title variants
  as MovieScout's original _query_scraper() and uses its host-level duplicate key.
- Do not rewrite arbitrary 'plugin.video.moviescout' literals inside downloaded
  Python source: these may be used as headers, URL parameters or request bodies.
  Only local profile paths, imports and explicit xbmcaddon lookup calls are adapted.
- GitHub updater uses MovieScout's existing default User-Agent for module GETs;
  source/hoster requests still use their respective original network clients.
- This aligns application-level requests; it does NOT make server-side
  identification impossible. Public IP, cookies, TLS and server telemetry remain.
