xShip Hybrid – TESTVERSION 2026.11.06

Basis: xShip Original 2026.08.21 (aktuellere Codebasis als MOD 2026.01.11).
Originale Quellenauswahl mit technischen Metadaten (Aufloesung / Bitrate).
Originaler Player und ResolveURL-Ablauf. MOD-Serien-Defer-Resolver mit harten
8s/2.25s Grenzen NICHT uebernommen (Fehlerquelle bei 403 / Redirects).

Uebernommen / ergaenzt:
- Individuelle Standard-Aktion fuer Filme und Serien, optional.
- HTML-Cache leeren ueber Werkzeuge.
- Zwei experimentelle MOD-Provider: filmpro und streamcloud (default AUS).
- Dynamischer Domain-Check anhand von HTTP-Redirects; Domain wird nur als
  Kodi Setting gespeichert. Kein riskantes Schreiben in die Addon-PY Dateien.
- Ein kurzfristiger Cloudflare/DNS-Fehler schaltet Provider nicht dauerhaft ab.
- Zwei optionale Geschwindigkeits-Modi fuer Suchzeit / Video-MediaInfo.
- Meta-Info Probe hat 9 Sekunden Budget; alle urspruenglichen Hoster bleiben
  in der Liste selbst dann, wenn die Probe scheitert oder abgebrochen wird.

NICHT portiert: MOD-HLS-Fake-FireTV-Headers, Kodi-HTTP-Proxy, MOD-Defer-Resolver,
Downloader, JDownloader, MOD-Paging-Caches und defekter MOD-Aniworld-Provider.

Hinweise:
- Bisherige Addon-ID bleibt plugin.video.xship. Ein Backup bestehender
  Addon-Version und Kodi-Settings ist vor der Installation sinnvoll.
- Keine Laufzeittests gegen Kodi-Server/Hoster durchgefuehrt.
- Manche Anbieter benoetigen eine gueltige Sitzung oder Lizenz;
  HTTP 403 wird nicht durch Domain-Wechsel automatisch behoben.
- Ein Domain-Check erkennt nur gueltige Redirect-Ziele, keine
  vollstaendig geaenderten HTML-Layouts oder neuen API-Endpunkte.
- Bei Bedarf Wiedergabe > Stream-Metadaten auf Schnell einstellen.
- Dateien unter GPLv3 aus dem Ursprungspaket, Lizenz beibehalten.
