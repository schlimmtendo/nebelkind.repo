"""Unified, Kodi-native title search for Nebelflix Hybrid.

Searches only catalogue metadata; streaming sources are resolved by the existing
Hybrid player after a title/episode is selected. No extra scraper code is run.
"""
import sys
from itertools import zip_longest
from urllib.parse import urlencode
import xbmcgui
import xbmcplugin


def _item(data, media):
    title = str(data.get('title') or '')
    if not title or not str(data.get('tmdb_id') or '').isdigit():
        return None
    label = ('[COLOR FFDF334A]Film[/COLOR]  ' if media == 'movie'
             else '[COLOR FF73B5FF]Serie[/COLOR]  ') + title
    item = xbmcgui.ListItem(label=label, offscreen=True)
    tag = item.getVideoInfoTag()
    tag.setTitle(title)
    tag.setPlot(data.get('plot') or '')
    tag.setMediaType('movie' if media == 'movie' else 'tvshow')
    tag.setUniqueIDs({'tmdb': str(data['tmdb_id'])}, 'tmdb')
    try:
        year = int(data.get('year') or 0)
        if year > 0:
            tag.setYear(year)
    except (ValueError, TypeError):
        pass
    try:
        tag.setRating(float(data.get('rating') or 0))
    except (ValueError, TypeError):
        pass
    poster = data.get('poster') or ''
    fanart = data.get('fanart') or ''
    item.setArt({'poster': poster, 'thumb': poster, 'icon': poster,
                 'fanart': fanart or poster})
    item.setProperty('tmdb_id', str(data['tmdb_id']))
    item.setProperty('tmdb_type', media)
    item.setProperty('IsPlayable', 'true' if media == 'movie' else 'false')
    link = sys.argv[0] + '?' + urlencode({
        'info': 'play' if media == 'movie' else 'seasons',
        'tmdb_type': media, 'tmdb_id': data['tmdb_id']})
    return (link, item, media == 'tv')


def search(params):
    from resources.lib.tmdb import cTMDB
    query = str(params.get('query') or '').strip()
    media = params.get('media_type') or 'both'
    if media not in ('movie', 'tv', 'both'):
        media = 'both'
    if not query:
        keyboard = xbmcgui.Dialog().input('Nebelflix Hybrid – Suche')
        query = str(keyboard or '').strip()
    if not query:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    try:
        page = max(1, min(int(params.get('page') or 1), 100))
    except (TypeError, ValueError):
        page = 1
    api = cTMDB()
    film = api.search_term_full('movie', query, page) if media in ('movie','both') else ([], 0)
    tv = api.search_term_full('tvshow', query, page) if media in ('tv','both') else ([], 0)
    film_items, film_pages = film or ([], 0)
    tv_items, tv_pages = tv or ([], 0)
    candidates = []
    if media == 'both':
        for a,b in zip_longest(film_items, tv_items):
            if a is not None: candidates.append((a,'movie'))
            if b is not None: candidates.append((b,'tv'))
    else:
        candidates = [(entry,media) for entry in (film_items if media == 'movie' else tv_items)]
    rows = []
    for result, kind in candidates:
        built = _item(result,kind)
        if built: rows.append(built)
    if page < max(int(film_pages or 0), int(tv_pages or 0)):
        next_path = sys.argv[0]+'?'+urlencode({
            'info':'search', 'tmdb_type':media, 'query':query, 'page':page+1})
        rows.append((next_path, xbmcgui.ListItem(label='Nächste Seite'), True))
    handle = int(sys.argv[1])
    xbmcplugin.setContent(handle, {'movie':'movies','tv':'tvshows','both':'videos'}[media])
    xbmcplugin.addDirectoryItems(handle, rows, len(rows))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
