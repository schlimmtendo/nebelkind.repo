# -*- coding: utf-8 -*-
"""Nebelkind update notices, executed once at Kodi startup by Hybrid's existing service.

Does not download, install, restart or forcibly upgrade Kodi add-ons. Kodi keeps
ownership of installation and its per-device update preferences. No polling loop.
"""
import json
import os
import re
import time
from urllib.request import Request, urlopen

MANIFEST_URL = (
    'https://raw.githubusercontent.com/schlimmtendo/nebelkind.repo/'
    'main/packages/release.json'
)
ADDON_IDS = (
    'skin.nebelflix',
    'plugin.video.nebelflix.hybrid',
    'plugin.video.nebelflix.tv',
    'plugin.video.nebelkindmusic',
)
CHECK_INTERVAL_SECONDS = 6 * 3600
HTTP_TIMEOUT_SECONDS = 1.8


def _vkey(version):
    # Matches common numeric Kodi add-on version components; suffixes compare
    # below the next numeric component, and are not used for release candidates.
    result = []
    for part in re.split(r'[._-]', str(version)):
        if not part:
            continue
        result.append((1, int(part)) if part.isdigit() else (0, part.lower()))
    return tuple(result)


def _read_state(path):
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            obj = json.load(handle)
            return obj if isinstance(obj, dict) else {}
    except (IOError, ValueError, TypeError):
        return {}


def _save_state(path, state):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    temp = path + '.tmp'
    with open(temp, 'w', encoding='utf-8') as handle:
        json.dump(state, handle, ensure_ascii=False, sort_keys=True)
    os.replace(temp, path)


def _remote_versions():
    req = Request(MANIFEST_URL, headers={
        'User-Agent': 'NebelkindKodi/1.0',
        'Cache-Control': 'no-cache',
    })
    with urlopen(req, timeout=HTTP_TIMEOUT_SECONDS) as response:
        data = response.read(131073)
    if len(data) > 131072:
        raise ValueError('Manifest too large')
    obj = json.loads(data.decode('utf-8'))
    if not isinstance(obj, dict) or obj.get('schema') != 1:
        raise ValueError('Invalid update manifest')
    found = {}
    for item in obj.get('addons', []):
        if not isinstance(item, dict):
            continue
        addon_id = item.get('id')
        version = item.get('version')
        if addon_id in ADDON_IDS and isinstance(version, str):
            if re.fullmatch(r'[A-Za-z0-9._+-]{1,48}', version):
                found[addon_id] = version
    return found


def run_startup_check():
    try:
        import xbmc
        import xbmcaddon
        import xbmcgui
        import xbmcvfs

        active = {}
        for addon_id in ADDON_IDS:
            try:
                addon = xbmcaddon.Addon(id=addon_id)
                active[addon_id] = addon.getAddonInfo('version')
            except Exception:
                pass
        if not active:
            return
        local = xbmcaddon.Addon(id='plugin.video.nebelflix.hybrid')
        profile = xbmcvfs.translatePath(local.getAddonInfo('profile'))
        state_path = os.path.join(profile, 'nebelkind_update_status.json')
        state = _read_state(state_path)
        previous = state.get('installed', {})
        if not isinstance(previous, dict):
            previous = {}
        # First execution creates a baseline, no fake "completed" toast.
        completed = [addon_id for addon_id, ver in active.items()
                     if addon_id in previous and _vkey(ver) > _vkey(previous[addon_id])]
        state['installed'] = active
        if completed:
            if len(completed) == 1:
                label = completed[0].replace('plugin.video.', '').replace('skin.', '')
                message = 'Update installiert: ' + label
            else:
                message = str(len(completed)) + ' Nebelkind-Addons aktualisiert'
            xbmcgui.Dialog().notification('Nebelkind · Update abgeschlossen', message,
                                          xbmcgui.NOTIFICATION_INFO, 7000, False)
        now = int(time.time())
        if now - int(state.get('last_check', 0) or 0) >= CHECK_INTERVAL_SECONDS:
            try:
                published = _remote_versions()
                state['last_check'] = now
                pending = {addon_id: ver for addon_id, ver in published.items()
                           if addon_id in active and _vkey(ver) > _vkey(active[addon_id])}
                # A same-version test ZIP must never cause a false update alert.
                signature = ';'.join('%s:%s' % item for item in sorted(pending.items()))
                if pending and signature != state.get('last_announced', ''):
                    msg = ('Update verfügbar: ' + next(iter(pending)).replace('plugin.video.', '').replace('skin.', '')
                           if len(pending) == 1 else str(len(pending)) + ' Nebelkind-Updates verfügbar')
                    xbmcgui.Dialog().notification('Nebelkind · System-Update', msg,
                                                  xbmcgui.NOTIFICATION_INFO, 8500, False)
                    state['last_announced'] = signature
                elif not pending:
                    state['last_announced'] = ''
            except Exception as exc:
                xbmc.log('[Nebelkind update] Check failed: ' + type(exc).__name__, xbmc.LOGWARNING)
                # Avoid repeated blocking retries during a temporary outage.
                state['last_check'] = now
        _save_state(state_path, state)
    except Exception:
        # Never interrupt TV/film playback or Kodi startup because of update UI.
        try:
            import xbmc
            xbmc.log('[Nebelkind update] Startup notification skipped', xbmc.LOGWARNING)
        except Exception:
            pass
