"""Optional MovieScout-compatible remote scraper engine (isolated from xShip)."""
