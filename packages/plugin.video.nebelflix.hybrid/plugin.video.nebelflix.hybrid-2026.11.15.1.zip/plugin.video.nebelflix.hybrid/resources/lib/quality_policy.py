"""MovieScout-style quality preference for xShip's shared provider list.

The upstream labels are declared estimates. If a media probe actually returns
video height, the measured height takes precedence over the label.
"""
import re


def source_quality(source):
    probe = source.get('_probe') or {}
    try:
        height = int(probe.get('height') or 0)
    except (TypeError, ValueError):
        height = 0
    if height > 100:
        if height >= 2000: return 4
        if height >= 1300: return 3
        if height >= 900: return 2
        if height >= 650: return 1
        return 0
    label = str(source.get('quality') or '').strip().lower()
    if '2160' in label or '4k' in label or 'uhd' in label: return 4
    if '1440' in label or '2k' in label: return 3
    if '1080' in label or 'fhd' in label: return 2
    if '720' in label or label == 'hd': return 1
    if any(v in label for v in ('576','540','480','360','sd','cam','scr')): return 0
    return -1  # unknown quality: do not rank ahead of confirmed SD


def order_sources(items, mode='0'):
    """0=best (4K), 1=data saving, 2=original/fast, 3=1080p first.

    Stable sort retains fallback hoster order within each quality bucket.
    """
    items = list(items)
    mode = str(mode or '0')
    if mode == '2':
        return items
    if mode == '1':
        return sorted(items, key=lambda s: (source_quality(s) < 0,
                                            source_quality(s) if source_quality(s) >= 0 else 9))
    if mode == '3':
        preference = {2:0,3:1,4:2,1:3,0:4,-1:5}
        return sorted(items, key=lambda s: preference.get(source_quality(s),5))
    return sorted(items, key=lambda s: -source_quality(s))
