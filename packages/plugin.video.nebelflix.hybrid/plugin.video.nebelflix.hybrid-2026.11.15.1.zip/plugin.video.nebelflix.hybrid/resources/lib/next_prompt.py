# -*- coding: utf-8 -*-
"""Lightweight in-player next episode prompt, usable with remote/keyboard/touch.

This is non-modal: video continues while the prompt is visible. The player's
own watcher handles the requested action; Kodi GUI callbacks never start a
second scraper directly.
"""
import xbmcgui


class NextPrompt(xbmcgui.WindowXMLDialog):
    def __new__(cls, title, subtitle, on_now, on_later):
        from resources.lib import control
        return super(NextPrompt, cls).__new__(
            cls, 'NextEpisode.xml', control.addonInfo('path'), 'Default', '1080i')

    def __init__(self, title, subtitle, on_now, on_later):
        self.title = title
        self.subtitle = subtitle
        self.on_now = on_now
        self.on_later = on_later

    def onInit(self):
        self.setProperty('NextTitle', self.title)
        self.setProperty('NextSubtitle', self.subtitle)
        try:
            self.setFocusId(21)
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId == 21:
            try:
                if self.on_now:
                    self.on_now()
            finally:
                self.close()
        elif controlId == 22:
            self.close()
            if self.on_later:
                self.on_later()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.close()
            if self.on_later:
                self.on_later()
