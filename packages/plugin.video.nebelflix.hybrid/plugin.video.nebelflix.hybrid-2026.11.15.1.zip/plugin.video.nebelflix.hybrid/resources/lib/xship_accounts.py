"""Opt-in xShip Mod account import for Nebelflix Hybrid.

The two Kodi add-on IDs have separate userdata. Credentials are copied locally
in Kodi only with the user's approval. Never log credential values.
"""
ACCOUNT_IDS = (
    'serienstream.user', 'serienstream.pass',
    'flimmerstube.user', 'flimmerstube.pass',
    'aniworld.user', 'aniworld.pass',
    'subtitles.os_user', 'subtitles.os_pass',
    'api.tmdb', 'api.trakt', 'api.fanart.tv',
)


def import_accounts():
    import xbmcaddon
    import xbmcgui
    dialog = xbmcgui.Dialog()
    if not dialog.yesno('Konten aus xShip Mod uebernehmen',
                        'Fehlende Zugangsdaten lokal aus einer installierten xShip Mod kopieren? '
                        'Bestehende Hybrid-Einstellungen bleiben erhalten.'):
        return
    try:
        old_addon = xbmcaddon.Addon('plugin.video.xship')
    except Exception:
        dialog.ok('xShip Mod nicht gefunden',
                  'Bitte die xShip Mod auf diesem Kodi-System installieren. '
                  'Dein bestehender Hybrid bleibt unveraendert.')
        return
    dest = xbmcaddon.Addon('plugin.video.nebelflix.hybrid')
    count = 0
    for setting_id in ACCOUNT_IDS:
        try:
            if dest.getSetting(setting_id):
                continue
            source_value = old_addon.getSetting(setting_id)
            if not source_value:
                continue
            dest.setSetting(setting_id, source_value)
            count += 1
        except Exception:
            # No credentials in exceptions/logs.
            pass
    dialog.ok('Konten-Uebernahme',
              '%d noch nicht belegte Konten-Felder wurden uebernommen. '
              'Vorhandene Hybrid-Daten blieben erhalten.' % count)
