# -*- coding: utf-8 -*-
"""Nebelkind addon runtime guard.

Checks for INSTALLATION, not active skin. Does not license or secure downloads;
public ZIP contents can be altered by third parties.
"""
import sys


def is_skin_installed():
    # Filesystem existence works for an installed-but-not-currently-selected skin.
    # Do not require the skin to be active: user explicitly requested only installed.
    try:
        import xbmcvfs
        if xbmcvfs.exists('special://home/addons/skin.nebelflix/addon.xml'):
            return True
    except Exception:
        pass
    # Support systems with the addon in an alternate addon location.
    try:
        import xbmcaddon
        return xbmcaddon.Addon(id='skin.nebelflix').getAddonInfo('id') == 'skin.nebelflix'
    except Exception:
        return False


def require_skin(argv=None):
    if is_skin_installed():
        return True
    try:
        import xbmc
        import xbmcgui
        import xbmcplugin
        window = xbmcgui.Window(10000)
        if window.getProperty('Nebelkind.SkinMissing.Notified') != '1':
            window.setProperty('Nebelkind.SkinMissing.Notified', '1')
            xbmcgui.Dialog().notification('Nebelkind',
                    'Bitte zuerst NebelFlix Skin installieren.',
                    xbmcgui.NOTIFICATION_WARNING, 7000, False)
        xbmc.log('[Nebelkind] Addon start blocked: skin.nebelflix is not installed', xbmc.LOGWARNING)
        arguments = argv if argv is not None else sys.argv
        if len(arguments) > 1:
            try:
                handle = int(arguments[1])
                if handle >= 0:
                    # Finish route without presenting any content.
                    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
            except (ValueError, TypeError):
                pass
    except Exception:
        pass
    return False
