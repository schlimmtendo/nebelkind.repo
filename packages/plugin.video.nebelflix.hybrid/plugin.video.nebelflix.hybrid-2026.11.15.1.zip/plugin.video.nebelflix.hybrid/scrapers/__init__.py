
# edit 2026.06.19

import os.path
import pkgutil
import importlib.util
from resources.lib import log_utils

try:
    import xbmcaddon
    __addon__ = xbmcaddon.Addon()
except:
    __addon__ = None
    pass

debug = True #if __addon__.getSetting('debug.enabled') == 'true' else False

LAST_LOAD_DIAGNOSTICS = []


def sources(specified_folders=None):
    """Load xShip-Mod providers plus existing Hybrid extensions safely.

    Diagnose load failures instead of disabling provider settings permanently.
    """
    global LAST_LOAD_DIAGNOSTICS
    result, diagnostics = [], []
    try:
        base = os.path.join(os.path.dirname(__file__), getScraperFolder('scrapers'))
        folders = specified_folders if specified_folders is not None else [x[1] for x in os.walk(base)][0]
        for folder in folders:
            source_dir = os.path.join(base, folder)
            for _loader, name, is_package in pkgutil.walk_packages([source_dir]):
                if is_package:
                    continue
                entry = {'provider': name, 'folder': folder, 'status': 'DISCOVERED', 'error': ''}
                diagnostics.append(entry)
                if not enabledCheck(name):
                    entry['status'] = 'DISABLED'
                    continue
                try:
                    filename = os.path.join(source_dir, name + '.py')
                    spec = importlib.util.spec_from_file_location(name, filename)
                    if spec is None or spec.loader is None:
                        raise ImportError('Missing module spec')
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    result.append((name, module.source()))
                    entry['status'] = 'LOADED'
                except Exception as exc:
                    entry['status'] = 'LOAD_ERROR'
                    entry['error'] = '%s: %s' % (type(exc).__name__, str(exc)[:300])
                    log_utils.log('Scraper %s: %s' % (name, entry['error']), log_utils.LOGERROR)
    except Exception as exc:
        log_utils.log('Scraper scan failed: %s' % type(exc).__name__, log_utils.LOGERROR)
    LAST_LOAD_DIAGNOSTICS = diagnostics
    return result


def getLoadDiagnostics():
    return list(LAST_LOAD_DIAGNOSTICS)


def enabledCheck(module_name):
    if __addon__ is not None:
        if __addon__.getSetting('provider.' + module_name) == 'false':
            return False
        return True


def providerSources():
    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    return getModuleName(sourceSubFolders)


def providerNames():
    providerList = []
    provider = __addon__.getSetting('module.provider')
    sourceFolder = getScraperFolder(provider)
    sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
    sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
    for i in sourceSubFolders:
        for loader, module_name, is_pkg in pkgutil.walk_packages([os.path.join(sourceFolderLocation, i)]):
            if is_pkg:
                continue
            correctName = module_name.split('_')[0]
            providerList.append(correctName)
    return providerList


def getAllHosters():
    def _sources(sourceFolder, appendList):
        sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
        sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
        for i in sourceSubFolders:
            for loader, module_name, is_pkg in pkgutil.walk_packages([os.path.join(sourceFolderLocation, i)]):
                if is_pkg:
                    continue
                try:
                    mn = str(module_name).split('_')[0]
                except:
                    mn = str(module_name)
                appendList.append(mn)

    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    appendList = []
    for item in sourceSubFolders:
        if item != 'modules':
            _sources(item, appendList)
    return list(set(appendList))


def getScraperFolder(scraper_source):
    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    return [i for i in sourceSubFolders if scraper_source.lower() in i.lower()][0]


def getModuleName(scraper_folders):
    nameList = []
    for s in scraper_folders:
        try:
            nameList.append(s.split('_')[1].lower().title())
        except:
            pass
    return nameList
