# streamcloud
# fixed 2026-07-10

import re
import time
from urllib.parse import quote_plus, urljoin, urlparse

from resources.lib.utils import isBlockedHoster, normalizeHosterUrl
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from resources.lib.control import getSetting
from scrapers.modules import meinecloud

SITE_IDENTIFIER = 'streamcloud'
SITE_DOMAIN = 'streamcloud.date'
SITE_NAME = SITE_IDENTIFIER.upper()


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = (getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN) or SITE_DOMAIN).strip()
        # Alte gespeicherte Domains auf die aktuelle Domain migrieren.
        if self.domain.lower().replace('https://', '').replace('http://', '').strip('/') in ('streamcloud.uno', 'streamcloud.forum', 'streamcloud.download'):
            self.domain = SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/suche?q=%s'
        self.sources = []

    def _log(self, message, level=1):
        """Best-effort logging without making the scraper depend on one logger API."""
        text = '[STREAMCLOUD] %s' % message
        try:
            import xbmc
            xbmc.log(text, level)
        except Exception:
            try:
                from resources.lib import control
                control.log(text)
            except Exception:
                pass

    def _absolute_url(self, url):
        if not url:
            return ''
        if url.startswith('//'):
            return 'https:' + url
        return urljoin(self.base_link + '/', url)

    def _request(self, url, referer=None, caching=False):
        request = cRequestHandler(url, caching=caching)
        if referer:
            request.addHeaderEntry('Referer', referer)
        request.addHeaderEntry('User-Agent',
                               'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                               'AppleWebKit/537.36 (KHTML, like Gecko) '
                               'Chrome/126.0 Safari/537.36')
        return request.request() or ''


    def _normalize_imdb(self, imdb):
        value = str(imdb or '').strip()
        if not value:
            return ''
        match = re.search(r'(tt\d+)', value, re.I)
        if match:
            return match.group(1).lower()
        digits = re.sub(r'\D', '', value)
        return ('tt' + digits) if digits else ''

    def _quality_from_url(self, url, default='720p'):
        value = (url or '').lower()
        if any(token in value for token in ('2160', '4k', 'uhd')):
            return '4K'
        if any(token in value for token in ('1080', 'fullhd', 'fhd')):
            return '1080p'
        if '720' in value:
            return '720p'
        if '480' in value:
            return '480p'
        if '360' in value:
            return '360p'
        return default

    def _resolve_dr0pstream(self, url):
        lower = (url or '').lower()
        if 'dr0pstream.' not in lower and 'dropload.' not in lower:
            return ''
        try:
            html = self._request(url, referer='https://meinecloud.click/', caching=False)
            patterns = (
                r'["\'](https?://[^"\'<>\s]*dropcdn[^"\'<>\s]*\.m3u8[^"\'<>\s]*)["\']',
                r'["\'](https?://[^"\'<>\s]*\.m3u8[^"\'<>\s]*)["\']',
                r'["\'](https?://[^"\'<>\s]*\.mp4[^"\'<>\s]*)["\']',
                r'file\s*[=:]\s*["\'](https?://[^"\'<>\s]+)["\']',
                r'source\s*[=:]\s*["\'](https?://[^"\'<>\s]+)["\']',
            )
            for pattern in patterns:
                match = re.search(pattern, html, re.I)
                if not match:
                    continue
                stream_url = match.group(1).strip().rstrip('"\'')
                if stream_url.startswith('http'):
                    if '|' not in stream_url:
                        stream_url += '|Referer=https://dr0pstream.com/&Origin=https://dr0pstream.com'
                    return stream_url
        except Exception as exc:
            self._log('dr0pstream-Auflösung fehlgeschlagen für %s: %s' % (url, exc), 3)
        return ''

    def _extract_meinecloud_links(self, html):
        links = []
        patterns = (
            r'data-link=["\']([^"\']+)["\']',
            r'data-href=["\']([^"\']+)["\']',
            r'window\.open\(\s*["\']([^"\']+)["\']',
            r'file\s*[:=]\s*["\']([^"\']+)["\']',
            r'source\s*[:=]\s*["\']([^"\']+)["\']',
        )
        for pattern in patterns:
            links.extend(re.findall(pattern, html or '', re.I))
        return links

    def _search_meinecloud_movie(self, imdb, found_urls):
        imdb_id = self._normalize_imdb(imdb)
        if not imdb_id:
            return

        movie_url = 'https://meinecloud.click/movie/%s' % imdb_id
        ddl_url = 'https://meinecloud.click/ddl/%s' % imdb_id
        pages = ((movie_url, self.base_link + '/'), (ddl_url, movie_url))

        for page_url, referer in pages:
            try:
                html = self._request(page_url, referer=referer, caching=False)
            except Exception as exc:
                self._log('Meinecloud-Request fehlgeschlagen für %s: %s' % (page_url, exc), 3)
                continue

            # Manche Movie-Seiten enthalten zuerst ein weiteres iframe.
            iframe_urls = re.findall(
                r'<iframe\b[^>]*\bsrc=["\']([^"\']+)["\']', html, re.I | re.S
            )
            page_contents = [(page_url, html)]
            for iframe_url in iframe_urls:
                iframe_url = urljoin(page_url, iframe_url)
                if 'youtube' in iframe_url.lower():
                    continue
                try:
                    iframe_html = self._request(iframe_url, referer=page_url, caching=False)
                    page_contents.append((iframe_url, iframe_html))
                except Exception:
                    continue

            for content_url, content in page_contents:
                for link in self._extract_meinecloud_links(content):
                    link = urljoin(content_url, link)
                    lower = link.lower()
                    if not link or 'youtube' in lower or 'fullhd/index.php' in lower:
                        continue
                    if 'meinecloud.click/' in lower:
                        continue
                    self._add_source(link, self._quality_from_url(link, '1080p'), found_urls)

    def _next_cards(self, page):
        """Read server-rendered Next.js cards: title, URL, year."""
        found = []
        for match in re.finditer(r'<a\b(?=[^>]*\bclass=["\'][^"\']*\bcv\b[^"\']*["\'])([^>]*)>(.*?)</a>', page or '', re.I | re.S):
            attrs, body = match.groups()
            href = re.search(r'\bhref=["\']([^"\']+)', attrs, re.I)
            title = re.search(r'\btitle=["\']([^"\']+)', attrs, re.I)
            if not href or not title or not href.group(1).startswith(('/stream/', '/filme/', '/serien/')):
                continue
            year = re.search(r'class=["\'][^"\']*\bcv-m\b[^"\']*["\'][^>]*>\s*((?:19|20)\d{2})', body, re.I)
            found.append((__import__('html').unescape(title.group(1)), href.group(1), year.group(1) if year else ''))
        return found

    def _search_title(self, titles, year):
        wanted_titles = {cleantitle.get(title) for title in titles if title}
        wanted_years = {str(int(year) - 1), str(int(year)), str(int(year) + 1)}

        # Mehrere Varianten, weil sich Attributreihenfolge und Quotes ändern können.
        patterns = (
            r'class=["\'][^"\']*\bthumb\b[^"\']*["\'][^>]*>.*?title=["\']([^"\']+)["\'].*?href=["\']([^"\']+)["\'].*?class=["\'][^"\']*_year[^"\']*["\'][^>]*>\s*([^<]+)',
            r'class=["\'][^"\']*\bthumb\b[^"\']*["\'].*?href=["\']([^"\']+)["\'].*?title=["\']([^"\']+)["\'].*?class=["\'][^"\']*_year[^"\']*["\'][^>]*>\s*([^<]+)',
        )

        for search_text in titles:
            if not search_text:
                continue
            search_url = self.search_link % quote_plus(str(search_text))
            try:
                html = self._request(search_url, referer=self.base_link + '/', caching=False)
                self._log('Suche: %s -> %d Zeichen' % (search_url, len(html)))
                if not html:
                    continue

                # DLE leitet bei einem eindeutigen Suchtreffer teilweise direkt
                # auf die Detailseite weiter. In diesem Fall existiert keine
                # Ergebnisliste; Titel, Jahr und Ziel-URL stehen bereits im
                # Seitentitel bzw. Canonical-Link.
                page_title_match = re.search(
                    r'<title>\s*(.*?)\s*\((\d{4})\)', html, re.I | re.S
                )
                canonical_match = re.search(
                    r'<link\b[^>]*\brel=["\']canonical["\'][^>]*\bhref=["\']([^"\']+)',
                    html, re.I | re.S
                )
                if not canonical_match:
                    canonical_match = re.search(
                        r'<link\b[^>]*\bhref=["\']([^"\']+)["\'][^>]*\brel=["\']canonical["\']',
                        html, re.I | re.S
                    )

                if page_title_match and canonical_match:
                    page_name = re.sub(r'<[^>]+>', '', page_title_match.group(1)).strip()
                    page_year = page_title_match.group(2)
                    cleaned_page_name = cleantitle.get(page_name)
                    if cleaned_page_name in wanted_titles and page_year in wanted_years:
                        found_url = self._absolute_url(canonical_match.group(1))
                        self._log('Direkte Detailseite erkannt: %s (%s) -> %s' %
                                  (page_name, page_year, found_url))
                        return found_url

                # Current Next.js layout; old DLE patterns remain as fallback.
                for name, href, found_year in self._next_cards(html):
                    if cleantitle.get(name) in wanted_titles and (not found_year or found_year in wanted_years):
                        found_url = self._absolute_url(href)
                        self._log('Next.js-Treffer: %s (%s) -> %s' % (name, found_year, found_url))
                        return found_url

                results = []
                matched, parsed = cParser.parse(html, patterns[0])
                if matched:
                    results.extend((name, href, found_year) for name, href, found_year in parsed)

                matched2, parsed2 = cParser.parse(html, patterns[1])
                if matched2:
                    results.extend((name, href, found_year) for href, name, found_year in parsed2)

                # Einfacherer Fallback für bekannte DLE-Layouts.
                if not results:
                    fallback = re.findall(
                        r'<a[^>]+href=["\']([^"\']+)["\'][^>]+title=["\']([^"\']+)["\'][^>]*>.*?'
                        r'(?:_year| DE)[^>]*>\s*(\d{4})',
                        html,
                        re.I | re.S,
                    )
                    results.extend((name, href, found_year) for href, name, found_year in fallback)

                for name, href, found_year in results:
                    cleaned_name = cleantitle.get(name)
                    normalized_year = re.sub(r'\D', '', found_year or '')[:4]
                    if cleaned_name in wanted_titles and normalized_year in wanted_years:
                        found_url = self._absolute_url(href)
                        self._log('Treffer: %s (%s) -> %s' % (name, normalized_year, found_url))
                        return found_url
            except Exception as exc:
                self._log('Suchfehler für %r: %s' % (search_text, exc), 3)

        self._log('Kein passender Titel gefunden. titles=%r year=%r' % (titles, year), 2)
        return ''

    def _normalize_hoster_url(self, url):
        """Verwendet die zentrale Alias-Normalisierung aus resources.lib.utils."""
        return normalizeHosterUrl(self._absolute_url(url))

    def _add_source(self, url, quality, found_urls):
        url = self._normalize_hoster_url(url)
        lower = (url or '').lower()
        if (not url or url in found_urls or 'youtube' in lower or
                'fullhd/index.php' in lower or 'meinecloud.click/' in lower):
            return
        found_urls.add(url)
        # Die Plattform-Embed-Seite ist selbst keine direkte Videodatei.
        # Die enthaltenen Hoster-Links werden über die API/HTML extrahiert.
        if meinecloud.is_platform(url):
            self._log('Plattform-Embed übersprungen (kein Direktstream): %s' % url, 2)
            return

        # MeineCloud liefert bereits externe Hoster-URLs. xShips zentrale
        # isBlockedHoster()-Pruefung fuehrt vorher einen HEAD-Request aus und
        # sperrt doodstream.com fest; dadurch verschwinden funktionierende
        # Quellen, bevor Kodi sie aufloesen kann. Nur fuer StreamCloud daher
        # bekannte Resolver-Hoster ohne Netz-Vorabpruefung uebernehmen.
        # Die vom Benutzer eingestellte Hoster-Sperrliste bleibt wirksam.
        try:
            import resolveurl
            hostname = (urlparse(url).hostname or '').lower()
            configured = (getSetting('hosts.filter') or '').replace(',', ' ').lower().split()
            if hostname and not any(blocked and blocked in hostname for blocked in configured):
                resolvers = resolveurl.relevant_resolvers(domain=hostname)
                if resolvers:
                    self.sources.append({
                        'source': hostname,
                        'quality': quality,
                        'language': 'de',
                        'url': url,
                        'direct': False,
                        'prioHoster': getattr(resolvers[0], 'priority', 100),
                    })
                    self._log('Hoster zur Wiedergabe vorgemerkt: %s' % hostname)
                    return
        except Exception as exc:
            self._log('Resolver-Erkennung fehlgeschlagen: %s' % exc, 2)

        # Bekannte Hoster erst bei der Wiedergabe aufloesen. Eine Vorab-
        # Aufloesung kann bei Captcha, Rate-Limits oder temporaeren Fehlern
        # einen ansonsten funktionierenden Hoster aus der Liste entfernen.
        # Die zentrale Hoster-Sperrliste bleibt weiterhin wirksam.
        try:
            is_blocked, hoster, checked_url, prio_hoster = isBlockedHoster(url, isResolve=False)
            if not is_blocked and checked_url:
                self.sources.append({
                    'source': hoster,
                    'quality': quality,
                    'language': 'de',
                    'url': checked_url,
                    'direct': False,
                    'prioHoster': prio_hoster,
                })
                return
        except Exception as exc:
            self._log('Hoster-Vorpruefung fehlgeschlagen fuer %s: %s' % (url, exc), 3)

        # Bestehende Aufloesung fuer nicht direkt erkannte Hoster beibehalten,
        # insbesondere den bereits funktionierenden DerrickNationTop-Link.
        try:
            is_blocked, hoster, resolved_url, prio_hoster = isBlockedHoster(url)
            if not is_blocked and resolved_url:
                self.sources.append({
                    'source': hoster,
                    'quality': self._quality_from_url(resolved_url, quality),
                    'language': 'de',
                    'url': resolved_url,
                    'direct': bool('.m3u8' in resolved_url.lower() or '.mp4' in resolved_url.lower()),
                    'prioHoster': prio_hoster,
                })
                return
        except Exception as exc:
            self._log('ResolveURL-Prüfung fehlgeschlagen für %s: %s' % (url, exc), 3)

        direct_url = self._resolve_dr0pstream(url)
        if direct_url:
            self.sources.append({
                'source': 'dr0pstream',
                'quality': self._quality_from_url(direct_url, quality),
                'language': 'de',
                'url': direct_url,
                'direct': True,
                'prioHoster': 0,
            })
            return

        self._log('Hoster verworfen: %s' % url, 2)

    def run(self, titles, year, season=0, episode=0, imdb=''):
        self.sources = []
        found_urls = set()
        self._log('run start: titles=%r year=%r season=%r episode=%r imdb=%r domain=%s' %
                  (titles, year, season, episode, imdb, self.domain))

        try:
            # Neue MeineCloud-API; bestehende HTML- und Titelsuche bleiben Fallback.
            try:
                imdb_id = self._normalize_imdb(imdb)
                if imdb_id:
                    if int(season or 0) == 0:
                        api_urls = meinecloud.movie(imdb_id, referer=self.base_link + '/')
                    else:
                        api_urls = meinecloud.series(imdb_id, season, episode, referer=self.base_link + '/')
                    for api_url in api_urls:
                        self._add_source(api_url, '1080p', found_urls)
                    if self.sources:
                        self._log('MeineCloud-API: %d abspielbare Quellen; weitere Quellen werden geprüft' % len(self.sources))
            except Exception as exc:
                self._log('MeineCloud-API fehlgeschlagen: %s' % exc, 3)

            # Filme zuerst direkt über IMDb/Meinecloud laden.
            if int(season or 0) == 0 and imdb:
                self._search_meinecloud_movie(imdb, found_urls)
                if self.sources:
                    self._log('IMDb-Direktweg: %d Quellen; Detailseite wird zusätzlich geprüft' % len(self.sources))
                else:
                    self._log('IMDb-Direktweg ohne Treffer; Titelsuche als Fallback', 2)

            detail_url = self._search_title(titles, year)
            if not detail_url:
                self._log('run Ende: %d Quellen (keine Detailseite)' % len(self.sources))
                return self.sources

            detail = self._request(
                detail_url + ('&' if '?' in detail_url else '?') + '_t=%d' % int(time.time()),
                referer=self.base_link + '/',
                caching=False,
            )
            self._log('Detailseite: %s -> %d Zeichen' % (detail_url, len(detail)))

            if int(season or 0) == 0:
                iframe_urls = re.findall(
                    r'<iframe\b[^>]*\bsrc=["\']([^"\']+)["\']', detail, re.I | re.S
                )
                iframe_urls = [urljoin(detail_url, url) for url in iframe_urls if url]
                iframe_urls = [url for url in iframe_urls if 'youtube.com' not in url.lower()]
                if not iframe_urls:
                    self._log('Kein Film-iframe auf der Detailseite gefunden', 2)
                    return self.sources

                # Alle relevanten Player prüfen, nicht nur den ersten iframe.
                # Download-Widgets und Trailer sind keine Filmplayer.
                players = []
                for candidate in iframe_urls:
                    lower = candidate.lower()
                    if ('/embed/download/' in lower or 'youtube.' in lower or
                            'youtube-nocookie.' in lower):
                        continue
                    if candidate not in players:
                        players.append(candidate)
                for iframe_url in players:
                    try:
                        iframe_html = self._request(
                            iframe_url + ('&' if '?' in iframe_url else '?') + '_t=%d' % int(time.time()),
                            referer=detail_url,
                            caching=False,
                        )
                        links = self._extract_meinecloud_links(iframe_html)
                        self._log('iframe: %s -> %d Link-Treffer' % (iframe_url, len(links)))
                        for link in links:
                            if link and 'embed-.html' not in link:
                                self._add_source(urljoin(iframe_url, link), '720p', found_urls)
                    except Exception as exc:
                        self._log('iframe konnte nicht geprüft werden: %s' % exc, 2)
            else:
                imdb_match = (re.search(r"var\s+imdb\s*=\s*['\"]?(tt\d+)", detail, re.I) or
                              re.search(r'id_imdb=(tt\d+)', detail, re.I))
                imdb_id = self._normalize_imdb(imdb) or (imdb_match.group(1) if imdb_match else '')
                if imdb_id:
                    try:
                        for api_url in meinecloud.series(imdb_id, season, episode, referer=detail_url):
                            self._add_source(api_url, '1080p', found_urls)
                        if self.sources:
                            return self.sources
                    except Exception as exc:
                        self._log('MeineCloud-Serien-API: %s' % exc, 3)
                    imdb_number = imdb_id.replace('tt', '')
                    mc_url = 'https://meinecloud.click/serial/%s?s=%s&e=%s' % (
                        imdb_number, season, episode)
                    mc_html = self._request(mc_url, referer=self.base_link + '/', caching=False)
                    links = self._extract_meinecloud_links(mc_html)
                    if links:
                        index = max(0, int(episode) - 1)
                        selected = links[index] if index < len(links) else links[0]
                        self._add_source(urljoin(mc_url, selected), '720p', found_urls)
                        if self.sources:
                            return self.sources

                episode_pattern = r'data-num=["\']%sx%s["\'].*?(?=data-num=|$)' % (season, episode)
                block_match = re.search(episode_pattern, detail, re.I | re.S)
                if block_match:
                    for href in re.findall(r'href=["\']([^"\']+)["\']', block_match.group(0), re.I):
                        self._add_source(urljoin(detail_url, href), '720p', found_urls)

        except Exception as exc:
            self._log('run Fehler: %s' % exc, 3)

        self._log('run Ende: %d Quellen' % len(self.sources))
        return self.sources

    def resolve(self, url):
        return url
