"""Short-lived action entry point, separate from the persistent controller."""
import sys
import time
import xbmc
import xbmcgui
import load_timing


def quick_tab(args):
    if not args or not args[0].isdigit():
        return
    home = xbmcgui.Window(10000)
    if home.getProperty('NF.Revisions.Running') == 'true':
        return
    page = home.getProperty('NF.TabPage' + args[0])
    if page and page != home.getProperty('NF.Page'):
        home.setProperty('NF.HubSwitching', 'true')
        home.setProperty('NF.HubRequestedAt', str(time.monotonic()))
        home.clearProperty('NF.RowsPage')
        home.setProperty('NF.HasHero', 'false')
        home.setProperty('NF.StopSpotlight', 'true')
        home.setProperty('NF.Page', page)
        home.setProperty('NF.FocusAfterTab', '200')


if __name__ == '__main__':
    started = time.monotonic()
    command = sys.argv[1] if len(sys.argv) > 1 else 'diagnostic'
    try:
        if (command not in ('tab','monitor','reload','stop','timing_debug') and
                xbmcgui.Window(10000).getProperty('NF.HubSwitching')=='true'):
            raise SystemExit(0)
        if command == 'tab':
            quick_tab(sys.argv[2:])
        else:
            import controller
            load_timing.record('skin', 'action.import', started)
            controller.dispatch(command, sys.argv[2:])
    except Exception as exc:
        xbmc.log('[Nebelflix] %s: %s' % (type(exc).__name__, exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Nebelflix', 'Aktion fehlgeschlagen. Details stehen im Kodi-Protokoll.')
        raise
    finally:
        load_timing.record('skin', 'action.' + command, started)
