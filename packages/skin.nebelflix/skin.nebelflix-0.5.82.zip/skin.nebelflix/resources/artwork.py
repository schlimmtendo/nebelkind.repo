"""Bounded background downloads of first-page widget artwork for TV devices."""
import hashlib
import os
from pathlib import Path
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor


class Artwork:
    def __init__(self, root):
        self.root = Path(root)
        # Keep Kodi's UI responsive on Android/Fire TV.
        try:
            import xbmc
            self.low_power = bool(xbmc.getCondVisibility('System.Platform.Android'))
        except (ImportError, AttributeError, RuntimeError):
            self.low_power = False
        self.pool = ThreadPoolExecutor(max_workers=1 if self.low_power else 2)
        self.max_pending = 18 if self.low_power else 42
        self.max_per_batch = 5 if self.low_power else 10
        self.jobs = {}
        self.attempted = set()
        self.failures = 0

    def filename(self, url):
        suffix = Path(urlparse(url).path).suffix.lower()
        if suffix not in ('.jpg', '.jpeg', '.png', '.webp'):
            suffix = '.jpg'
        return self.root / (hashlib.sha256(url.encode('utf-8')).hexdigest() + suffix)

    def local(self, url):
        if not str(url).startswith(('http://', 'https://')):
            return url
        path = self.filename(url)
        return str(path) if path.is_file() else url

    def prepare(self, items):
        # Bounded prefetch: Kodi continues rendering URLs via its own cache.
        submitted = 0
        for item in items:
            for field in ('Poster', 'Fanart', 'Clearlogo'):
                if len(self.jobs) >= self.max_pending or submitted >= self.max_per_batch:
                    return
                url = item.get(field) or ''
                if not isinstance(url, str) or not url.startswith(('http://', 'https://')):
                    continue
                if self.local(url) != url or url in self.attempted:
                    continue
                self.attempted.add(url)
                self.jobs[url] = self.pool.submit(self.download, url)
                submitted += 1

    def download(self, url):
        import requests
        destination = self.filename(url)
        temporary = destination.with_suffix('.part')
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            with requests.get(url, timeout=(5, 12), stream=True) as response:
                response.raise_for_status()
                if not response.headers.get('Content-Type', '').lower().startswith('image/'):
                    return False
                size = 0
                with temporary.open('wb') as stream:
                    for chunk in response.iter_content(65536):
                        size += len(chunk)
                        if size > 4 * 1024 * 1024:
                            return False
                        stream.write(chunk)
                if size == 0:
                    return False
                os.replace(temporary, destination)
            return True
        except (OSError, requests.RequestException):
            return False
        finally:
            temporary.unlink(missing_ok=True)

    def tick(self):
        for url in [url for url, job in self.jobs.items() if job.done()]:
            if not self.jobs.pop(url).result():
                self.failures += 1

    def close(self):
        for job in self.jobs.values():
            job.cancel()
        self.pool.shutdown(wait=False)
