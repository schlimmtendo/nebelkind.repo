"""Local widget rendering only: no network, executors or widget-cache loading."""
import base64
import json
from pathlib import Path
import re
import time
import xbmcgui
import xbmcvfs


def read(page, row):
    root = Path(xbmcvfs.translatePath('special://profile/addon_data/skin.nebelflix/'))
    safe_page = re.sub(r'[^A-Za-z0-9_-]', '', str(page or 'home'))[:64] or 'home'
    name = 'row-%s-%d.json' % (safe_page, row) if page else 'row-%d.json' % row
    for attempt in range(3):
        try:
            data = json.loads((root / name).read_text(encoding='utf-8'))
            return data if isinstance(data, list) else []
        except (OSError, ValueError):
            if attempt < 2:
                time.sleep(.02)
    try:
        data = json.loads((root / (name + '.bak')).read_text(encoding='utf-8'))
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def listitem(item, rank=0, top10=False, continued=False):
    li = xbmcgui.ListItem(label=item.get('Title', ''), path=item.get('Path', ''))
    artwork = item.get('Fanart') or item.get('Poster') or 'special://skin/media/nebelflix/poster.png'
    li.setArt({'fanart': artwork, 'landscape': artwork, 'thumb': artwork,
               'poster': item.get('Poster', ''), 'clearlogo': item.get('Clearlogo', '')})
    li.setProperty('NF.Data', json.dumps(item, ensure_ascii=False))
    li.setProperty('NF.Hub', item.get('Hub', ''))
    li.setProperty('tmdb_id', item.get('TMDB', ''))
    li.setProperty('tmdb_type', item.get('Type', ''))
    category = bool(item.get('GuideOpen') or (item.get('AddonBrowse') and
        str(item.get('Path', '')).startswith('plugin://plugin.video.nebelflix.tv/?action=list&group=')))
    li.setProperty('NFTV.Category', '1' if category else '')
    for key in ('EPG', 'EPGNext', 'EPGProgress'):
        li.setProperty('NF.' + key, str(item.get(key, '')))
    if item.get('AddonLauncher'):
        li.setProperty('NF.AddonLauncher', 'true')
        li.setProperty('NF.AddonID', item.get('AddonID', ''))
    tag = li.getVideoInfoTag()
    tag.setTitle(item.get('Title', ''))
    tag.setPlot(item.get('Plot', ''))
    if item.get('DBType') in ('movie', 'tvshow', 'episode', 'season'):
        tag.setMediaType(item['DBType'])
    if item.get('Resume'):
        li.setProperty('ResumeTime', str(item['Resume']))
        li.setProperty('TotalTime', str(item.get('Total', 0)))
    if top10 and 1 <= rank <= 10 and not any(item.get(key) for key in ('Empty', 'Next', 'Back')):
        li.setProperty('NF.Rank', str(rank))
        li.setProperty('NF.RankArt', 'special://skin/media/nebelflix/rank-%d.png' % rank)
    if continued and item.get('Resume') and not any(item.get(key) for key in ('Empty', 'Next', 'Back')):
        target = {key: item.get(key) for key in
                  ('Title', 'DBType', 'HybridMedia', 'HybridIdentity', 'Season', 'Episode')}
        token = base64.urlsafe_b64encode(json.dumps(target, ensure_ascii=False,
                    separators=(',', ':')).encode('utf-8')).decode('ascii').rstrip('=')
        li.addContextMenuItems([('Aus Weiterschauen entfernen',
            'RunScript(skin.nebelflix,remove_continue,%s)' % token)])
    return li
