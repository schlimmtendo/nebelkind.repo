"""Bounded background downloads of first-page widget artwork for TV devices."""
import hashlib
import os
import re
from pathlib import Path
from urllib.parse import urlparse
from bounded_workers import SearchExecutor as ThreadPoolExecutor
import threading
import time


class Artwork:
    def __init__(self, root, max_jobs=8, max_mb=128):
        self.root = Path(root)
        self.pool = ThreadPoolExecutor(max_workers=1)
        self.max_jobs = max_jobs
        self.paused = False
        self.max_bytes = max_mb * 1024 * 1024
        self.downloads = 0
        self.stopped = threading.Event()
        self.jobs = {}
        self.attempted = set()
        self.failures = 0

    def filename(self, url):
        suffix = Path(urlparse(url).path).suffix.lower()
        if suffix not in ('.jpg', '.jpeg', '.png', '.webp'):
            suffix = '.jpg'
        return self.root / (hashlib.sha256(url.encode('utf-8')).hexdigest() + suffix)

    def local(self, url):
        if not str(url).startswith(('http://', 'https://')):
            return url
        path = self.filename(url)
        return str(path) if path.is_file() else url

    def prepare(self, items):
        if self.paused:
            return
        for item in items:
            for field in ('Fanart', 'Poster', 'Clearlogo'):
                url = item.get(field) or ''
                if not url.startswith(('http://', 'https://')):
                    continue
                if self.local(url) != url or url in self.attempted:
                    continue
                if len(self.jobs) >= self.max_jobs:
                    return
                self.attempted.add(url)
                self.jobs[url] = self.pool.submit(self.download, url)

    def download(self, url):
        import requests
        destination = self.filename(url)
        temporary = destination.with_suffix('.part')
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            if self.downloads % 16 == 0:
                self.prune()
            self.downloads += 1
            deadline=time.monotonic()+4
            with requests.get(url, timeout=(2, 2), stream=True) as response:
                response.raise_for_status()
                if not response.headers.get('Content-Type', '').lower().startswith('image/'):
                    return False
                size = 0
                with temporary.open('wb') as stream:
                    for chunk in response.iter_content(65536):
                        if self.stopped.is_set() or time.monotonic()>deadline:
                            return False
                        size += len(chunk)
                        if size > 4 * 1024 * 1024:
                            return False
                        stream.write(chunk)
                if size == 0:
                    return False
                os.replace(temporary, destination)
            return True
        except (OSError, requests.RequestException):
            return False
        finally:
            temporary.unlink(missing_ok=True)

    def prune(self):
        # Runs on the sole download worker, never on Kodi's UI/controller loop.
        files = []
        root = self.root.resolve()
        for path in self.root.iterdir():
            if not re.fullmatch(r'[a-f0-9]{64}\.(jpg|jpeg|png|webp)', path.name):
                continue
            try:
                if path.is_symlink() or path.resolve().parent != root:
                    continue
                stat = path.stat()
                files.append((stat.st_mtime, stat.st_size, path))
            except OSError:
                continue
        size = sum(item[1] for item in files)
        for _, amount, path in sorted(files):
            if size <= self.max_bytes * 0.85:
                break
            try:
                path.unlink()
                size -= amount
            except OSError:
                pass

    def tick(self):
        for url in [url for url, job in self.jobs.items() if job.done()]:
            if not self.jobs.pop(url).result():
                self.failures += 1
        if len(self.attempted) > 1500:
            self.attempted = set(self.jobs)

    def close(self):
        self.stopped.set()
        for job in self.jobs.values():
            job.cancel()
        self.pool.shutdown(wait=False)
