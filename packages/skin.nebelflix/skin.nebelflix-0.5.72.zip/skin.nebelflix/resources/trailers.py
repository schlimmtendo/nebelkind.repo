"""MultiTrailer resolution only; playback and cancellation belong to the skin."""
def resolve(item):
    from multitrailer import api, sources, filters
    media = item.get('Type')
    ident = str(item.get('TMDB') or '')
    if media not in ('movie', 'tv') or not ident.isdigit():
        return None
    for language, locale in (('de', 'de-DE'), ('en', 'en-US')):
        candidates = [v for v in sources.from_tmdb(media, int(ident), locale=locale)
                      if v.get('language') == language and v.get('type') == 'Trailer'
                      and not v.get('fan_made')]
        candidates.sort(key=lambda v: (bool(v.get('official')), v.get('published', '')), reverse=True)
        if language == 'de' and not candidates and media == 'tv' and item.get('Title'):
            # Many series have no German video attached to their TMDB record.
            # Use MultiTrailer's title matching, then require an explicit language
            # marker and a real trailer (not a recap, concept or fan edit).
            import re
            title = item['Title']
            found = sources.from_youtube_search(title + ' Serie', suffix=' Trailer Deutsch',
                                                query_title=title, require_match=True)
            words = re.findall(r'\w+', title.casefold())
            for video in found:
                name = video.get('title', '')
                folded = ' '.join(re.findall(r'\w+', name.casefold()))
                if (words and ' '.join(words) in folded
                        and re.search(r'\b(deutsch|german)\b', name, re.I)
                        and re.search(r'\btrailer\b', name, re.I)
                        and not re.search(r'\b(teaser|recap|review|reaction|ov|omu)\b', name, re.I)
                        and not filters.is_fan_made(name, video.get('channel'))):
                    candidates.append(video)
        for candidate in candidates[:6]:
            stream, _ = api.resolve_video_item(candidate, max_quality=2160,
                                             ask_quality=False, prefer_dash=False)
            if stream and stream.get('url'):
                # Do not expose MultiTrailer's loopback HTTP MPD to Kodi: when its local
                # server stalls, Kodi blocks media stat for ~20s per retry. Resolve a
                # direct HLS/HTTP stream so category changes can stop immediately.
                from urllib.parse import urlparse
                if urlparse(stream['url']).hostname == '127.0.0.1':
                    continue
                return dict(stream, title=item.get('Title', 'Trailer'))
    return None


def play(player, stream, windowed):
    import xbmcgui
    from urllib.parse import urlencode
    li = xbmcgui.ListItem(label=stream.get('title', 'Trailer'), path=stream['url'])
    li.setProperty('IsPlayable', 'true')
    if stream.get('isa_manifest_type'):
        li.setProperty('inputstream', 'inputstream.adaptive')
        headers = urlencode(stream.get('http_headers') or {})
        if headers:
            li.setProperty('inputstream.adaptive.manifest_headers', headers)
            li.setProperty('inputstream.adaptive.stream_headers', headers)
        li.setMimeType(stream.get('mime_type') or ('application/dash+xml'
                       if stream['isa_manifest_type'] == 'mpd' else 'application/vnd.apple.mpegurl'))
        li.setContentLookup(False)
    player.play(stream['url'], li, windowed=windowed)
