"""Fast local Kodi directory provider for controller-owned widget snapshots."""
import base64
import json
import sys
from urllib.parse import parse_qs, urlencode, urlparse
import xbmcplugin
import library
import vavoo_live

handle = int(sys.argv[1])
params = parse_qs(sys.argv[2].lstrip('?'))
vavoo_mode = (params.get('vavoo') or [''])[0]
if vavoo_mode in ('groups', 'group'):
    source = 'nf://vavoo/groups'
    if vavoo_mode == 'group':
        filename = (params.get('file') or [''])[0]
        source = 'nf://vavoo/group?' + urlencode({'file': filename})
    items, _ = vavoo_live.directory(source)
    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.setProperty(handle, 'NF.VavooGuide', 'true' if vavoo_mode == 'group' else '')
    if vavoo_mode == 'group':
        groups, _ = vavoo_live.directory('nf://vavoo/groups')
        selected_file = (params.get('file') or [''])[0]
        group = next((item for item in groups
                      if (parse_qs(urlparse(item['Path']).query).get('file') or [''])[0]
                      == selected_file), {})
        xbmcplugin.setProperty(handle, 'NF.VavooGroup', group.get('Title', 'TV-Programm'))
    for item in items:
        li = library.listitem(item)
        if item.get('EPGNext'):
            li.setProperty('NF.EPGNext', item['EPGNext'])
        if item.get('EPGProgress') is not None:
            li.setProperty('NF.EPGProgress', str(item['EPGProgress']))
        xbmcplugin.addDirectoryItem(handle, item.get('Path') or 'nf://empty', li,
                                    isFolder=bool(item.get('Folder')))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    if vavoo_mode == 'group':
        xbmc.executebuiltin('Container.SetViewMode(504)')
else:
    row = int(params.get('row', ['600'])[0])
    if not 600 <= row < 648:
        raise ValueError('Invalid widget row')
    page = (params.get('page') or [''])[0]
    filename = library.row_snapshot_name(page, row) if page else 'row-%s.json' % row
    snapshot = library.read(filename, [])
    is_continue = params.get('continue', ['0'])[0] == '1'
    is_top10 = params.get('top10', ['0'])[0] == '1'
    xbmcplugin.setContent(handle, 'videos')
    for rank, item in enumerate(snapshot, 1):
        li = library.listitem(item)
        if is_top10 and 1 <= rank <= 10 and not any(item.get(key) for key in ('Empty', 'Next', 'Back')):
            li.setProperty('NF.Rank', str(rank))
            li.setProperty('NF.RankArt', 'special://skin/media/nebelflix/rank-%d.png' % rank)
        if is_continue and item.get('Resume') and not item.get('Empty') and not item.get('Next'):
            # Keep the Kodi context-menu builtin short. Poster/plot URLs can
            # make a whole-item token excessively long on iOS/TV remotes.
            target = {key: item.get(key) for key in
                      ('Title', 'DBType', 'HybridMedia', 'HybridIdentity', 'Season', 'Episode')}
            token = base64.urlsafe_b64encode(json.dumps(target, ensure_ascii=False,
                        separators=(',', ':')).encode('utf-8')).decode('ascii').rstrip('=')
            action = 'RunScript(special://skin/resources/controller.py,remove_continue,%s)' % token
            li.addContextMenuItems([('Aus Weiterschauen entfernen', action)])
        xbmcplugin.addDirectoryItem(handle, item.get('Path') or 'nf://empty', li,
                                    isFolder=bool(item.get('Folder')))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
