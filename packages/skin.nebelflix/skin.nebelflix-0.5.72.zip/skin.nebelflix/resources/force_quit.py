# -*- coding: utf-8 -*-
"""Optional emergency Kodi exit for NebelFlix.

This intentionally bypasses Kodi's normal save/cleanup cycle. NEVER call it
from the automatic updater: use only after an explicit user confirmation.
"""
import os
import signal

import xbmc
import xbmcgui

HOME = xbmcgui.Window(10000)
UPDATE_MARKERS = (
    "Nebelkind.UpdateInProgress",
    "NebelFlix.UpdateInProgress",
    "NF.UpdateInProgress",
)


def updater_busy():
    return any(HOME.getProperty(name).strip().lower() in ("1", "true", "yes", "running", "installing")
               for name in UPDATE_MARKERS)


def run():
    dialog = xbmcgui.Dialog()
    if updater_busy():
        dialog.ok("NebelFlix Update", "Bitte warten: Eine Aktualisierung läuft. Kodi darf jetzt nicht erzwungen beendet werden.")
        return False
    if xbmc.getCondVisibility("System.Platform.IOS") or xbmc.getCondVisibility("System.Platform.TVOS"):
        dialog.ok("NebelFlix", "Auf iPhone und Apple TV ist das erzwungene Beenden deaktiviert. Bitte Kodi regulär verlassen.")
        return False
    if xbmc.Player().isPlaying():
        dialog.ok("NebelFlix", "Bitte zuerst die Wiedergabe beenden, damit Fortschritt und Wiedergabestand gespeichert werden.")
        return False
    if not dialog.yesno(
        "Kodi sofort beenden (Notfall)",
        "Kodi wird OHNE normales Speichern und Aufräumen geschlossen. Nicht während Updates oder Cache-Vorgängen benutzen. Wirklich beenden?",
        nolabel="Abbrechen", yeslabel="Sofort beenden",
    ):
        return False
    # Check again after the confirmation in case an updater began meanwhile.
    if updater_busy():
        dialog.ok("NebelFlix Update", "Ein Update wurde gestartet. Sofort beenden ist gesperrt.")
        return False
    xbmc.log("[NebelFlix] Emergency exit requested by user; clean shutdown bypassed", xbmc.LOGWARNING)
    if os.name == "nt":
        os._exit(1)
    else:
        os.kill(os.getpid(), signal.SIGKILL)
    return True


if __name__ == "__main__":
    run()
