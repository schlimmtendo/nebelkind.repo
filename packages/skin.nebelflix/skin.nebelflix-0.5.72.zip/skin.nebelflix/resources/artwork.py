"""Bounded background downloads of first-page widget artwork for TV devices."""
import hashlib
import os
from pathlib import Path
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor


class Artwork:
    def __init__(self, root):
        self.root = Path(root)
        self.pool = ThreadPoolExecutor(max_workers=2)
        self.jobs = {}
        self.attempted = set()
        self.failures = 0

    def filename(self, url):
        suffix = Path(urlparse(url).path).suffix.lower()
        if suffix not in ('.jpg', '.jpeg', '.png', '.webp'):
            suffix = '.jpg'
        return self.root / (hashlib.sha256(url.encode('utf-8')).hexdigest() + suffix)

    def local(self, url):
        if not str(url).startswith(('http://', 'https://')):
            return url
        path = self.filename(url)
        return str(path) if path.is_file() else url

    def prepare(self, items):
        for item in items:
            for field in ('Fanart', 'Poster', 'Clearlogo'):
                url = item.get(field) or ''
                if not url.startswith(('http://', 'https://')):
                    continue
                if self.local(url) != url or url in self.attempted:
                    continue
                self.attempted.add(url)
                self.jobs[url] = self.pool.submit(self.download, url)

    def download(self, url):
        import requests
        destination = self.filename(url)
        temporary = destination.with_suffix('.part')
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            with requests.get(url, timeout=(5, 12), stream=True) as response:
                response.raise_for_status()
                if not response.headers.get('Content-Type', '').lower().startswith('image/'):
                    return False
                size = 0
                with temporary.open('wb') as stream:
                    for chunk in response.iter_content(65536):
                        size += len(chunk)
                        if size > 4 * 1024 * 1024:
                            return False
                        stream.write(chunk)
                if size == 0:
                    return False
                os.replace(temporary, destination)
            return True
        except (OSError, requests.RequestException):
            return False
        finally:
            temporary.unlink(missing_ok=True)

    def tick(self):
        for url in [url for url, job in self.jobs.items() if job.done()]:
            if not self.jobs.pop(url).result():
                self.failures += 1

    def close(self):
        for job in self.jobs.values():
            job.cancel()
        self.pool.shutdown(wait=False)
