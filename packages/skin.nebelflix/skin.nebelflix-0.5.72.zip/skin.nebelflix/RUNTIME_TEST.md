# Nebelflix 0.5.1 – Prüfstand 31.10.2026

## Direkt in Kodi 21.3 geprüft

- Skin 0.5.1 wird geladen; kein Wechsel zu einem anderen Skin vorgenommen.
- Eigener Plugin-Einstieg im Skin wird von Kodi registriert und liefert die lokalen Widget-Snapshots. Ein vorläufiger Versuch mit direkt befüllten GUI-Listen wurde durch diesen nativen Provider ersetzt, nachdem Klicks dort nicht zuverlässig verarbeitet wurden.
- Startseite zeigt einen zufälligen Film oder eine Serie; Spotlight bleibt beim Navigieren in den Reihen unverändert.
- Explizit gestarteter Trailer „Forgotten Island“, TMDB movie:1465063: deutscher Treffer im Cache, Wiedergabe im Spotlight sichtbar, auf die Fläche zugeschnitten und mit runden Ecken. Log 01:50:42: Spotlight video visible. Herunterscrollen beendet die Wiedergabe; Player schließt um 01:51:42.
- Kein automatischer Trailer beim Start oder beim normalen Navigieren. Der überprüfte Start erfolgte ausschließlich nach Betätigung des Trailer-Buttons.
- Weiter-Kachel mit eigenem Icon: dieselbe Reihe wächst von 20 auf 38 unterschiedliche Titel. Log 01:59:14: Widget 600 ready: 38 items, next=True. Keine Add-on-Ansicht geöffnet.
- Detailansicht zeigt den tatsächlich angeklickten Titel „Wir – nur ein bisschen besser“, movie:1541477, statt des Spotlight-Titels.
- Der Nutzer hat den Editor anschließend selbst genutzt: Sprache wurde zu VoD, eigene Add-on-Quellen wurden zugeordnet, LiveTV wurde ergänzt und Mein Nebelflix verschoben. Diese Profilkonfiguration ist erhalten. Auch verschachtelte TV-Verzeichnisse wurden als Widget geladen (48 Einträge).
- Das Full-HD-Intro wurde neu gerendert und seine Standbilder visuell auf Lesbarkeit, Zusammenführen der Buchstaben und N-Zoom geprüft. Die erste Wiedergabe während des allerersten Renderlaufs traf auf eine unvollständige Datei; der Renderer schreibt nun zuerst eine separate Datei und kopiert nur das fertige Ergebnis. Beim späteren Kodi-Start wurde das Intro ohne diesen Dateifehler beendet.
- Alle Kodi-Systemzugänge bleiben in Einstellungen & Tools vorhanden; native Systemdateien sind durch die Validierung abgedeckt.

## Automatisierte Verhaltenstests

13 isolierte Tests in tools/test_runtime.py bestanden:

1. Leere/null Kodi-Favoritenliste lässt Hinzufügen und lokale Metadatenablage zu.
2. Mehr/Weiter/Nächste Seite wird als Navigation erkannt.
3. Langsame Reihe blockiert eine schnelle Reihe nicht; weitere Ergebnisse werden angehängt.
4. Verspätete Ergebnisse einer verlassenen Kategorie werden verworfen.
5. Ohne ausdrückliche Anfrage erfolgt keine Trailer-Auflösung und kein Autoplay.
6. Eine abgebrochene Trailer-Abfrage kann keine verspätete Wiedergabe freigeben.
7. Der Spotlight-Trailer übernimmt eine feste Momentaufnahme der ausgewählten Medienidentität.
8. Episoden erhalten unterschiedliche Fortschrittsidentitäten.
9. Modulares Layout wird gespeichert und unverändert gelesen.
10. Wiedergabefortschritt wird gespeichert, beim Fortsetzen angesprungen und ab 95 Prozent entfernt.
11. Lokale Widget-Snapshots erhalten die Weiter-Aktion.
12. Trailer-Auflösung akzeptiert ausschließlich den deutschen Trailer der richtigen Medienidentität, keine englischen Trailer, Teaser oder fremden Titel.
13. Quellfehler bieten gespeicherte Inhalte und eine Wiederholungsaktion an.

Zusätzlich: Python-Syntax aller eigenen Python-Dateien sowie 142 XML-/Playlist-Dokumente, Includes, Fonts, Texturen und Kontrollverknüpfungen geprüft.

## Grenzen der Live-Abdeckung

- „Meine Liste“ ist für den zuvor gemeldeten null-Fehler korrigiert und isoliert getestet. Eine erfolgreiche echte Favoritenänderung wurde im Abschlusslauf nicht nachgewiesen; der erste Bedienversuch landete wegen verzögerter UI-Aktionen in der Wiedergabeauswahl und wurde abgebrochen.
- Die erzwungene Posteransicht für Helper-Suchergebnisse und Folgeseiten ist implementiert, im Abschlusslauf aber nicht nochmals visuell durchgeklickt.
- Fortschritt und Fortsetzen sind mit simuliertem Kodi-Player getestet. Eine vollständige Filmwiedergabe über jeden installierten Wiedergabeanbieter ist nicht geprüft. Titel-/Identitätsrückmeldung und Seek-Fähigkeit des Anbieters sind erforderlich; Live-TV zählt nicht als fortsetzbarer Film.
- Am Nachmittag aktualisierte Kodi TMDB Helper automatisch von 6.19.5 auf 6.19.6. Während des Updates meldete Helper vorübergehend „Unknown addon id“; um 13:42:23 war 6.19.6 registriert, um 13:42:33 stand wieder ein Spotlight-Titel bereit. Der Skin enthält inzwischen einen Cache-Rückgriff für Quellfehler. Helper selbst wurde nicht bearbeitet.
- Kodi wurde während der Abschlussprüfung geschlossen. Der letzte Code- und Paketstand wurde danach statisch und mit den isolierten Verhaltenstests geprüft; nicht alle oben genannten Bedienwege wurden nach den letzten Randfallkorrekturen nochmals live wiederholt.

## Sicherung und Installation

Vorheriger Stand: My_Builds/Nebelflix/backups/skin.nebelflix-before-modular-0.4.0.zip.

Installierter Quellstand: addons/skin.nebelflix. Eigene Reiter, Listen und Fortschritte gehören zum aktiven Profil unter addon_data/skin.nebelflix und sind nicht Teil des verteilbaren Skin-ZIPs.

Der automatische Betrieb anderer Add-ons und das vom Nutzer durchgeführte Helper-Update sind nicht Teil der Skin-Änderungen.


## Nachprüfung und MultiTrailer, 01.11.2026 (0.5.2)

- Nachprüfung 31.10.: Batman-Suche und zweite Ergebnisseite live in Posteransicht bestätigt. Bleach (tv:30984) erfolgreich zu Meine Liste hinzugefügt, Metadaten gespeichert. LiveTV-Reiter zeigt die 14 Anbieterordner als Widgets.
- MultiTrailer-Code und öffentliche Python-Schnittstelle geprüft. Nebelflix nutzt MultiTrailer sources.from_tmdb und api.resolve_video_item; ausschließlich deutsche Trailer der festen Medien-ID, keine unscharfe Titelsuche und kein automatischer Start. Stream-Metadaten einschließlich DASH/HLS und HTTP-Headern bleiben erhalten. Der Skin kontrolliert Wiedergabefenster und Abbruch.
- Clearlogo-Ebene für normale, fokussierte und Top-10-Kacheln ergänzt, mit dezentem Schatten. Serienlogos werden auch aus tvshow.clearlogo übernommen. Ohne geliefertes Logo bleibt das Fanart sichtbar.
- 14 isolierte Verhaltenstests erfolgreich, einschließlich MultiTrailer-Sprachfilter und Übergabe adaptiver Streams im Fenstermodus. 142 XML-/Playlist-Dokumente validiert.
- Die frühere SQLite-Trailer-Auflösung ist durch MultiTrailer ersetzt; der alte Live-Trailertest belegt daher nicht automatisch die neue Integration.
- Live 01.11.: MultiTrailer für Clayface movie:1400940 erfolgreich aufgelöst (13:40:09), Video im Spotlight sichtbar (13:40:13). Beim Navigieren nach unten gestoppt, Fanart wieder sichtbar. Der Clip zeigt schwarze Balken im Banner; vollständige randlose Füllung ist für dieses Quellformat noch nicht bestätigt.
- Live: Clearlogos bei Welcome to Derry, Verity, Das Ende der Sterne, Forgotten Island und Clayface sichtbar, einschließlich Fokusrahmen. Bei Medien ohne geliefertes Clearlogo wird keines erfunden.
- Apokalypse Z – Neue Welt movie:1507696: kein passender deutscher Trailer gefunden, keine Ersatzwiedergabe gestartet.

## 0.5.3 – automatische Trailer und Serien
- Automatische Trailer sind für neue Profile standardmäßig deaktiviert. Der Schalter „Trailer im Spotlight automatisch starten“ aktiviert sie; manuelle Trailer bleiben verfügbar. Kein Start in ausgeblendeten Spotlights/Widgetreihen, Abbruch bei Verlassen; automatische Fehlsuchen bleiben still.
- Serien ohne deutschen TMDB-Trailer: MultiTrailer-Suche mit Serientitel, ausdrücklichem Deutsch/German-Marker, Titelabgleich und Ausschluss von Teasern/Fan-Edits. Suchtreffer sind titelbasiert und können daher nicht dieselbe Identitätssicherheit wie TMDB-verknüpfte Videos bieten.
- TMDB-Bewertungszeile aus Spotlight und Detailmetadaten entfernt.
- Fehlerkorrektur: erfolglose Auflösung beendet den Wartezustand jetzt ausdrücklich.
- 17 isolierte Verhaltenstests bestanden. Die zusätzliche Serien-Suche ist mit kontrollierten Treffern geprüft; noch kein erfolgreicher realer Serienstream nachgewiesen.

## 0.5.4 – Kategorienwechsel bei laufendem Trailer
- Logbefund: 13:53:43 Player geschlossen nach etwa 0,12 Sekunden; anschließend drei CCurlFile::Stat-Timeouts gegen 127.0.0.1:52080/mpd mit je 20 Sekunden. Kategorienwidgets erst 13:54:44 fortgesetzt. Gleicher Befund im alten Log.
- Erste Live-Korrektur auf lokale file-URI schlug fehl: InputStream Adaptive konnte die Datei auf Windows nicht öffnen. Diese Variante wurde zurückgenommen. MultiTrailer wird nun ohne DASH angefragt, Loopback-MPDs werden verworfen und nur direkte Streams verwendet, damit keine blockierenden lokalen HTTP-Stat-Aufrufe beim Kategorienwechsel erfolgen.
- Alter Logfehler PermissionError beim Lesen von row-602.json: begrenzte Wiederholung und Sicherung/Standardwert statt Absturz des Widget-Providers.
- Verweildauer wird beim Spotlight-Reset zurückgesetzt.
- 19 Verhaltenstests und 142 XML-Dokumente erfolgreich geprüft.

- 0.5.5 korrigiert die fehlgeschlagene lokale MPD-Umleitung nach Live-Prüfung. Direkte HLS/HTTP-Streams werden bevorzugt. 19 Regressionstests grün.


## 0.5.6 – Tastaturzugriff und Kachelformat
- Erste Widget-Reihe navigiert mit Hoch jetzt explizit zurück zur oberen Tab-Leiste (Control 200). Weitere Widget-Reihen gehen weiterhin zur vorherigen Reihe.
- Kachelbilder verwenden aspectratio=scale innerhalb der abgerundeten 16:9-Fläche, damit quadratische/hochformatige Add-on-Art nicht verzerrt wird.
- Live 01.11.2026: 0.5.6 geladen, LiveTV-Widgets sichtbar. Der obere Reiter konnte gewählt werden. Wegen leerer/noch ladender Anbieterreihen ließ sich der Hoch-Tastaturpfad auf einer tatsächlich fokussierten Add-on-Kachel nicht visuell abschließend bestätigen; die generierte Focus-Aufwärtsverbindung der ersten Zeile zeigt jetzt direkt auf Control 200.
