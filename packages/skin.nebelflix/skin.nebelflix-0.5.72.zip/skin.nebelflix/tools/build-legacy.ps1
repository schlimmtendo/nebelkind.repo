$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$utf8 = New-Object System.Text.UTF8Encoding($false)
function Save($name, $text) { [IO.File]::WriteAllText((Join-Path $root $name), $text, $utf8) }
function Esc($s) { [Security.SecurityElement]::Escape($s) }
function Image($x,$y,$w,$h,$texture,$extra='') { $tex=if($extra -match '<texture'){''}else{"<texture>$texture</texture>"}; "<control type=`"image`"><left>$x</left><top>$y</top><width>$w</width><height>$h</height>$tex$extra</control>" }
function Label($x,$y,$w,$h,$text,$font='NFBody',$extra='') { $color=if($extra -match '<textcolor>'){''}else{'<textcolor>FFFFFFFF</textcolor>'}; "<control type=`"label`"><left>$x</left><top>$y</top><width>$w</width><height>$h</height><font>$font</font>$color<label>$text</label>$extra</control>" }
Save 'addon.xml' @'
<?xml version="1.0" encoding="UTF-8"?>
<addon id="skin.nebelflix" version="0.1.0" name="Nebelflix" provider-name="Nebelflix / Estuary contributors">
 <requires><import addon="xbmc.gui" version="5.17.0"/></requires>
 <extension point="xbmc.gui.skin" debugging="false"><res width="1920" height="1080" aspect="16:9" default="true" folder="xml"/></extension>
 <extension point="xbmc.addon.metadata"><summary lang="de_DE">Filmische Startseite mit Overlay-Navigation und vollständigen Kodi-Werkzeugen.</summary><summary lang="en_GB">Cinematic home with overlay navigation and complete Kodi tools.</summary><description lang="de_DE">Eigene Nebelflix-Startseite. Kodi-Systemfenster basieren auf Estuary. Lokale Bibliotheksinhalte, keine Streamingdienste.</description><platform>all</platform><license>CC BY-SA 4.0, GPL-2.0-or-later</license><assets><icon>resources/nebelflix-icon.png</icon></assets></extension>
</addon>
'@
# Kodi reads resolution metadata from addon.xml, not from a separate skin.xml.
Save 'skin.xml' '<nebelflix name="Nebelflix" version="0.1.0" kodi="21" width="1920" height="1080"><note>Project metadata only; Kodi entry point is addon.xml.</note></nebelflix>'
Add-Type -AssemblyName System.Drawing
function Texture($name,$width,$height,$kind) {
 $bmp = New-Object Drawing.Bitmap($width,$height)
 for ($x=0; $x -lt $width; $x++) { for ($y=0; $y -lt $height; $y++) {
  $a=255; $r=20; $g=20; $b=20
  switch($kind) {
   'white' {$r=255;$g=255;$b=255}
   'red' {$r=229;$g=9;$b=20}
   'left' {$a=[int](255*[Math]::Pow(1-($x/($width-1)),1.7));$r=10;$g=10;$b=10}
   'bottom' {$a=[int](255*[Math]::Pow($y/($height-1),1.5));$r=20;$g=20;$b=20}
   'poster' {$r=[int](32+18*$y/$height);$g=[int](33+8*$y/$height);$b=[int](39+10*$y/$height)}
  }
  $bmp.SetPixel($x,$y,[Drawing.Color]::FromArgb($a,$r,$g,$b))
 }}
 $bmp.Save((Join-Path $root "media\nebelflix\$name.png"),[Drawing.Imaging.ImageFormat]::Png);$bmp.Dispose()
}
Texture 'white' 8 8 'white'; Texture 'red' 8 8 'red'; Texture 'background' 8 8 'background'
Texture 'fade-left' 512 8 'left'; Texture 'fade-bottom' 8 256 'bottom'; Texture 'poster' 64 96 'poster'
& (Join-Path $PSScriptRoot 'assets.ps1')
$fonts=[xml](Get-Content (Join-Path $root 'xml\Font.xml') -Raw)
foreach($set in $fonts.fonts.fontset) { foreach($old in @($set.SelectNodes("font[starts-with(name,'NF')]"))) {[void]$set.RemoveChild($old)}; foreach($f in @(@('NFBody',26,'NotoSans-Regular.ttf'),@('NFSmall',21,'NotoSans-Regular.ttf'),@('NFHeading',32,'NotoSans-Regular.ttf'),@('NFTitle',68,'NotoSans-Regular.ttf'),@('NFBrand',34,'NotoSans-Regular.ttf'),@('NFRank',150,'NotoSans-Regular.ttf'))) {
 $style=if($f[0] -in @('NFHeading','NFTitle','NFBrand','NFRank')){'<style>bold</style>'}else{''}
 $n=$fonts.CreateElement('font');$n.InnerXml="<name>$($f[0])</name><filename>$($f[2])</filename><size>$($f[1])</size>$style";[void]$set.AppendChild($n)
}}
$fonts.Save((Join-Path $root 'xml\Font.xml'))
$colors=[xml](Get-Content (Join-Path $root 'colors\defaults.xml') -Raw)
foreach($c in $colors.colors.color) { switch($c.name) { 'primary_background' {$c.InnerText='FF141414'} 'secondary_background' {$c.InnerText='FF202020'} 'dialog_tint' {$c.InnerText='FF181818'} 'button_focus' {$c.InnerText='FFE50914'} 'button_alt_focus' {$c.InnerText='80E50914'} 'selected' {$c.InnerText='FFFFFFFF'} } }
$colors.Save((Join-Path $root 'colors\defaults.xml'))
$inc=[xml](Get-Content (Join-Path $root 'xml\Includes.xml') -Raw)
if (!$inc.SelectSingleNode('/includes/include[@file="Includes_Nebelflix.xml"]')) { $node=$inc.CreateElement('include');$node.SetAttribute('file','Includes_Nebelflix.xml');[void]$inc.DocumentElement.AppendChild($node) };$inc.Save((Join-Path $root 'xml\Includes.xml'))
$rowDefs=@(
 @('Neu in deiner Filmwelt','videodb://recentlyaddedmovies/','true'),
 @('Weiterschauen für $INFO[System.ProfileName]','special://skin/playlists/nebelflix-continue.xsp','!Skin.HasSetting(NFHideContinue)'),
 @('Top 10 · Deine meistgesehenen Filme','special://skin/playlists/nebelflix-top10.xsp','!Skin.HasSetting(NFHideTop10)'),
 @('Serien entdecken','videodb://tvshows/titles/','true'),
 @('Neue Folgen für dich','videodb://recentlyaddedepisodes/','true')
)
$rowConditions=@{}; foreach($i in 0..($rowDefs.Count-1)) { $id=510+$i; $rowConditions[$id]="[$($rowDefs[$i][2]) + Integer.IsGreater(Container($id).NumItems,0)]" }
$heroReady=(@(510..514 | ForEach-Object { "[String.IsEqual(Window(Home).Property(NF.Row),$_) + Integer.IsGreater(Container($_).NumItems,0)]" }) -join ' | ')
$variables=''
foreach($prop in @('Title','Plot','Art(fanart)','Art(clearlogo)','FileNameAndPath','Year','Rating')) {
 $name=$prop.Replace('(','').Replace(')','').Replace('.','')
 $variables+="<variable name=`"NF$name`">"
 foreach($id in @(511,512,513,514)) {$variables+='<value condition="String.IsEqual(Window(Home).Property(NF.Row),'+ $id +')">$INFO[Container('+ $id +').ListItem.'+$prop+']</value>'}
 $variables+='<value>$INFO[Container(510).ListItem.'+$prop+']</value></variable>'
}
$logoMissing=(@(510..514 | ForEach-Object { "[String.IsEqual(Window(Home).Property(NF.Row),$_) + String.IsEmpty(Container($_).ListItem.Art(clearlogo))]" }) -join ' | ')
$heroFocus=''; foreach($id in 510..514) { $heroFocus+="<onclick condition=`"String.IsEqual(Window(Home).Property(NF.Row),$id)`">SetFocus($id)</onclick>" }
$nav=@(
 @('$INFO[System.ProfileName]','ActivateWindow(Profiles)','profile'),
 @('Suche','VideoLibrary.Search','search'),
 @('Startseite','SetFocus(100)','home'),
 @('Serien','ActivateWindow(Videos,videodb://tvshows/titles/,return)','series'),
 @('Filme','ActivateWindow(Videos,videodb://movies/titles/,return)','movies'),
 @('Meine Liste','ActivateWindow(FavouritesBrowser)','list'),
 @('Nebelflix Settings','ActivateWindow(1190)','settings'),
 @('Einstellungen & Tools','ActivateWindow(Settings)','settings'),
 @('Dateimanager','ActivateWindow(FileManager)','folder'),
 @('Profile','ActivateWindow(Profiles)','profile'),
 @('Medien / Quellen','ActivateWindow(MediaSettings)','media'),
 @('Add-ons','ActivateWindow(AddonBrowser)','addons'),
 @('System','ActivateWindow(SystemSettings)','settings'),
 @('Interface / Skin wechseln','ActivateWindow(InterfaceSettings)','settings'),
 @('Player','ActivateWindow(PlayerSettings)','play'),
 @('Dienste','ActivateWindow(ServiceSettings)','settings'),
 @('TV / PVR','ActivateWindow(PVRSettings)','series'),
 @('Musik','ActivateWindow(Music,return)','music'),
 @('Bilder','ActivateWindow(Pictures)','media'),
 @('Spiele','ActivateWindow(Games)','addons'),
 @('Videos / Dateien','ActivateWindow(Videos,files,return)','folder'),
 @('Systeminformationen','ActivateWindow(SystemInfo)','info'),
 @('Ereignisprotokoll','ActivateWindow(EventLog)','info'),
 @('Beenden / Energie','ActivateWindow(ShutdownMenu)','power')
)
$items=''; foreach($entry in $nav) {
 $actions='<onclick>'+(Esc $entry[1])+'</onclick>'
 if($entry[0] -eq 'Startseite') {$actions="<onclick condition=`"$heroReady`">SetFocus(100)</onclick><onclick condition=`"![$heroReady]`">SetFocus(102)</onclick>"}
 $items+='<item><label>'+(Esc $entry[0])+'</label><icon>nebelflix/icon-'+$entry[2]+'.png</icon>'+$actions+'</item>'
}
$sidebar=@"
<control type="group">
 <visible>Control.HasFocus(9000) | Skin.HasSetting(NFAlwaysExpand)</visible>
 <animation effect="fade" start="0" end="100" time="160">Visible</animation>
 $(Image 0 0 430 1080 'nebelflix/background.png')
 $(Image 430 0 150 1080 'nebelflix/fade-left.png')
</control>
$(Image 24 32 6 38 'nebelflix/red.png')
$(Label 45 27 330 50 'NEBELFLIX' 'NFBrand' '<visible>Control.HasFocus(9000) | Skin.HasSetting(NFAlwaysExpand)</visible><textcolor>FFE50914</textcolor>')
<control type="list" id="9000"><left>18</left><top>108</top><width>390</width><height>855</height><onright condition="$heroReady">SetFocus(100)</onright><onright condition="![$heroReady]">SetFocus(102)</onright><onback>SetFocus(9000)</onback><scrolltime>180</scrolltime>
<itemlayout width="390" height="57">
$(Image 0 0 62 53 'nebelflix/background.png')
$(Image 19 11 30 30 '$INFO[ListItem.Icon]' '<colordiffuse>FFE8E8E8</colordiffuse>')
$(Label 68 0 310 53 '$INFO[ListItem.Label]' 'NFSmall' '<visible>Control.HasFocus(9000) | Skin.HasSetting(NFAlwaysExpand)</visible>')
</itemlayout>
<focusedlayout width="390" height="57">
$(Image 0 0 390 53 'nebelflix/white.png')
$(Image 19 11 30 30 '$INFO[ListItem.Icon]' '<colordiffuse>FF141414</colordiffuse>')
$(Label 68 0 310 53 '$INFO[ListItem.Label]' 'NFSmall' '<textcolor>FF141414</textcolor>')
</focusedlayout><content>$items</content></control>
"@
$buttons='';$heroDown='';foreach($id in 510..514) {$heroDown+="<ondown condition=`"String.IsEqual(Window(Home).Property(NF.Row),$id)`">SetFocus($id)</ondown>"}
foreach($b in @(@(100,180,260,'Abspielen','play',101),@(101,460,270,'Mehr Info','info',100))) {
 $action=if($b[0] -eq 100){'Play'}else{'Info'}
 $click=$heroFocus+"<onclick>Action($action)</onclick>"
 $buttons+="<control type=`"button`" id=`"$($b[0])`"><left>$($b[1])</left><top>482</top><width>$($b[2])</width><height>64</height><font>NFBody</font><textcolor>FF141414</textcolor><focusedcolor>FF141414</focusedcolor><textoffsetx>60</textoffsetx><texturefocus>nebelflix/button-focus.png</texturefocus><texturenofocus>nebelflix/button.png</texturenofocus><label>$($b[3])</label>$click<onleft>9000</onleft><onright>$($b[5])</onright>$heroDown<onup>9000</onup><visible>$heroReady</visible></control>"
 $buttons+=Image ($b[1]+20) 502 24 24 "nebelflix/icon-$($b[4]).png" "<colordiffuse>FF141414</colordiffuse><visible>$heroReady</visible>"
}
$rows='';$i=0
foreach($r in $rowDefs) {
 $id=510+$i;$up='';$down='';$exclude=''
 for($candidate=$id-1;$candidate -ge 510;$candidate--) {$up+="<onup condition=`"$($rowConditions[$candidate])$exclude`">SetFocus($candidate)</onup>";$exclude+=" + !$($rowConditions[$candidate])"}
 $up+="<onup condition=`"true$exclude`">SetFocus(100)</onup>"
 $exclude=''
 for($candidate=$id+1;$candidate -le 514;$candidate++) {$down+="<ondown condition=`"$($rowConditions[$candidate])$exclude`">SetFocus($candidate)</ondown>";$exclude+=" + !$($rowConditions[$candidate])"}
 $down+="<ondown condition=`"true$exclude`">SetFocus(100)</ondown>"
 $layout=''
 foreach($focus in @($false,$true)) {
  $tag=if($focus){'focusedlayout'}else{'itemlayout'}
  $tileWidth=if($id -eq 512){300}else{225};$offset=if($id -eq 512){75}else{0}
  $layout+="<$tag width=`"$tileWidth`" height=`"332`">"
  if($id -eq 512){$layout+=Label 0 105 100 195 '$INFO[ListItem.CurrentItem]' 'NFRank' '<textcolor>FFBBBBBB</textcolor>'}
  if($focus) {$layout+="<control type=`"group`"><animation effect=`"zoom`" start=`"100`" end=`"104`" center=`"$($offset+112),155`" time=`"160`">Focus</animation>"; $layout+=Image (5+$offset) 5 210 300 'nebelflix/white.png'}
  $layout+=Image (10+$offset) 10 200 290 '$INFO[ListItem.Art(poster)]' '<aspectratio>scale</aspectratio><texture fallback="nebelflix/poster.png">$INFO[ListItem.Art(poster)]</texture>'
  $layout+=Label (12+$offset) 300 198 32 '$INFO[ListItem.Label]' 'NFSmall'
  if($focus){$layout+='</control>'};$layout+="</$tag>"
 }
 $rows+=@"
<control type="group"><width>1730</width><height>406</height><visible>$($rowConditions[$id])</visible>
$(Label 10 0 1650 52 $r[0] 'NFHeading')
<control type="list" id="$id"><left>0</left><top>60</top><width>1730</width><height>338</height><orientation>horizontal</orientation><onfocus>SetProperty(NF.Row,$id,Home)</onfocus><onleft>9000</onleft><onright>$id</onright>$up$down<onback>SetFocus(9000)</onback><scrolltime>220</scrolltime><preloaditems>3</preloaditems>$layout<content target="videos" limit="20">$($r[1])</content></control>
</control>
"@
 $i++
}
Save 'xml\Home.xml' @"
<?xml version="1.0" encoding="UTF-8"?>
<window><defaultcontrol always="true">9000</defaultcontrol><backgroundcolor>FF141414</backgroundcolor><onload>SetProperty(NF.Row,510,Home)</onload><controls>
$(Image 0 0 1920 1080 'nebelflix/background.png')
$(Image 480 0 1440 760 '$VAR[NFArtfanart]' '<aspectratio>scale</aspectratio><visible>!Skin.HasSetting(NFHideFanart)</visible>')
$(Image 380 0 1100 760 'nebelflix/fade-left.png')
$(Image 0 300 1920 470 'nebelflix/fade-bottom.png')
$(Label 180 96 900 44 'N  ·  DEIN KINO. DEIN ZUHAUSE.' 'NFSmall' '<textcolor>FFCCCCCC</textcolor>')
$(Image 180 158 650 155 '$VAR[NFArtclearlogo]' '<aspectratio align="left">keep</aspectratio><visible>!Skin.HasSetting(NFHideClearlogo)</visible>')
$(Label 180 170 1060 160 '$VAR[NFTitle]' 'NFTitle' "<visible>Skin.HasSetting(NFHideClearlogo) | $logoMissing</visible>")
$(Label 182 324 900 36 '$VAR[NFYear]    $VAR[NFRating]' 'NFSmall')
<control type="textbox"><left>182</left><top>373</top><width>820</width><height>91</height><font>NFBody</font><textcolor>FFE5E5E5</textcolor><label>`$VAR[NFPlot]</label></control>
$buttons
<control type="group"><visible>![$heroReady]</visible>
$(Label 180 185 1100 110 'Willkommen bei Nebelflix' 'NFTitle')
$(Label 182 338 1000 90 'Wähle einen Titel oder füge deine Medienbibliothek hinzu.' 'NFBody')
<control type="button" id="102"><left>180</left><top>482</top><width>480</width><height>64</height><label>Medien / Quellen öffnen</label><font>NFBody</font><texturefocus>nebelflix/red.png</texturefocus><texturenofocus>nebelflix/background.png</texturenofocus><onclick>ActivateWindow(MediaSettings)</onclick><onleft>9000</onleft><onright>9000</onright><onup>9000</onup>$( $exclude=''; foreach($candidate in 510..514) { "<ondown condition=`"$($rowConditions[$candidate])$exclude`">SetFocus($candidate)</ondown>"; $exclude+=" + !$($rowConditions[$candidate])" }; "<ondown condition=`"true$exclude`">SetFocus(9000)</ondown>" )</control>
</control>
<control type="grouplist" id="500"><left>170</left><top>610</top><width>1750</width><height>460</height><orientation>vertical</orientation><itemgap>12</itemgap><onleft>9000</onleft><onup>100</onup><ondown>510</ondown>$rows</control>
$sidebar
$(Label 1590 30 280 40 '$INFO[System.Time]' 'NFSmall' '<align>right</align>')
</controls></window>
"@
Save 'playlists\nebelflix-continue.xsp' @'
<smartplaylist type="movies"><name>Weiterschauen</name><match>all</match><rule field="inprogress" operator="true"/><limit>20</limit><order direction="descending">lastplayed</order></smartplaylist>
'@
Save 'playlists\nebelflix-top10.xsp' @'
<smartplaylist type="movies"><name>Deine Top 10</name><match>all</match><rule field="playcount" operator="greaterthan"><value>0</value></rule><limit>10</limit><order direction="descending">playcount</order></smartplaylist>
'@
$settings='';$j=0
foreach($setting in @(@('Fanart im Hero ausblenden','NFHideFanart'),@('Medientitel statt Clearlogo','NFHideClearlogo'),@('Navigation dauerhaft ausklappen','NFAlwaysExpand'),@('Weiterschauen ausblenden','NFHideContinue'),@('Top 10 ausblenden','NFHideTop10'))) {
 $id=1200+$j;$prev=if($j -eq 0){1204}else{$id-1};$next=if($j -eq 4){1200}else{$id+1};$top=260+$j*110
 $settings+="<control type=`"radiobutton`" id=`"$id`"><left>250</left><top>$top</top><width>1420</width><height>90</height><font>NFHeading</font><label>$($setting[0])</label><texturefocus>nebelflix/button-focus.png</texturefocus><texturenofocus>nebelflix/background.png</texturenofocus><textcolor>FFFFFFFF</textcolor><focusedcolor>FF141414</focusedcolor><textureradioonfocus>nebelflix/toggle-on.png</textureradioonfocus><textureradioonnofocus>nebelflix/toggle-on.png</textureradioonnofocus><textureradioofffocus>nebelflix/toggle-off.png</textureradioofffocus><textureradiooffnofocus>nebelflix/toggle-off.png</textureradiooffnofocus><radiowidth>58</radiowidth><radioheight>32</radioheight><onclick>Skin.ToggleSetting($($setting[1]))</onclick><selected>Skin.HasSetting($($setting[1]))</selected><onup>$prev</onup><ondown>$next</ondown><onback>PreviousMenu</onback></control>";$j++
}
$settingsContent=@"
$(Image 0 0 1920 1080 'nebelflix/background.png')
$(Image 170 110 7 95 'nebelflix/red.png')
$(Label 210 100 1500 100 'Nebelflix Settings' 'NFTitle')
$settings
$(Label 250 910 1450 60 'Zurück / Esc schließt dieses Menü. Änderungen werden automatisch gespeichert.' 'NFSmall')
"@
Save 'xml\Custom_1190_NebelflixSettings.xml' "<window id=`"1190`" type=`"window`"><defaultcontrol always=`"true`">1200</defaultcontrol><controls>$settingsContent</controls></window>"
Save 'xml\SkinSettings.xml' "<window><defaultcontrol always=`"true`">1200</defaultcontrol><controls>$settingsContent</controls></window>"
Save 'xml\Includes_Nebelflix.xml' "<includes>$variables</includes>"
$toolItems=''
foreach($entry in @($nav | Select-Object -Skip 6)) {$toolItems+='<item><label>'+(Esc $entry[0])+'</label><icon>nebelflix/icon-'+$entry[2]+'.png</icon><onclick>'+(Esc $entry[1])+'</onclick></item>'}
# Do not put the Settings launcher itself inside its own grid.
$toolItems=$toolItems.Replace('<item><label>Einstellungen &amp; Tools</label><icon>nebelflix/icon-settings.png</icon><onclick>ActivateWindow(Settings)</onclick></item>','')
$toolLayout=''
foreach($focus in @($false,$true)) {
 $tag=if($focus){'focusedlayout'}else{'itemlayout'};$color=if($focus){'FF141414'}else{'FFFFFFFF'}
 $texture=if($focus){'nebelflix/button-focus.png'}else{'nebelflix/poster.png'}
 $toolLayout+="<$tag width=`"390`" height=`"130`">"+(Image 0 0 372 112 $texture)+(Image 22 22 32 32 '$INFO[ListItem.Icon]' "<colordiffuse>$color</colordiffuse>")+(Label 22 60 332 40 '$INFO[ListItem.Label]' 'NFSmall' "<textcolor>$color</textcolor>")+"</$tag>"
}
Save 'xml\Settings.xml' @"
<window><defaultcontrol always="true">7000</defaultcontrol><backgroundcolor>FF141414</backgroundcolor><controls>
$(Image 0 0 1920 1080 'nebelflix/background.png')
$(Image 180 94 7 95 'nebelflix/red.png')
$(Label 215 82 1520 105 'Einstellungen &amp; Tools' 'NFTitle')
$(Label 215 190 1500 55 'NEBELFLIX   /   KODI' 'NFSmall' '<textcolor>FFBBBBBB</textcolor>')
<control type="panel" id="7000"><left>180</left><top>280</top><width>1560</width><height>650</height><orientation>vertical</orientation><scrolltime>180</scrolltime><onup>7001</onup><ondown>7001</ondown><onleft>7000</onleft><onright>7000</onright><onback>PreviousMenu</onback>$toolLayout<content>$toolItems</content></control>
<control type="button" id="7001"><left>180</left><top>957</top><width>330</width><height>64</height><label>Zurück</label><font>NFBody</font><textcolor>FFFFFFFF</textcolor><focusedcolor>FF141414</focusedcolor><texturefocus>nebelflix/button-focus.png</texturefocus><texturenofocus>nebelflix/background.png</texturenofocus><onclick>PreviousMenu</onclick><onup>7000</onup><ondown>7000</ondown><onleft>7000</onleft><onright>7000</onright></control>
</controls></window>
"@
Save 'README.md' @'
# Nebelflix 0.1.0 · Kodi 21 / Omega

Eigenes 1920×1080 Home-Layout mit dunklem Hero, Bibliotheks-Fanart, vorhandenen Clearlogos, horizontalen Posterreihen, Fokuszoom und Overlay-Navigation. Die vollständigen Systemfenster, Player-OSDs, Tastatur-, Profil-, Datei-, Add-on- und Einstellungsdialoge stammen aus dem lokal mitgelieferten Estuary 4.0.0 und wurden mitkopiert. Diese erste Version ist kein vollständig neu gezeichnetes Systemdialog-Design.

## Manuell auswählen
Kodi gegebenenfalls neu starten, damit das neue Add-on erkannt wird. Einstellungen → Interface → Skin → Nebelflix. Falls Kodi den manuell angelegten Ordner nicht registriert: My_Builds/Nebelflix/skin.nebelflix-0.1.0.zip über Add-ons → Aus ZIP-Datei installieren installieren. Der Build aktiviert den Skin nicht und verändert weder guisettings.xml noch die Add-on-Datenbank. Beim manuellen Skinwechsel zeigt Kodi gegebenenfalls seine übliche Bestätigungsabfrage; ohne Bestätigung fällt Kodi auf den vorherigen Skin zurück.

## Bedienung
Links am Anfang einer Posterreihe öffnet die Navigation; Rechts aus der Navigation führt zum Hero. Abwärts führt in die zuletzt ausgewählte Reihe; weitere Abwärtsbewegungen scrollen zwischen nicht leeren, sichtbaren Reihen. OK auf einem Poster verwendet Kodis konfigurierte Standardaktion für das Bibliotheksobjekt. Kontextmenü und Wiedergabeaktionen bleiben Kodi-Standard. Der Hero behält den Titel der zuletzt fokussierten Reihe; „Abspielen“ und „Mehr Info“ wirken auf diesen Titel. Suche ruft VideoLibrary.Search direkt auf. „Meine Liste“ öffnet Kodi-Favoriten. Die Navigation lässt sich vertikal bis zu allen Systemwerkzeugen durchscrollen.

Hero und fünf Reihen verwenden ausschließlich die lokale Kodi-Bibliothek: neue Filme, angefangene Filme, persönliche Top 10, Serien und neue Folgen. „Top 10“ sortiert die zehn meistgesehenen Filme dieses Kodi-Profils nach Wiedergabeanzahl und zeigt ihre Rangnummer. Es werden keine Netflix-Trends oder Netflix-Kataloge vorgetäuscht. Logos erscheinen nur bei vorhandener Art(clearlogo), sonst wird der Titel angezeigt. Für Episoden ohne Poster gibt es eine neutrale Ersatzgrafik. Leere Reihen werden ausgeblendet. Ohne ausgewählten Bibliothekstitel erscheint ein Einstieg zur Medienverwaltung. Keine automatischen Trailer und keine zusätzlichen Helper-Abhängigkeiten.

## Einstellungen
Navigation → Nebelflix Settings: Fanart, Clearlogo/Titel, ausgeklappte Navigation, Weiterschauen und Top 10. Dieselben Optionen öffnen sich auch über Kodis reguläres Fenster SkinSettings. Die eigene Übersicht „Einstellungen & Tools“ enthält Dateimanager, Profile, Medien, Add-ons, System, Interface, Player, Dienste, PVR und weitere Werkzeuge. Deren Detailfenster behalten die vollständigen Estuary-Steuerelemente mit dunkler und roter Farbgebung. Der manuelle Skinwechsel bleibt über Interface erreichbar.

## Status und Prüfung
tools/validate.ps1 prüft XML-Struktur, Include-Dateien, Fenster-ID-Konflikte, lokale Texturen, Fonts, Variablen und die Navigationsziele der eigenen Fenster. Das Ergebnis steht in validation.json. Kein Aktivierungs- oder Wiedergabetest im laufenden Kodi: der Benutzer möchte selbst umschalten. Die YouTube-Referenz war beim Erstellen nicht abrufbar; eine pixelgenaue Übereinstimmung ist nicht bestätigt. skin.xml dokumentiert nur Projektmetadaten; Kodi lädt addon.xml und xml/Home.xml. tools/build.ps1 generiert die eigenen Quellen und Assets neu; Änderungen an generierten Dateien deshalb im Buildskript pflegen.

## Herkunft / Lizenz
Eigene Home.xml, Settings.xml, SkinSettings.xml, Includes_Nebelflix.xml, Custom_1190_NebelflixSettings.xml, Playlist-Dateien und nebelflix-Texturen. Systemfenster, übrige Includes, Fonts, Übersetzungen und Basismedien: Estuary, phil65 / Ichabod Fletchman und weitere Mitwirkende, https://github.com/xbmc/skin.estuary/ . Original LICENSE.txt bleibt erhalten; CC BY-SA 4.0 und GPL Version 2 wie im ursprünglichen Add-on. Keine Netflix-Markenlogos oder Videobilder gebündelt.
'@
Write-Output 'Nebelflix source generated.'
