# Navigation NOTE (0.5.55): Use numeric destinations in onup/ondown tags.
# Kodi executes ALL matching non-numeric SetFocus actions; an unconditional
# fallback will override the correct widget-row focus. Do not regress.
"""Build Nebelflix's reference-based Kodi 21 interface; never activates a skin."""
from pathlib import Path
import math
import json
import xml.etree.ElementTree as ET
from urllib.parse import urlencode
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
MEDIA = ROOT / 'media' / 'nebelflix'
ROWS = range(600, 616)
SCRIPT = 'special://skin/resources/controller.py'
HERO_FOCUSABLE = ('String.IsEqual(Window(Home).Property(NF.HasHero),true) + '
                  '[!String.IsEmpty(Window(Home).Property(NF.TMDB)) | '
                  '!String.IsEmpty(Window(Home).Property(NF.Path))]')
NO_HERO_FOCUS = ('!String.IsEqual(Window(Home).Property(NF.HasHero),true) | '
                 '[String.IsEmpty(Window(Home).Property(NF.TMDB)) + '
                 'String.IsEmpty(Window(Home).Property(NF.Path))]')


def el(tag, text=None, **attrs):
    node = ET.Element(tag, {k: str(v) for k, v in attrs.items()})
    if text is not None:
        node.text = str(text)
    return node


def put(parent, tag, text=None, **attrs):
    node = el(tag, text, **attrs)
    parent.append(node)
    return node


def save(name, node):
    ET.indent(node, space='  ')
    ET.ElementTree(node).write(ROOT / name, encoding='utf-8', xml_declaration=True)


def control(parent, kind, x=0, y=0, w=0, h=0, cid=None, visible=None):
    node = put(parent, 'control', type=kind, **({'id': cid} if cid is not None else {}))
    for key, value in [('left', x), ('top', y), ('width', w), ('height', h)]:
        if value:
            put(node, key, value)
    if visible:
        put(node, 'visible', visible)
    return node


def image(parent, x, y, w, h, texture, visible=None, color=None, diffuse=None, fallback=None):
    node = control(parent, 'image', x, y, w, h, visible=visible)
    attrs = {k: v for k, v in [('diffuse', diffuse), ('fallback', fallback)] if v}
    put(node, 'texture', texture, **attrs)
    put(node, 'aspectratio', 'scale' if '$' in texture else 'stretch')
    if color:
        put(node, 'colordiffuse', color)
    return node


def label(parent, x, y, w, h, text, font='NFBody', color='FFFFFFFF', visible=None, align=None):
    node = control(parent, 'label', x, y, w, h, visible=visible)
    put(node, 'label', text)
    put(node, 'font', font)
    put(node, 'textcolor', color)
    put(node, 'aligny', 'center')
    if align:
        put(node, 'align', align)
    return node


def action(name):
    return f'RunScript({SCRIPT},{name})'


def button(parent, cid, x, y, w, h, text, clicks, up=None, down=None, left=None, right=None, visible=None, dark=False):
    node = control(parent, 'button', x, y, w, h, cid, visible)
    put(node, 'label', text)
    put(node, 'font', 'NFBody')
    put(node, 'textcolor', 'FFFFFFFF' if dark else 'FF141414')
    put(node, 'focusedcolor', 'FF141414')
    put(node, 'align', 'center')
    put(node, 'texturefocus', 'nebelflix/button-focus.png')
    put(node, 'texturenofocus', 'nebelflix/pill-dark.png' if dark else 'nebelflix/button.png')
    for click in ([clicks] if isinstance(clicks, str) else clicks):
        put(node, 'onclick', click)
    for tag, value in [('onup', up), ('ondown', down), ('onleft', left), ('onright', right)]:
        if value is not None:
            if value == action('first_row'):
                if cid in (100, 101, 102):
                    native_focus(node, tag, list(ROWS), 200)
                else:
                    put(node, tag, 100, condition=HERO_FOCUSABLE)
                    native_focus(node, tag, list(ROWS), 200, guard=NO_HERO_FOCUS)
            else:
                put(node, tag, value)
    return node


def native_focus(node, direction, candidates, fallback, guard=None):
    """Kodi FIRST-match numeric navigation: never emit multiple SetFocus calls."""
    for cid in candidates:
        condition = f'Control.IsVisible({cid})'
        if guard:
            condition += ' + [' + guard + ']'
        put(node, direction, str(cid), condition=condition)
    put(node, direction, str(fallback), condition=guard)


def window(default, wid=None, kind=None):
    node = el('window', **({'id': wid, 'type': kind} if wid else {}))
    put(node, 'defaultcontrol', default, always='true')
    put(node, 'backgroundcolor', 'FF141414')
    return node


def tmdb(info='popular', media='movie', **kwargs):
    return 'plugin://plugin.video.nebelflix.hybrid/?' + urlencode(dict(info=info, tmdb_type=media, **kwargs))


EMPTY = 'special://skin/playlists/nebelflix-empty.xsp'
CONTINUE = 'special://skin/playlists/nebelflix-continue.xsp'
EPISODES = 'special://skin/playlists/nebelflix-episodes.xsp'
PAGES = {
    'home': [
        ('Heutige Top-Auswahl für dich', tmdb('trending_day')),
        ('Serien, die gerade begeistern', tmdb('trending_week', 'tv')),
        ('Weiterschauen', CONTINUE),
        ('Top 10 · Beliebte Filme auf TMDB', tmdb()),
        ('Netflix-Serien entdecken', tmdb('discover', 'tv', with_networks='213', with_id='true')),
        ('Nervenkitzel & große Geschichten', tmdb('discover', with_genres='53', with_id='true')),
        ('Horrorfilme', tmdb('discover', with_genres='27', with_id='true')),
        ('Britische Serien', tmdb('discover', 'tv', with_origin_country='GB')),
    ],
    'movie': [
        ('Filme · Deine nächste große Geschichte', tmdb('trending_week')),
        ('Beliebt bei Filmfans', tmdb()), ('Weiterschauen', CONTINUE),
        ('Top 10 · Bestbewertete Filme', tmdb('top_rated')),
        ('Auf Netflix verfügbar · Deutschland', tmdb('discover', with_watch_providers='8', watch_region='DE', with_watch_monetization_types='flatrate', with_id='true')),
        ('Krimis', tmdb('discover', with_genres='80', with_id='true')),
        ('Horrorfilme', tmdb('discover', with_genres='27', with_id='true')),
        ('Komödien', tmdb('discover', with_genres='35', with_id='true')),
    ],
    'tv': [
        ('Serien · Geschichten, die bleiben', tmdb('trending_week', 'tv')),
        ('Beliebte Serien', tmdb('popular', 'tv')), ('Weiterschauen · Folgen', EPISODES),
        ('Top 10 · Bestbewertete Serien', tmdb('top_rated', 'tv')),
        ('Netflix-Serien entdecken', tmdb('discover', 'tv', with_networks='213', with_id='true')),
        ('Dramaserien', tmdb('discover', 'tv', with_genres='18', with_id='true')),
        ('Mystery-Serien', tmdb('discover', 'tv', with_genres='9648', with_id='true')),
        ('Britische Serien', tmdb('discover', 'tv', with_origin_country='GB')),
    ],
    'new': [
        ('Demnächst im Kino', tmdb('upcoming')),
        ('Jetzt im Kino', tmdb('now_playing')), ('Aktuell im TV', tmdb('on_the_air', 'tv')),
        ('Top 10 · Heute im Trend', tmdb('trending_day')),
        ('Heute ausgestrahlte Serien', tmdb('airing_today', 'tv')),
        ('Neue Filme in deiner Bibliothek', 'videodb://recentlyaddedmovies/'),
        ('Neue Folgen in deiner Bibliothek', 'videodb://recentlyaddedepisodes/'),
        ('Serien im Trend', tmdb('trending_day', 'tv')),
    ],
    'my': [
        ('Meine Liste', 'favourites://'), ('Weiterschauen · Filme', CONTINUE),
        ('Weiterschauen · Folgen', EPISODES),
        ('Neu in deiner Bibliothek', 'videodb://recentlyaddedmovies/'),
        ('Neue Folgen', 'videodb://recentlyaddedepisodes/'),
        ('', EMPTY), ('', EMPTY), ('', EMPTY),
    ],
}


def assets():
    MEDIA.mkdir(exist_ok=True)
    for name, size, radius, fill in [
        ('hero-mask', (1792, 800), 48, 'white'),
        ('tile-mask', (540, 304), 12, 'white'),
        ('pill-dark', (200, 80), 40, (58, 58, 58, 225)),
        ('pill', (200, 80), 40, (88, 88, 88, 235)),
        ('button', (320, 80), 40, (230, 230, 230, 255)),
        ('button-focus', (320, 80), 40, 'white'),
    ]:
        im = Image.new('RGBA', size)
        ImageDraw.Draw(im).rounded_rectangle((0, 0, size[0]-1, size[1]-1), radius, fill=fill)
        im.save(MEDIA / f'{name}.png')
    mask = Image.open(MEDIA / 'hero-mask.png').getchannel('A')
    corners = Image.new('RGBA', (1792, 800), (20, 20, 20, 255))
    corners.putalpha(mask.point(lambda a: 255-a))
    corners.save(MEDIA / 'hero-corners.png')
    im = Image.new('RGBA', (1080, 608), (28, 28, 32, 255))
    draw = ImageDraw.Draw(im)
    draw.rounded_rectangle((12, 12, 1068, 596), 40, outline=(70, 70, 80), width=3)
    draw.ellipse((400, 164, 680, 444), fill=(229, 9, 20))
    draw.line((478, 304, 600, 304), fill='white', width=16)
    draw.line((550, 250, 604, 304, 550, 358), fill='white', width=16, joint='curve')
    im.save(MEDIA / 'next.png')
    im = Image.new('RGBA', (556, 320))
    ImageDraw.Draw(im).rounded_rectangle((2, 2, 553, 317), 16, outline='white', width=6)
    im.save(MEDIA / 'tile-focus.png')
    im = Image.new('RGBA', (1792, 800))
    px = im.load()
    for y in range(800):
        bottom = min(0.94, max(0, (y - 300) / 500) ** 1.5 * 0.94)
        for x in range(1792):
            left = 0.69 * max(0, 1 - x/1250) ** 1.4
            alpha = int(255 * (1 - (1-left)*(1-bottom)))
            px[x, y] = (0, 0, 0, alpha)
    im.save(MEDIA / 'hero-shade.png')
    im = Image.new('RGBA', (540, 304))
    draw = ImageDraw.Draw(im)
    for y in range(304):
        a = int(180 * max(0, (y-110)/194))
        draw.line((0, y, 540, y), fill=(0, 0, 0, a))
    im.save(MEDIA / 'tile-shade.png')


def fonts():
    path = ROOT / 'xml/Font.xml'
    doc = ET.parse(path).getroot()
    for fontset in doc.findall('fontset'):
        for font in list(fontset):
            if (font.findtext('name') or '').startswith('NF'):
                fontset.remove(font)
        for name, size, bold in [('NFBody', 25, False), ('NFSmall', 20, False), ('NFNav', 23, False), ('NFHeading', 30, True), ('NFTitle', 66, True), ('NFDetailTitle', 48, True), ('NFBrand', 31, True), ('NFRank', 150, True), ('NFRankDouble', 90, True)]:
            font = put(fontset, 'font')
            put(font, 'name', name); put(font, 'filename', 'NotoSans-Regular.ttf'); put(font, 'size', size)
            if bold:
                put(font, 'style', 'bold')
    save('xml/Font.xml', doc)


def includes():
    doc = el('includes')
    for i in range(12):
        var = put(doc, 'variable', name=f'NFNavTexture{i}')
        put(var, 'value', 'nebelflix/pill.png', condition=f'String.IsEqual(Window(Home).Property(NF.TabSelected),{i})')
        put(var, 'value', '')
    first = put(doc, 'variable', name='NFSpotlightURL650')
    put(first, 'value', tmdb('trending_week', 'tv'), condition='String.IsEqual(Window(Home).Property(NF.Page),tv)')
    put(first, 'value', tmdb('trending_week', 'movie'))
    second = put(doc, 'variable', name='NFSpotlightURL651')
    put(second, 'value', EMPTY, condition='String.IsEqual(Window(Home).Property(NF.Page),movie) | String.IsEqual(Window(Home).Property(NF.Page),tv)')
    put(second, 'value', tmdb('trending_week', 'tv'))
    for offset, cid in enumerate(ROWS):
        for field, index in [('URL', 1), ('Heading', 0)]:
            var = put(doc, 'variable', name=f'NFRow{field}{cid}')
            for page in ['movie', 'tv', 'new', 'my'] if offset < 8 else []:
                put(var, 'value', PAGES[page][offset][index], condition=f'String.IsEqual(Window(Home).Property(NF.Page),{page})')
            put(var, 'value', PAGES['home'][offset][index] if offset < 8 else '')
    tile = put(doc, 'variable', name='NFTile')
    for art in ['landscape', 'fanart', 'tvshow.fanart', 'thumb', 'poster']:
        put(tile, 'value', f'$INFO[ListItem.Art({art})]', condition=f'!String.IsEmpty(ListItem.Art({art}))')
    put(tile, 'value', 'nebelflix/poster.png')
    save('xml/Includes_Nebelflix.xml', doc)
    base = ET.parse(ROOT / 'xml/Includes.xml').getroot()
    if not any(n.get('file') == 'Includes_Nebelflix.xml' for n in base.findall('include')):
        put(base, 'include', file='Includes_Nebelflix.xml')
    save('xml/Includes.xml', base)


def navigation(controls):
    image(controls, 0, 0, 1920, 120, 'nebelflix/background.png')
    label(controls, 64, 26, 190, 60, 'NEBELFLIX', 'NFBrand', 'FFE50914')
    tabs = control(controls, 'grouplist', 258, 34, 1340, 54, 220)
    put(tabs, 'orientation', 'horizontal'); put(tabs, 'itemgap', 12); put(tabs, 'scrolltime', 180)
    put(tabs, 'onleft', 212); put(tabs, 'onright', 210)
    tab_ids = [200+i if i < 6 else 230+i for i in range(12)]
    for idx in range(12):
        cid = 200+idx if idx < 6 else 230+idx
        node = button(tabs, cid, 0, 0, 205, 48, f'$INFO[Window(Home).Property(NF.TabLabel{idx})]', action(f'tab,{idx}'),
                      cid, action('first_row'), 212, 210, dark=True,
                      visible=f'!String.IsEmpty(Window(Home).Property(NF.TabLabel{idx}))')
        node.find('font').text = 'NFNav'
        node.find('texturenofocus').text = f'$VAR[NFNavTexture{idx}]'
        put(node, 'onfocus', 'SetProperty(NF.StopSpotlight,true,Home)')
        node.find('onleft').text = str(tab_ids[idx-1] if idx else 212)
        node.remove(node.find('onright'))
        native_focus(node, 'onright', tab_ids[idx+1:], 210)
    for cid, x, icon, click, left, right in [
        (210, 1630, 'search', action('search'), 205, 211),
        (211, 1710, 'settings', 'ActivateWindow(Settings)', 210, 212),
        (212, 1790, 'profile', 'ActivateWindow(1193)', 211, 200),
    ]:
        node = button(controls, cid, x, 32, 58, 54, '', click, cid, action('first_row'), left, right, dark=True)
        put(node, 'onfocus', 'SetProperty(NF.StopSpotlight,true,Home)')
        if cid == 210:
            node.remove(node.find('onleft'))
            native_focus(node, 'onleft', list(reversed(tab_ids)), 200)
        image(controls, x+14, 44, 30, 30, f'nebelflix/icon-{icon}.png')


def row(parent, cid):
    condition = f'!String.IsEmpty(Window(Home).Property(NF.RowHeading{cid}))'
    condition += f' + [!Skin.HasSetting(NFHideContinue) | !String.IsEqual(Window(Home).Property(NF.RowKind{cid}),continue)]'
    condition += f' + [!Skin.HasSetting(NFHideTop10) | !String.IsEqual(Window(Home).Property(NF.RowKind{cid}),top10)]'
    group = control(parent, 'group', w=1920, h=256, visible=condition)
    label(group, 64, 0, 1100, 48, f'$INFO[Window(Home).Property(NF.RowHeading{cid})]', 'NFHeading')
    label(group, 1200, 0, 650, 48, f'$INFO[Window(Home).Property(NF.RowState{cid})]', 'NFSmall', 'FFBBBBBB', align='right')
    node = control(group, 'list', 60, 44, 1800, 204, cid)
    put(node, 'orientation', 'horizontal'); put(node, 'scrolltime', 230); put(node, 'preloaditems', 2)
    put(node, 'onfocus', f'SetProperty(NF.Row,{cid},Home)')
    put(node, 'onleft', 200); put(node, 'onright', cid)
    # The first row has no previous widget: route Up to the top tab bar.
    if cid == 600:
        put(node, 'onup', 100, condition=HERO_FOCUSABLE)
        put(node, 'onup', 200, condition=NO_HERO_FOCUS)
    else:
        native_focus(node, 'onup', list(reversed(range(600,cid))), 200)
    native_focus(node, 'ondown', list(range(cid+1,616)), cid)
    put(node, 'onback', 200)
    put(node, 'onclick', action(f'details,{cid},$INFO[Container({cid}).ListItem.CurrentItem],$INFO[Window(Home).Property(NF.Page)]'))
    for rank, focused in [(False, False), (False, True), (True, False), (True, True)]:
        rank_condition = f'String.IsEqual(Window(Home).Property(NF.RowKind{cid}),top10)'
        layout = put(node, 'focusedlayout' if focused else 'itemlayout', width=350 if rank else 286,
                     height=204 if focused else 198,
                     condition=rank_condition if rank else '!' + rank_condition)
        group2 = control(layout, 'group')
        x = 70 if rank else 4
        if focused:
            put(group2, 'animation', 'Focus', effect='zoom', start='100', end='104', center=f'{x+135},90', time='150')
            image(group2, x-4, 4, 278, 160, 'nebelflix/tile-focus.png', visible=f'Control.HasFocus({cid})')
        if rank:
            image(group2, 0, 12, 130, 158, '$INFO[ListItem.Property(NF.RankArt)]').find('aspectratio').text = 'keep'
        tile_image = image(group2, x, 8, 270, 152, '$VAR[NFTile]',
                           visible='!ListItem.IsFolder', diffuse='nebelflix/tile-mask.png')
        tile_image.find('aspectratio').text = 'scale'
        folder_image = image(group2, x, 8, 270, 152, '$VAR[NFTile]',
                             visible='ListItem.IsFolder', diffuse='nebelflix/tile-mask.png')
        folder_image.find('aspectratio').text = 'keep'
        logo_visible = '!String.IsEmpty(ListItem.Art(clearlogo)) + !Skin.HasSetting(NFHideClearlogo)'
        image(group2, x, 8, 270, 152, 'nebelflix/hero-shade.png', visible=logo_visible, diffuse='nebelflix/tile-mask.png')
        image(group2, x+20, 94, 230, 55, '$INFO[ListItem.Art(clearlogo)]', visible=logo_visible).find('aspectratio').text = 'keep'
        fallback = label(group2, x+20, 105, 230, 42, '$INFO[ListItem.Label]', 'NFBody',
                         visible='String.IsEmpty(ListItem.Art(clearlogo)) + !Skin.HasSetting(NFHideClearlogo)',
                         align='center')
        put(fallback, 'shadowcolor', 'FF000000')


        if focused:
            label(group2, x, 160, 270, 22, '$INFO[ListItem.Label]', 'NFSmall', 'FFD5D5D5', visible=f'Control.HasFocus({cid})')
            label(group2, x, 183, 270, 20, '$INFO[ListItem.Property(NF.EPG)]', 'NFSmall', 'FFBDBDBD',
                  visible=f'Control.HasFocus({cid}) + !String.IsEmpty(ListItem.Property(NF.EPG))')
    # The provider returns only a local snapshot; remote fetching and pagination
    # happen independently in the controller, never in the GUI directory call.
    put(node, 'content', f'$INFO[Window(Home).Property(NF.RowURL{cid})]', target='videos')


def home():
    doc = window(100)
    put(doc, 'onload', 'SetProperty(NF.Page,home,Home)', condition='String.IsEmpty(Window(Home).Property(NF.Page))')
    put(doc, 'onload', 'Skin.Reset(TMDbHelper.Service)')
    put(doc, 'onload', 'SetProperty(NF.Bootstrapping,true,Home)')
    put(doc, 'onload', 'SetProperty(NF.ResetBootstrap,true,Home)')
    put(doc, 'onload', action('monitor'))
    controls = put(doc, 'controls')
    image(controls, 0, 0, 1920, 1080, 'nebelflix/background.png')
    # Invisible presentation only: providers stay alive independently of all
    # focusable category rows. Neither provider can receive navigation focus.
    feeds = control(controls, 'group', w=1, h=1)
    put(feeds, 'animation', 'Conditional', effect='fade', start='0', end='0', time='0', condition='true')
    for cid in (650, 651):
        feed = control(feeds, 'list', 0, 0, 1, 1, cid)
        put(feed, 'enable', 'false')
        for layout_type in ('itemlayout', 'focusedlayout'):
            layout = put(feed, layout_type, width=1, height=1)
            label(layout, 0, 0, 1, 1, '$INFO[ListItem.Label]', 'NFSmall')
        put(feed, 'content', f'$VAR[NFSpotlightURL{cid}]', target='videos', limit='8')
    body = control(controls, 'grouplist', 0, 120, 1920, 960, 500)
    put(body, 'orientation', 'vertical'); put(body, 'itemgap', 16); put(body, 'scrolltime', 300)
    put(body, 'onup', 200); put(body, 'onleft', 200)
    hero = control(body, 'group', w=1920, h=830, visible='String.IsEqual(Window(Home).Property(NF.HasHero),true)')
    image(hero, 64, 0, 1792, 800, '$INFO[Window(Home).Property(NF.Fanart)]', diffuse='nebelflix/hero-mask.png', fallback='nebelflix/poster.png')
    control(hero, 'videowindow', 64, 0, 1792, 800,
            visible='String.IsEqual(Window(Home).Property(NF.AutoPlaying),true)')
    image(hero, 64, 0, 1792, 800, 'nebelflix/hero-shade.png')
    image(hero, 64, 0, 1792, 800, 'nebelflix/hero-corners.png')
    logo = image(hero, 106, 310, 590, 180, '$INFO[Window(Home).Property(NF.Clearlogo)]', '!String.IsEmpty(Window(Home).Property(NF.Clearlogo)) + !Skin.HasSetting(NFHideClearlogo)')
    logo.find('aspectratio').text = 'keep'
    label(hero, 106, 350, 1000, 140, '$INFO[Window(Home).Property(NF.Title)]', 'NFTitle', visible='String.IsEmpty(Window(Home).Property(NF.Clearlogo)) | Skin.HasSetting(NFHideClearlogo)')
    label(hero, 108, 510, 1200, 40, '$INFO[Window(Home).Property(NF.Meta)]', 'NFSmall', 'FFE5E5E5')
    plot = control(hero, 'textbox', 108, 565, 820, 96)
    put(plot, 'font', 'NFBody'); put(plot, 'textcolor', 'FFFFFFFF'); put(plot, 'label', '$INFO[Window(Home).Property(NF.Plot)]')
    button(hero, 100, 108, 700, 225, 62, 'Abspielen', action('play'), 200, action('first_row'), 200, 101)
    more_info = button(hero, 101, 348, 700, 242, 62, 'Weitere Infos', action('details'), 200, action('first_row'), 100, 102, dark=True)
    more_info.find('onright').set('condition', '!String.IsEmpty(Window(Home).Property(NF.TMDB))')
    right_home = el('onright', '100', condition='String.IsEmpty(Window(Home).Property(NF.TMDB))')
    more_info.append(right_home)
    button(hero, 102, 605, 700, 170, 62, 'Trailer', action('trailer'), 200, action('first_row'), 101, 100, dark=True)
    put(hero.find("control[@id='102']"), 'visible', '!String.IsEmpty(Window(Home).Property(NF.TMDB))')
    for cid in (100, 101, 102):
        put(hero.find(f"control[@id='{cid}']"), 'enable', '!String.IsEmpty(Window(Home).Property(NF.TMDB)) | !String.IsEmpty(Window(Home).Property(NF.Path))')
    label(hero, 108, 350, 1200, 100, 'Deine Auswahl wird geladen …', 'NFHeading', visible='String.IsEmpty(Window(Home).Property(NF.TMDB)) + String.IsEmpty(Window(Home).Property(NF.Path))')
    label(hero, 106, 30, 900, 48, '$INFO[Window(Home).Property(NF.SpotlightCaption)]', 'NFSmall', 'FFCCCCCC')
    for cid in ROWS:
        row(body, cid)
    navigation(controls)
    intro = control(controls, 'group', visible='String.IsEqual(Window(Home).Property(NF.IntroActive),true)')
    image(intro, 0, 0, 1920, 1080, 'nebelflix/background.png')
    control(intro, 'videowindow', 0, 0, 1920, 1080)
    button(intro, 1999, 1530, 975, 320, 60, 'Intro überspringen', action('skip_intro'), 1999, 1999, 1999, 1999, dark=True)
    save('xml/Home.xml', doc)


TOOLS = [
    ('Nebelflix Settings', 'ActivateWindow(1190)', 'settings'),
    ('Dateimanager', 'ActivateWindow(FileManager)', 'folder'), ('Profile', 'ActivateWindow(Profiles)', 'profile'),
    ('Medien / Quellen', 'ActivateWindow(MediaSettings)', 'media'), ('Add-ons', 'ActivateWindow(AddonBrowser)', 'addons'),
    ('System', 'ActivateWindow(SystemSettings)', 'settings'), ('Interface / Skin wechseln', 'ActivateWindow(InterfaceSettings)', 'settings'),
    ('Player', 'ActivateWindow(PlayerSettings)', 'play'), ('Dienste', 'ActivateWindow(ServiceSettings)', 'settings'),
    ('TV / PVR', 'ActivateWindow(PVRSettings)', 'series'), ('Musik', 'ActivateWindow(Music,return)', 'music'),
    ('Bilder', 'ActivateWindow(Pictures)', 'media'), ('Videos / Dateien', 'ActivateWindow(Videos,files,return)', 'folder'),
    ('Nebelflix Hybrid', 'ActivateWindow(Videos,plugin://plugin.video.nebelflix.hybrid/,return)', 'movies'),
    ('Nebelflix Hybrid konfigurieren', 'Addon.OpenSettings(plugin.video.nebelflix.hybrid)', 'settings'),
    ('Systeminformationen', 'ActivateWindow(SystemInfo)', 'info'), ('Ereignisprotokoll', 'ActivateWindow(EventLog)', 'info'),
    ('Skin neu laden', action('reload'), 'settings'), ('Laufzeitprüfung', action('diagnostic'), 'info'),
    ('Beenden / Energie', 'ActivateWindow(ShutdownMenu)', 'power'),
]


def tools():
    doc = window(7000)
    controls = put(doc, 'controls')
    image(controls, 0, 0, 1920, 1080, 'nebelflix/background.png')
    label(controls, 170, 80, 1590, 100, 'Einstellungen & Tools', 'NFTitle')
    label(controls, 170, 185, 1590, 60, 'NEBELFLIX  /  KODI', 'NFSmall', 'FFB5B5B5')
    panel = control(controls, 'panel', 170, 280, 1580, 650, 7000)
    put(panel, 'orientation', 'vertical'); put(panel, 'onup', 7001); put(panel, 'ondown', 7001)
    put(panel, 'onleft', 7000); put(panel, 'onright', 7000); put(panel, 'onback', 'PreviousMenu')
    for focused in [False, True]:
        layout = put(panel, 'focusedlayout' if focused else 'itemlayout', width=395, height=128)
        color = 'FF141414' if focused else 'FFFFFFFF'
        image(layout, 0, 0, 375, 112, 'nebelflix/button-focus.png' if focused else 'nebelflix/poster.png')
        image(layout, 22, 18, 30, 30, '$INFO[ListItem.Icon]', color=color)
        label(layout, 22, 60, 332, 40, '$INFO[ListItem.Label]', 'NFSmall', color)
    content = put(panel, 'content')
    for title, click, icon in TOOLS:
        item = put(content, 'item'); put(item, 'label', title); put(item, 'onclick', click); put(item, 'icon', f'nebelflix/icon-{icon}.png')
    button(controls, 7001, 170, 960, 300, 64, 'Zurück', 'PreviousMenu', 7000, 7000, 7000, 7000, dark=True)
    save('xml/Settings.xml', doc)


def settings():
    options = [('Intro beim Kodi-Start überspringen', 'NFDisableIntro', False),
               ('Medientitel statt Clearlogo', 'NFHideClearlogo', False),
               ('Weiterschauen ausblenden', 'NFHideContinue', False),
               ('Top 10 ausblenden', 'NFHideTop10', False),
               ('Trailer im Spotlight automatisch starten', 'NFDisableAutoTrailer', True)]
    for name, custom in [('xml/SkinSettings.xml', False), ('xml/Custom_1190_NebelflixSettings.xml', True)]:
        doc = window(1200, 1190 if custom else None, 'window' if custom else None)
        controls = put(doc, 'controls')
        image(controls, 0, 0, 1920, 1080, 'nebelflix/background.png')
        label(controls, 190, 90, 1500, 100, 'Nebelflix Settings', 'NFTitle')
        for index, (title, setting, inverse) in enumerate(options):
            cid = 1200+index
            node = control(controls, 'radiobutton', 230, 225+index*88, 1460, 80, cid)
            put(node, 'label', title); put(node, 'font', 'NFHeading')
            put(node, 'texturefocus', 'nebelflix/button-focus.png', border='14'); put(node, 'texturenofocus', 'nebelflix/background.png')
            put(node, 'textcolor', 'FFFFFFFF'); put(node, 'focusedcolor', 'FF141414')
            for field, state in [('textureradioonfocus','on'),('textureradioonnofocus','on'),('textureradioofffocus','off'),('textureradiooffnofocus','off')]:
                put(node, field, f'nebelflix/toggle-{state}.png')
            put(node, 'radiowidth', 58); put(node, 'radioheight', 32)
            put(node, 'selected', ('!' if inverse else '')+f'Skin.HasSetting({setting})')
            put(node, 'onclick', f'Skin.ToggleSetting({setting})')
            put(node, 'onup', cid-1 if index else 1210); put(node, 'ondown', cid+1 if index <len(options)-1 else 1210)
            put(node, 'onback', 'PreviousMenu')
        button(controls, 1210, 230, 820, 420, 64, 'Nebelflix-Intro ansehen', action('intro'), 1200+len(options)-1, 1211, 1211, 1211, dark=True)
        button(controls, 1211, 680, 820, 420, 64, 'Nebelflix Hybrid einstellen', 'Addon.OpenSettings(plugin.video.nebelflix.hybrid)', 1200+len(options)-1, 1200, 1210, 1210, dark=True)
        button(controls, 1212, 230, 690, 870, 64, 'Reiter & Widgets verwalten', action('edit_layout'), 1204, 1210, 1212, 1212, dark=True)
        for node in controls.findall("control[@id='1204']/ondown"):
            node.text = '1212'
        label(controls, 230, 765, 1460, 42, 'Automatische Trailer starten nach 3 Sekunden und stoppen beim Verlassen.', 'NFSmall', 'FFBBBBBB')
        label(controls, 230, 960, 1500, 48, 'Esc / Zurück schließt dieses Menü. Einstellungen werden gespeichert.', 'NFSmall', 'FFB5B5B5')
        save(name, doc)


def details():
    doc = window(1300, 1191, 'dialog')
    put(doc, 'onunload', 'ClearProperty(NF.DetailOpen,Home)')
    controls = put(doc, 'controls')
    image(controls, 0, 0, 1920, 1080, 'nebelflix/background.png', color='DFFFFFFF')
    image(controls, 250, 40, 1420, 1000, 'nebelflix/background.png')
    image(controls, 250, 40, 1420, 670, '$INFO[Window(Home).Property(NF.Fanart)]')
    image(controls, 250, 40, 1420, 670, 'nebelflix/hero-shade.png')
    image(controls, 310, 310, 750, 155, '$INFO[Window(Home).Property(NF.Clearlogo)]', '!String.IsEmpty(Window(Home).Property(NF.Clearlogo)) + !Skin.HasSetting(NFHideClearlogo)').find('aspectratio').text = 'keep'
    title = control(controls, 'textbox', 310, 320, 1210, 145, visible='String.IsEmpty(Window(Home).Property(NF.Clearlogo)) | Skin.HasSetting(NFHideClearlogo)')
    put(title, 'font', 'NFDetailTitle'); put(title, 'label', '$INFO[Window(Home).Property(NF.Title)]'); put(title, 'textcolor', 'FFFFFFFF')
    label(controls, 310, 480, 1210, 42, '$INFO[Window(Home).Property(NF.Meta)]', 'NFBody', 'FFDDDDDD')
    button(controls, 1300, 310, 550, 270, 65, 'Abspielen', action('play,detail'), 1304, 1305, 1304, 1301)
    trailer = button(controls, 1301, 600, 550, 220, 65, 'Trailer', action('trailer,detail'), 1304, 1305, 1300, 1302, dark=True)
    put(trailer, 'visible', '!String.IsEmpty(Window(Home).Property(NFD.TMDB))')
    button(controls, 1302, 840, 550, 270, 65, '$INFO[Window(Home).Property(NF.MyListLabel)]', action('mylist,detail'), 1304, 1305, 1301, 1303, dark=True)
    button(controls, 1303, 1130, 550, 390, 65, 'In Nebelflix Hybrid öffnen', action('browse,detail'), 1304, 1305, 1302, 1304, dark=True)
    button(controls, 1304, 1560, 70, 65, 60, '×', 'Dialog.Close(1191)', 1300, 1300, 1303, 1300, dark=True)
    plot = control(controls, 'textbox', 310, 660, 1250, 280, 1305)
    put(plot, 'font', 'NFBody'); put(plot, 'textcolor', 'FFFFFFFF'); put(plot, 'label', '$INFO[Window(Home).Property(NF.Plot)]')
    put(plot, 'onup', 1300); put(plot, 'ondown', 1300); put(plot, 'onleft', 1300); put(plot, 'onright', 1300)
    label(controls, 310, 962, 1200, 40, '$INFO[Window(Home).Property(NF.Genres)]', 'NFSmall', 'FFBBBBBB')
    for node in doc.iter():
        if node.text:
            node.text = node.text.replace('Window(Home).Property(NF.', 'Window(Home).Property(NFD.')
    save('xml/Custom_1191_Details.xml', doc)


def menus():
    for wid, title, choices in [
        (1192, 'Nach Sprachen durchsuchen', [('Deutsch', 'de'), ('Englisch', 'en'), ('Koreanisch', 'ko'), ('Spanisch', 'es'), ('Japanisch', 'ja')]),
        (1193, 'Mein Nebelflix', [('Meine Liste', 'list'), ('Nebelflix Settings', 'skin'), ('Kodi-Einstellungen & Tools', 'tools'), ('Profile verwalten', 'profiles')]),
    ]:
        doc = window(1400, wid, 'dialog')
        controls = put(doc, 'controls')
        image(controls, 0, 0, 1920, 1080, 'nebelflix/background.png', color='EFFFFFFF')
        label(controls, 380, 170, 1200, 110, title, 'NFTitle')
        for index, (text, value) in enumerate(choices):
            if wid == 1192:
                clicks=['Dialog.Close(1192)', f'ActivateWindow(Videos,"{tmdb("discover", with_original_language=value)}",return)']
            else:
                clicks=['Dialog.Close(1193)', {'list':'ActivateWindow(FavouritesBrowser)', 'skin':'ActivateWindow(1190)', 'tools':'ActivateWindow(Settings)', 'profiles':'ActivateWindow(Profiles)'}[value]]
            button(controls, 1400+index, 400, 320+index*110, 1120, 86, text, clicks,
                   1400+(index-1)%len(choices), 1400+(index+1)%len(choices), 1400+index, 1400+index, dark=True)
        save(f'xml/Custom_{wid}_Menu.xml', doc)


def metadata():
    doc = ET.parse(ROOT / 'addon.xml').getroot()
    doc.set('version','0.5.38')
    requires=doc.find('requires')
    if not any(n.get('addon')=='xbmc.python' for n in requires):
        put(requires, 'import', addon='xbmc.python', version='3.0.0')
    if doc.find("extension[@point='xbmc.python.pluginsource']") is None:
        provider = put(doc, 'extension', point='xbmc.python.pluginsource', library='resources/provider.py')
        put(provider, 'provides', 'video')
    if not any(n.get('addon')=='plugin.video.nebelflix.hybrid' for n in requires):
        put(requires, 'import', addon='plugin.video.nebelflix.hybrid', version='2026.11.07.2')
    if not any(n.get('addon')=='plugin.video.multitrailer' for n in requires):
        put(requires, 'import', addon='plugin.video.multitrailer')
    desc=doc.find("extension[@point='xbmc.addon.metadata']/description")
    desc.text='Nebelflix mit modularen Reitern und Widgets, manuellen deutschen Spotlight-Trailern, Weiterschauen, Meine Liste und eigenem Intro. Vollständige Kodi-Systemzugänge ohne Games.'
    save('addon.xml',doc)
    skin=el('nebelflix',name='Nebelflix',version='0.5.39',kodi='21',width='1920',height='1080')
    put(skin,'note','Project metadata only. Kodi loads addon.xml, xml/Home.xml and the controller.')
    save('skin.xml',skin)
    doc = window(0)
    doc.remove(doc.find('defaultcontrol'))
    put(doc,'onload','ReplaceWindow(Home)')
    put(doc,'controls')
    save('xml/Startup.xml',doc)
    for name, media, rule in [('nebelflix-empty.xsp','movies',('title','is','__NEBELFLIX_EMPTY_8F912__')),
                              ('nebelflix-episodes.xsp','episodes',('inprogress','true',None))]:
        doc=el('smartplaylist',type=media);put(doc,'name','Nebelflix');put(doc,'match','all')
        r=put(doc,'rule',field=rule[0],operator=rule[1])
        if rule[2]:put(r,'value',rule[2])
        put(doc,'limit',16);put(doc,'order','lastplayed',direction='descending')
        save('playlists/'+name,doc)


def default_layout():
    tabs = []
    for page, title in [('home', 'Startseite'), ('tv', 'Serien'), ('movie', 'Filme'), ('new', 'Neu und beliebt'), ('my', 'Mein Nebelflix')]:
        rows = []
        for heading, path in PAGES[page]:
            if not heading:
                continue
            if path == CONTINUE:
                path = 'nf://continue/all' if page == 'home' else 'nf://continue/movie'
            elif path == EPISODES:
                path = 'nf://continue/tv'
            elif path == 'favourites://':
                path = 'nf://mylist'
            rows.append({'label': heading, 'path': path})
        tabs.append({'id': page, 'label': title, 'rows': rows})
    tabs.append({'id': 'language', 'label': 'Sprache', 'rows': [
        {'label': 'Deutschsprachige Filme', 'path': tmdb('discover', with_original_language='de')},
        {'label': 'Deutschsprachige Serien', 'path': tmdb('discover', 'tv', with_original_language='de')}]})
    tabs.append({'id': 'live_tv', 'label': 'LiveTV', 'rows': [
        {'label': 'Vavoo TV Gruppen', 'path': 'nf://vavoo/groups'},
        {'label': 'Live', 'path': 'plugin://plugin.video.titansmarttvplus/'}]})
    # Retain curated Nebelflix/Hybrid genre and streaming-widget tabs when rebuilding.
    existing_layout = ROOT/'resources/default-layout.json'
    if existing_layout.exists():
        try:
            existing = json.loads(existing_layout.read_text(encoding='utf-8'))
            for entry in existing.get('tabs', []):
                if entry.get('id') in ('genres', 'streaming') and not any(
                        t['id'] == entry['id'] for t in tabs):
                    tabs.append(entry)
        except (ValueError, OSError):
            pass
    (ROOT/'resources/default-layout.json').write_text(json.dumps({'version': 1, 'tabs': tabs}, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    default_layout()
    assets();fonts();includes();home();tools();settings();details();menus();metadata()
    print('Nebelflix 0.5.39 generated: cached widget loading, responsive Live TV channel details, spotlight navigation.')
