"""Regression tests for Nebelflix 0.5.52. Run without Kodi."""
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock

ROOT = Path(__file__).resolve().parents[1]
# Reuse the existing lightweight Kodi stubs without running the old tests.
spec = importlib.util.spec_from_file_location('nebel_test_stubs', ROOT / 'tools/test_runtime.py')
bootstrap = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = bootstrap
spec.loader.exec_module(bootstrap)
library = bootstrap.library
controller = bootstrap.controller


class FixTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        library.ROOT = Path(self.temp.name)
        bootstrap.properties.clear()
        self.notification = controller.notification
        controller.notification = lambda text: None
        self.orig_rpc = controller.rpc
        self.orig_directory = library.directory
        self.win = bootstrap.Window()

    def tearDown(self):
        controller.notification = self.notification
        controller.rpc = self.orig_rpc
        library.directory = self.orig_directory
        self.temp.cleanup()

    def test_add_remove_does_not_require_kodi_favourites(self):
        calls = []
        def fake_rpc(method, params):
            calls.append(method)
            raise RuntimeError('Kodi favourites not writable')
        controller.rpc = fake_rpc
        item = {'Title':'The Dark Knight','Type':'movie','TMDB':'155',
                'DBType':'movie','Plot':'Beschreibung'}
        self.assertTrue(controller.mylist(item))
        self.assertEqual(library.read('mylist.json', []),
                         [dict(item, Path='plugin://plugin.video.nebelflix.hybrid/?info=details&tmdb_type=movie&tmdb_id=155')])
        items, _ = library.directory(fake_rpc,'nf://mylist')
        self.assertEqual(len(items),1)
        self.assertTrue(controller.mylist(item))
        self.assertEqual(library.read('mylist.json',[]), [])
        self.assertEqual(library.directory(fake_rpc,'nf://mylist')[0], [])
        self.assertFalse(any(name == 'Favourites.AddFavourite' for name in calls))

    def test_existing_empty_list_does_not_reimport_favourites(self):
        library.write('mylist.json',[])
        calls=[]
        def rpc(method,params):
            calls.append(method)
            return {'favourites':[{'title':'Ghost','type':'window',
                        'windowparameter':'plugin://plugin.video.nebelflix.hybrid/?info=details&tmdb_type=movie&tmdb_id=155'}]}
        self.assertEqual(library.read_mylist(rpc), [])
        self.assertEqual(calls,[])

    def test_legacy_import_runs_once_only_for_nebelflix(self):
        calls=[]
        def rpc(method,params):
            calls.append(method)
            return {'favourites':[
                {'title':'Legacy Film', 'type':'window', 'windowparameter':'plugin://plugin.video.nebelflix.hybrid/?info=details&tmdb_type=movie&tmdb_id=77'},
                {'title':'Other App', 'type':'window', 'windowparameter':'plugin://plugin.video.other/?info=details&tmdb_type=movie&tmdb_id=80'}]}
        self.assertEqual([x['Title'] for x in library.read_mylist(rpc)],['Legacy Film'])
        self.assertEqual(library.read('mylist-v2-migrated.json',{}).get('imported'),1)
        library.write('mylist.json',[])
        self.assertEqual(library.read_mylist(rpc),[])
        self.assertEqual(len(calls),1)

    def test_episode_identity_is_specific(self):
        first={'Type':'tv','TMDB':'700','DBType':'episode','Season':'1','Episode':'1'}
        second=dict(first,Episode='2')
        self.assertNotEqual(library.mylist_identity(first),library.mylist_identity(second))

    def test_progress_segments_follow_count(self):
        self.assertEqual(controller.publish_preload_progress(72,101),71)
        self.assertEqual(controller.prop('PreloadPercent'),'71')
        self.assertEqual(controller.prop('PreloadCount'),'72 / 101 Reihen')
        self.assertEqual([controller.prop('PreloadFill%02d'%i) for i in range(1,21)].count('true'),14)
        controller.publish_preload_progress(101,101)
        self.assertEqual([controller.prop('PreloadFill%02d'%i) for i in range(1,21)].count('true'),20)
        controller.publish_preload_progress(0,101)
        self.assertEqual([controller.prop('PreloadFill%02d'%i) for i in range(1,21)].count('true'),0)

    def test_mylist_cache_is_immediately_stale(self):
        self.assertEqual(library.widget_cache_ttl('nf://mylist'),0)
        w=library.Widgets(lambda *args:None,self.win,controller.prop)
        w.cache={'nf://mylist':{'items':[{'Title':'Ghost'}], 'time':99999999999, 'next':''}}
        w.start('my',{'tabs':[{'id':'my','rows':[{'label':'Meine Liste','path':'nf://mylist'}]}]})
        self.assertNotEqual(w.rows[600]['items'],[{'Title':'Ghost'}])
        w.logo_pool.shutdown(wait=False)

if __name__ == '__main__':
    unittest.main()
