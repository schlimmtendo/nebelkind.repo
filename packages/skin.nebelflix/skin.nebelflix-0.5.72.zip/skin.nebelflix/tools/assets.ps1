$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$assetRoot = Join-Path (Split-Path $PSScriptRoot -Parent) 'media\nebelflix'
function RoundedPath([single]$x,[single]$y,[single]$w,[single]$h,[single]$r) {
 $p = New-Object Drawing.Drawing2D.GraphicsPath
 $d=2*$r
 $p.AddArc($x,$y,$d,$d,180,90);$p.AddArc($x+$w-$d,$y,$d,$d,270,90)
 $p.AddArc($x+$w-$d,$y+$h-$d,$d,$d,0,90);$p.AddArc($x,$y+$h-$d,$d,$d,90,90);$p.CloseFigure()
 return ,$p
}
foreach($name in @('profile','search','home','series','movies','list','settings','folder','media','addons','play','music','info','power')) {
 $bmp=New-Object Drawing.Bitmap(64,64);$g=[Drawing.Graphics]::FromImage($bmp)
 $g.SmoothingMode=[Drawing.Drawing2D.SmoothingMode]::AntiAlias
 $pen=New-Object Drawing.Pen([Drawing.Color]::White,3.8);$pen.StartCap='Round';$pen.EndCap='Round';$pen.LineJoin='Round'
 switch($name) {
  'profile' { $p=RoundedPath 9 6 46 52 7;$g.DrawPath($pen,$p);$p.Dispose();$g.FillEllipse([Drawing.Brushes]::White,20,23,5,5);$g.FillEllipse([Drawing.Brushes]::White,40,23,5,5);$g.DrawArc($pen,22,31,21,13,10,160) }
  'search' {$g.DrawEllipse($pen,9,8,33,33);$g.DrawLine($pen,39,39,55,55)}
  'home' {$pts=[Drawing.Point[]]@([Drawing.Point]::new(7,29),[Drawing.Point]::new(32,8),[Drawing.Point]::new(57,29));$g.DrawLines($pen,$pts);$g.DrawLine($pen,15,26,15,55);$g.DrawLine($pen,15,55,49,55);$g.DrawLine($pen,49,55,49,26);$g.DrawRectangle($pen,27,37,11,18)}
  'series' {$p=RoundedPath 7 15 50 35 5;$g.DrawPath($pen,$p);$p.Dispose();$g.DrawLine($pen,25,8,32,15);$g.DrawLine($pen,39,8,32,15);$g.DrawLine($pen,23,57,41,57)}
  'movies' {$g.DrawRectangle($pen,9,11,46,44);$g.DrawLine($pen,9,25,55,25);$g.DrawLine($pen,20,11,15,25);$g.DrawLine($pen,35,11,30,25);$g.DrawLine($pen,50,11,45,25)}
  'list' {$g.DrawLine($pen,32,13,32,51);$g.DrawLine($pen,13,32,51,32)}
  'settings' {$g.DrawEllipse($pen,16,16,32,32);$g.DrawEllipse($pen,26,26,12,12);foreach($angle in 0,45,90,135,180,225,270,315){$r=$angle*[Math]::PI/180;$g.DrawLine($pen,[single](32+17*[Math]::Cos($r)),[single](32+17*[Math]::Sin($r)),[single](32+25*[Math]::Cos($r)),[single](32+25*[Math]::Sin($r)))}}
  'folder' {$pts=[Drawing.Point[]]@([Drawing.Point]::new(7,18),[Drawing.Point]::new(25,18),[Drawing.Point]::new(31,24),[Drawing.Point]::new(57,24),[Drawing.Point]::new(57,52),[Drawing.Point]::new(7,52));$g.DrawPolygon($pen,$pts)}
  'media' {$p=RoundedPath 8 9 48 46 5;$g.DrawPath($pen,$p);$p.Dispose();$g.DrawEllipse($pen,36,18,9,9);$pts=[Drawing.Point[]]@([Drawing.Point]::new(10,48),[Drawing.Point]::new(25,31),[Drawing.Point]::new(37,44),[Drawing.Point]::new(43,37),[Drawing.Point]::new(55,49));$g.DrawLines($pen,$pts)}
  'addons' {foreach($x in 10,37){foreach($y in 10,37){$g.DrawRectangle($pen,$x,$y,17,17)}}}
  'play' {$pts=[Drawing.Point[]]@([Drawing.Point]::new(20,10),[Drawing.Point]::new(53,32),[Drawing.Point]::new(20,54));$g.FillPolygon([Drawing.Brushes]::White,$pts)}
  'music' {$g.DrawLine($pen,27,43,27,16);$g.DrawLine($pen,27,16,50,10);$g.DrawLine($pen,50,10,50,38);$g.FillEllipse([Drawing.Brushes]::White,11,40,18,13);$g.FillEllipse([Drawing.Brushes]::White,34,35,18,13)}
  'info' {$g.DrawEllipse($pen,8,8,48,48);$g.DrawLine($pen,32,29,32,46);$g.FillEllipse([Drawing.Brushes]::White,29,18,6,6)}
  'power' {$g.DrawArc($pen,11,13,42,42,-60,300);$g.DrawLine($pen,32,6,32,29)}
 }
 $bmp.Save((Join-Path $assetRoot "icon-$name.png"),[Drawing.Imaging.ImageFormat]::Png)
 $g.Dispose();$pen.Dispose();$bmp.Dispose()
}
foreach($focused in @($false,$true)) {
 $bmp=New-Object Drawing.Bitmap(320,80);$g=[Drawing.Graphics]::FromImage($bmp);$g.SmoothingMode='AntiAlias'
 $p=RoundedPath 1 1 318 78 7;$color=if($focused){[Drawing.Color]::White}else{[Drawing.Color]::FromArgb(215,215,215)}
 $brush=New-Object Drawing.SolidBrush($color);$g.FillPath($brush,$p)
 $name=if($focused){'button-focus.png'}else{'button.png'}
 $bmp.Save((Join-Path $assetRoot $name),[Drawing.Imaging.ImageFormat]::Png)
 $brush.Dispose();$p.Dispose();$g.Dispose();$bmp.Dispose()
}
foreach($on in @($false,$true)) {
 $bmp=New-Object Drawing.Bitmap(116,64);$g=[Drawing.Graphics]::FromImage($bmp);$g.SmoothingMode='AntiAlias'
 $p=RoundedPath 1 1 114 62 31;$color=if($on){[Drawing.Color]::FromArgb(229,9,20)}else{[Drawing.Color]::FromArgb(90,90,90)}
 $brush=New-Object Drawing.SolidBrush($color);$g.FillPath($brush,$p)
 $x=if($on){58}else{6};$g.FillEllipse([Drawing.Brushes]::White,$x,6,52,52)
 $name=if($on){'toggle-on.png'}else{'toggle-off.png'}
 $bmp.Save((Join-Path $assetRoot $name),[Drawing.Imaging.ImageFormat]::Png)
 $brush.Dispose();$p.Dispose();$g.Dispose();$bmp.Dispose()
}
$bmp=New-Object Drawing.Bitmap(512,512);$g=[Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode='AntiAlias';$g.TextRenderingHint='AntiAliasGridFit';$g.Clear([Drawing.Color]::FromArgb(20,20,20))
$font=New-Object Drawing.Font('Segoe UI',145,[Drawing.FontStyle]::Bold,[Drawing.GraphicsUnit]::Pixel)
$brand=New-Object Drawing.Font('Segoe UI',43,[Drawing.FontStyle]::Bold,[Drawing.GraphicsUnit]::Pixel)
$red=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(229,9,20))
$format=New-Object Drawing.StringFormat;$format.Alignment='Center';$format.LineAlignment='Center'
$g.DrawString('NF',$font,$red,[Drawing.RectangleF]::new(0,70,512,230),$format)
$g.DrawString('NEBELFLIX',$brand,[Drawing.Brushes]::White,[Drawing.RectangleF]::new(0,315,512,90),$format)
$g.FillRectangle($red,175,425,162,6)
$bmp.Save((Join-Path (Split-Path $PSScriptRoot -Parent) 'resources\nebelflix-icon.png'),[Drawing.Imaging.ImageFormat]::Png)
$font.Dispose();$brand.Dispose();$red.Dispose();$format.Dispose();$g.Dispose();$bmp.Dispose()
Write-Output 'Nebelflix vector-derived assets generated.'
