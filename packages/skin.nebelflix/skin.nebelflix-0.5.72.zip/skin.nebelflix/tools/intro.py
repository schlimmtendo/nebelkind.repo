"""Render a silent original Nebelflix wordmark animation."""
from pathlib import Path
import subprocess
import tempfile
import shutil
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'media' / 'nebelflix'
FFMPEG = Path(r'C:\Program Files (x86)\MiniTool Video Converter\FFmpeg\ffmpeg.exe')
W, H, FPS, DURATION = 1920, 1080, 30, 6.5


def render():
    font_path = Path('C:/Windows/Fonts/arialbd.ttf')
    font = ImageFont.truetype(str(font_path), 176)
    letters = []
    widths = [int(font.getlength(letter))+8 for letter in 'NEBELFLIX']
    cursor = (W-sum(widths))/2
    for letter, width in zip('NEBELFLIX', widths):
        glyph = Image.new('L', (width+12, 240))
        ImageDraw.Draw(glyph).text((6, 0), letter, font=font, fill=255, stroke_width=3)
        letters.append((glyph, cursor))
        cursor += width
    with tempfile.TemporaryDirectory(prefix='nebelflix-intro-') as temp:
        command=[str(FFMPEG),'-hide_banner','-loglevel','error','-y',
                 '-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}',
                 '-framerate',str(FPS),'-i','pipe:0',
                 '-map','0:v:0','-an',
                 '-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p',
                 '-movflags','+faststart',str(OUT/'intro-render.mp4')]
        proc=subprocess.Popen(command,stdin=subprocess.PIPE,stderr=subprocess.PIPE,stdout=subprocess.DEVNULL)
        for frame in range(int(FPS*DURATION)):
            t=frame/FPS
            canvas=Image.new('RGB',(W,H),(3,3,5))
            # Hold the entire word clearly, gather letters into its first N,
            # move that N to centre, then let it approach the viewer.
            canvas=Image.new('RGB',(W,H),(20,20,20))
            ease=lambda p: (max(0,min(1,p)))**2*(3-2*max(0,min(1,p)))
            fade=ease(t/.45) * (1-ease((t-5.9)/.6))
            gather=ease((t-2.3)/1.2)
            centre=ease((t-3.55)/.7)
            first_x=letters[0][1]
            n_width=letters[0][0].width
            n_x=first_x + ((W-n_width)/2-first_x)*centre
            zoom=1+35*ease((t-4.45)/1.7)**3
            for index in reversed(range(len(letters))):
                glyph, original_x=letters[index]
                if index and gather >= 1:
                    continue
                opacity=fade*(1-gather if index else 1)
                x=original_x+(first_x-original_x)*gather if index else n_x
                if not index and zoom>1:
                    size=(max(1,int(glyph.width*zoom)),max(1,int(glyph.height*zoom)))
                    glyph=glyph.resize(size,Image.Resampling.BICUBIC)
                    x=(W-size[0])/2
                y=(H-glyph.height)/2-10
                glyph=glyph.point(lambda a:int(a*opacity))
                canvas.paste((229,9,20),(int(x),int(y)),glyph)
            if frame in (45, 90, 126, 153):
                canvas.save(OUT/f'intro-stage-{frame}.jpg',quality=92)
            if frame==45:
                canvas.save(OUT/'intro-preview.jpg',quality=92)
            proc.stdin.write(canvas.tobytes())
        proc.stdin.close()
        error=proc.stderr.read().decode('utf-8','replace')
        if proc.wait()!=0:
            raise RuntimeError(error)
    shutil.copyfile(OUT/'intro-render.mp4', OUT/'intro.mp4')
    (OUT/'intro-render.mp4').unlink()
    print('Silent Nebelflix intro generated: readable word, gathering letters, centred N zoom; 6.5s Full HD.')


if __name__=='__main__':
    render()
