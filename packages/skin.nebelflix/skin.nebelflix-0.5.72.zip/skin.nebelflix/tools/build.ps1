param([switch]$RenderIntro)
$ErrorActionPreference = 'Stop'
$runtimePython = 'C:\Users\Chris\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if(!(Test-Path -LiteralPath $runtimePython)) {throw 'Set runtimePython to a Python installation with Pillow.'}
& $runtimePython (Join-Path $PSScriptRoot 'build.py')
if($LASTEXITCODE -ne 0) {throw 'Nebelflix XML build failed'}
if($RenderIntro -or !(Test-Path -LiteralPath (Join-Path (Split-Path $PSScriptRoot -Parent) 'media\nebelflix\intro.mp4'))) {
 & $runtimePython (Join-Path $PSScriptRoot 'intro.py')
 if($LASTEXITCODE -ne 0) {throw 'Intro render failed'}
}
