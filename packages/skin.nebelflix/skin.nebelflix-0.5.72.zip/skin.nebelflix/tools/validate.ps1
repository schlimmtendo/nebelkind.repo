$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$failures = [Collections.Generic.List[string]]::new()
$notes = [Collections.Generic.List[string]]::new()
$docs = @{}
foreach($file in Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object {$_.Extension -in '.xml','.xsp'}) {
 try { $doc = New-Object Xml.XmlDocument; $doc.Load($file.FullName); $docs[$file.FullName] = $doc }
 catch { $failures.Add("XML parse: $($file.FullName): $($_.Exception.Message)") }
}
foreach($pair in $docs.GetEnumerator()) {
 foreach($include in $pair.Value.SelectNodes('//include[@file]')) {
  if($include.file -match '\$') {continue}
  if(!(Test-Path -LiteralPath (Join-Path $root "xml\$($include.file)"))) {$failures.Add("Missing include: $($include.file)")}
 }
}
$customIDs=@{}
foreach($file in Get-ChildItem (Join-Path $root 'xml') -Filter 'Custom*.xml') {
 $doc=$docs[$file.FullName];$id=[string]$doc.window.id
 if($customIDs.ContainsKey($id)) {$failures.Add("Custom window collision $id : $($file.Name) / $($customIDs[$id])")}
 else {$customIDs[$id]=$file.Name}
}
$fontDoc=$docs[(Join-Path $root 'xml\Font.xml')]
$fontNames=@($fontDoc.SelectNodes('//font/name') | ForEach-Object {$_.InnerText})
foreach($file in $fontDoc.SelectNodes('//font/filename')) {
 if(!(Test-Path -LiteralPath (Join-Path $root "fonts\$($file.InnerText)"))) {
  if($file.InnerText -eq 'arial.ttf' -and (Test-Path -LiteralPath 'C:\Program Files (x86)\TitanX Lab\media\Fonts\arial.ttf')) {continue}
  $failures.Add("Missing font: $($file.InnerText)")
 }
}
foreach($set in $fontDoc.SelectNodes('//fontset')) {
 foreach($dup in @($set.SelectNodes('font/name') | Group-Object InnerText | Where-Object Count -gt 1)) {$failures.Add("Duplicate font $($dup.Name) in $($set.id)")}
}
$owned = @('Home.xml','SkinSettings.xml','Custom_1190_NebelflixSettings.xml','Settings.xml','Custom_1191_Details.xml','Custom_1192_Menu.xml','Custom_1193_Menu.xml','Startup.xml')
$builtins=@('Settings','FileManager','Profiles','MediaSettings','AddonBrowser','SystemSettings','InterfaceSettings','PlayerSettings','ServiceSettings','PVRSettings','Music','Pictures','Videos','SystemInfo','ShutdownMenu','FavouritesBrowser','EventLog','1190','1191','1192','1193','Home')
foreach($name in $owned) {
 $doc=$docs[(Join-Path $root "xml\$name")]
 if(!$doc) {$failures.Add("Missing window $name");continue}
 $ids=@($doc.SelectNodes('//control[@id]') | ForEach-Object {[string]$_.id})
 foreach($dup in @($ids | Group-Object | Where-Object Count -gt 1)) {$failures.Add("Duplicate control ID $($dup.Name) in $name")}
 foreach($control in $doc.SelectNodes('//control')) {
  foreach($field in @('texture','textcolor','font','visible','width','height','left','top')) {
   if($control.SelectNodes($field).Count -gt 1) {$failures.Add("Repeated $field on $($control.type)/$($control.id) in $name")}
  }
 }
 foreach($font in $doc.SelectNodes('//font')) {
  if($font.InnerText -notin $fontNames) {$failures.Add("Undefined font $($font.InnerText) in $name")}
 }
 foreach($texture in $doc.SelectNodes('//texture | //texturefocus | //texturenofocus | //textureradioonfocus | //textureradioonnofocus | //textureradioofffocus | //textureradiooffnofocus | //icon')) {
  $value=$texture.InnerText
  if($value -like 'nebelflix/*' -and !(Test-Path -LiteralPath (Join-Path $root "media\$value"))) {$failures.Add("Missing texture $value in $name")}
 }
 foreach($fallback in $doc.SelectNodes('//texture[@fallback]')) {
  if($fallback.fallback -like 'nebelflix/*' -and !(Test-Path -LiteralPath (Join-Path $root "media\$($fallback.fallback)"))) {$failures.Add("Missing fallback $($fallback.fallback)")}
 }
 foreach($node in $doc.SelectNodes('//onclick | //onup | //ondown | //onleft | //onright | //onback')) {
  $value=$node.InnerText
  if($value -match '^(?:Control\.)?SetFocus\((\d+)\)' -and $Matches[1] -notin $ids) {$failures.Add("Missing control target $($Matches[1]) in $name")}
  if($value -match '^\d+$' -and $value -notin $ids) {$failures.Add("Missing numeric target $value in $name")}
  if($value -match '^ActivateWindow\(([^,)]+)' -and $Matches[1] -notin $builtins) {$failures.Add("Unreviewed window target $($Matches[1]) in $name")}
 }
}
$nfVars=@($docs[(Join-Path $root 'xml\Includes_Nebelflix.xml')].SelectNodes('//variable') | ForEach-Object {$_.name})
$homeDoc=$docs[(Join-Path $root 'xml\Home.xml')]
if($homeDoc.SelectNodes('//control[@type="videowindow"]').Count -ne 2) {$failures.Add('Home must contain intro and spotlight video surfaces')}
if($homeDoc.OuterXml -match 'spotlight_next|spotlight_prev|NF.SpotlightPosition') {$failures.Add('Spotlight arrows/counter must be absent')}
$controllerText=Get-Content -LiteralPath (Join-Path $root 'resources\controller.py') -Raw
if($controllerText -match 'def (start_preview|cover_preview|can_preview)\(') {$failures.Add('Legacy automatic trailer implementation found')}
$detailText=Get-Content -LiteralPath (Join-Path $root 'xml\Custom_1191_Details.xml') -Raw
if($detailText -notmatch 'NFD\.Title' -or $detailText -notmatch 'trailer,detail') {$failures.Add('Detail actions must use their captured title')}
foreach($match in [regex]::Matches($homeDoc.OuterXml,'\$VAR\[([^\]]+)\]')) {if($match.Groups[1].Value -notin $nfVars){$failures.Add("Undefined NF variable $($match.Groups[1].Value)")}}
foreach($match in [regex]::Matches($homeDoc.OuterXml,'special://skin/([^<]+\.xsp)')) {if(!(Test-Path -LiteralPath (Join-Path $root $match.Groups[1].Value))){$failures.Add("Missing playlist $($match.Groups[1].Value)")}}
$required=@('FileManager.xml','DialogSettings.xml','SettingsCategory.xml','SettingsProfile.xml','MyVideoNav.xml','MyMusicNav.xml','MyPics.xml','MyGames.xml','MyFavourites.xml','AddonBrowser.xml','DialogKeyboard.xml','DialogVideoInfo.xml','VideoOSD.xml','DialogButtonMenu.xml')
foreach($file in $required){if(!(Test-Path -LiteralPath (Join-Path $root "xml\$file"))){$failures.Add("Missing native window $file")}}
$addon=$docs[(Join-Path $root 'addon.xml')]
if($addon.addon.id -ne 'skin.nebelflix') {$failures.Add('Incorrect addon ID')}
if($addon.SelectSingleNode('/addon/requires/import[@addon="xbmc.gui"]').version -ne '5.17.0') {$failures.Add('Incorrect Omega GUI ABI')}
if(!$addon.SelectSingleNode('/addon/requires/import[@addon="plugin.video.themoviedb.helper"]')) {$failures.Add('Missing TMDB Helper dependency')}
foreach($name in $owned) {
 $text=$docs[(Join-Path $root "xml\$name")].OuterXml
 if($text -match 'ActivateWindow\(Games|GameSettings|<label>Games</label>|<label>Spiele</label>') {$failures.Add("Games link in own window $name")}
}
if(!(Test-Path -LiteralPath (Join-Path $root 'media\nebelflix\intro.mp4'))) {$failures.Add('Missing intro clip')}
$runtimePython='C:\Users\Chris\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $runtimePython -c "from pathlib import Path; p=Path(r'$root'); files=list((p/'resources').glob('*.py'))+list((p/'tools').glob('*.py')); [compile(f.read_text(encoding='utf-8-sig'),str(f),'exec') for f in files]; print('Python syntax OK')"
if($LASTEXITCODE -ne 0) {$failures.Add('Python syntax validation failed')}
$report=[ordered]@{
 checkedAt=(Get-Date).ToString('o')
 addon='skin.nebelflix'
 xmlDocuments=$docs.Count
 customWindows=$customIDs.Count
 ownedWindows=$owned
 failures=@($failures)
 result=if($failures.Count -eq 0){'PASS'}else{'FAIL'}
 runtimeTested='Partial: see RUNTIME_TEST.md for verified behavior and remaining external-player coverage'
 activeSkinChanged=$false
 limitations=@('Runtime verification details are in RUNTIME_TEST.md.','System detail dialogs retain the Estuary layout.','Reference is the local NEBELFLIX.mp4; no Netflix account data is accessed.','Film playback uses the configured TMDB Helper players; availability depends on those players.')
}
$report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'validation.json') -Encoding utf8
if($failures.Count) {$failures | ForEach-Object {Write-Output "FAIL: $_"};throw "$($failures.Count) validation failures"}
Write-Output "PASS: $($docs.Count) XML/playlist documents, $($customIDs.Count) unique custom windows; fonts, local textures, includes, Python syntax and navigation resolved. See RUNTIME_TEST.md for live verification."
