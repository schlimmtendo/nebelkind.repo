"""Behavioral regression checks without modifying Kodi/profile state."""
import importlib.util
import json
import sys
import tempfile
import threading
import time
import sqlite3
import types
import unittest
from pathlib import Path
from unittest.mock import Mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'resources'))
properties = {}
class Control:
    def __init__(self): self.items=[]; self.position=0
    def reset(self): self.items=[]
    def addItems(self, items): self.items.extend(items)
    def addItem(self, item): self.items.append(item)
    def getSelectedPosition(self): return self.position
    def selectItem(self, n): self.position=n
class Window:
    def __init__(self, *args): self.controls={}
    def getProperty(self, k): return properties.get(k, '')
    def setProperty(self, k, v): properties[k]=v
    def clearProperty(self, k): properties.pop(k,None)
    def getControl(self, k): return self.controls.setdefault(k, Control())
sys.modules['xbmc'] = types.SimpleNamespace(Player=type('Player',(),{'isPlaying':lambda s:False}),
    Monitor=Mock(), LOGINFO=1, LOGWARNING=2, LOGERROR=3, log=Mock(), getInfoLabel=Mock(return_value=''),
    getCondVisibility=Mock(return_value=False), executebuiltin=Mock())
sys.modules['xbmcgui'] = types.SimpleNamespace(Window=Window, ListItem=Mock(), Dialog=Mock(),
    getCurrentWindowId=Mock(return_value=10000))
sys.modules['xbmcvfs'] = types.SimpleNamespace(translatePath=lambda p:tempfile.gettempdir())
import library
import controller

class RuntimeTests(unittest.TestCase):
    def setUp(self):
        properties.clear()
        self.temp=tempfile.TemporaryDirectory()
        library.ROOT=Path(self.temp.name)
        self.original_directory=library.directory
        self.original_listitem=library.listitem
        self.original_rpc=controller.rpc
        self.original_visible=controller.spotlight_visible
        self.original_cancel=controller.cancel_spotlight_video
        self.original_resolver=controller.resolve_trailer
        self.original_player=controller.PLAYER
    def tearDown(self):
        library.directory=self.original_directory; library.listitem=self.original_listitem
        controller.rpc=self.original_rpc; controller.spotlight_visible=self.original_visible
        controller.cancel_spotlight_video=self.original_cancel; controller.resolve_trailer=self.original_resolver
        controller.PLAYER=self.original_player
        self.temp.cleanup()
    def test_null_favourites_and_metadata(self):
        calls=[]
        def rpc(method, params):
            calls.append((method,params)); return {'favourites':None}
        controller.rpc=rpc
        controller.mylist({'Title':'Batman', 'Type':'movie', 'TMDB':'155', 'Plot':'Plot'})
        self.assertEqual(calls[-1][0], 'Favourites.AddFavourite')
        self.assertEqual(library.read('mylist.json',[])[0]['Plot'],'Plot')
    def test_navigation_not_media(self):
        for text in ('Mehr ...','[B]Mehr …[/B]','Nächste Seite','Next page (2)'):
            self.assertTrue(library.navigation({'label':text}))
        self.assertFalse(library.navigation({'label':'Batman'}))
    def test_independent_loading_and_append(self):
        gate=threading.Event()
        def source(rpc,path):
            if path=='slow': gate.wait(2)
            if path=='second': return [{'Title':'B','Path':'b'}],''
            return [{'Title':'A','Path':'a'}],'second'
        library.directory=source; library.listitem=lambda x:x
        win=Window(); w=library.Widgets(None,win,controller.prop)
        def publish(cid, items, position=0):
            control=win.getControl(cid); control.reset(); control.addItems(items); control.selectItem(position)
        w.publish=publish
        w.start('home',{'tabs':[{'id':'home','rows':[{'label':'Slow','path':'slow'},{'label':'Fast','path':'fast'}]}]})
        time.sleep(.05); w.tick()
        self.assertEqual(win.getControl(601).items[0]['Title'],'A')
        self.assertEqual(win.getControl(600).items[0]['Title'],'Lädt …')
        controller.prop('WidgetRequest',json.dumps({'row':601,'generation':str(w.generation)}))
        w.tick(); time.sleep(.05); w.tick()
        self.assertEqual([x['Title'] for x in win.getControl(601).items],['A','B'])
        gate.set(); time.sleep(.05); w.tick()
    def test_stale_category_result_ignored(self):
        library.listitem=lambda x:x
        w=library.Widgets(None,Window(),controller.prop)
        w.generation=2
        w.results.put((1,600,'old',[{'Title':'Wrong'}],'',''))
        w.tick()
        self.assertEqual(w.rows,{})
    def test_no_autoplay_without_request(self):
        controller.spotlight_visible=lambda:True
        controller.prop('Page','home')
        controller.resolve_trailer=Mock(return_value='german')
        video=controller.SpotlightVideo()
        for _ in range(20): video.tick('home',{'Title':'A','Type':'movie','TMDB':'1'})
        controller.resolve_trailer.assert_not_called()
        self.assertEqual(video.token,'')
    def test_cancelled_lookup_cannot_publish(self):
        controller.resolve_trailer=lambda item:'german'
        video=controller.SpotlightVideo(); video.token='new'
        controller.prop('AutoToken','new')
        video.lookup('old',{})
        self.assertIsNone(video.result)
    def test_manual_spotlight_request_is_captured(self):
        item={'Title':'A','Type':'movie','TMDB':'1'}
        controller.play_trailer(item)
        self.assertEqual(json.loads(controller.prop('TrailerRequest')),item)
    def test_episode_progress_has_distinct_identity(self):
        item={'Type':'tv','TMDB':'10','DBType':'episode','Season':'1','Episode':'2'}
        self.assertNotEqual(library.identity(item),library.identity(dict(item,Episode='3')))
    def test_layout_storage_roundtrip(self):
        config={'tabs':[{'id':'custom','label':'Live-TV','rows':[{'label':'Sendergruppe','path':'pvr://channels/tv/'}]}]}
        library.write('layout.json',config)
        self.assertEqual(library.layout(),config)
    def test_progress_saved_resumed_and_completed(self):
        player=Mock()
        player.isPlayingVideo.return_value=True
        player.getPlayingFile.return_value='/movie.mkv'
        player.getTotalTime.return_value=1000
        player.getTime.return_value=200
        rpc=lambda *args:{'item':{'file':'/movie.mkv','label':'Batman','type':'movie','uniqueid':{'tmdb':'155'}}}
        progress=library.Progress(rpc,player,controller.prop)
        progress.tick()
        self.assertEqual(library.read('progress.json',[])[0]['Resume'],200)
        progress.item['Resume']=200
        controller.prop('PendingPlay',json.dumps(dict(progress.item,RequestedAt=time.time())))
        progress.file=''
        progress.tick()
        player.seekTime.assert_called_once_with(200)
        progress.saved=0; player.getTime.return_value=960
        progress.tick()
        self.assertEqual(library.read('progress.json',[]),[])
    def test_provider_snapshot_preserves_actions(self):
        w=library.Widgets(None,Window(),controller.prop)
        entries=[{'Title':'Weiter','Next':True,'Row':600,'Generation':'4'}]
        w.publish(600,entries)
        self.assertEqual(library.read('row-600.json',[]),entries)
        self.assertTrue(controller.prop('RowURL600').startswith('plugin://skin.nebelflix/'))
    def test_only_exact_german_trailer_is_selected(self):
        import trailers
        from unittest.mock import patch
        source=Mock(return_value=[
            {'language':'en','type':'Trailer','id':'english'},
            {'language':'de','type':'Teaser','id':'teaser'},
            {'language':'de','type':'Trailer','id':'german'}])
        resolve=Mock(return_value=({'url':'https://example.test/german','isa_manifest_type':'mpd'},{}))
        module=types.SimpleNamespace(sources=types.SimpleNamespace(from_tmdb=source),
            filters=types.SimpleNamespace(is_fan_made=lambda *a:False), api=types.SimpleNamespace(resolve_video_item=resolve), isa=types.SimpleNamespace(is_ready=lambda:True))
        with patch.dict(sys.modules, {'multitrailer':module}):
            result=trailers.resolve({'TMDB':'155','Type':'movie','Title':'Batman'})
            source.assert_called_once_with('movie',155)
            self.assertEqual(resolve.call_args.args[0]['id'],'german')
            self.assertEqual(result['isa_manifest_type'],'mpd')
            source.return_value=[]
            self.assertIsNone(trailers.resolve({'TMDB':'9','Type':'tv'}))
    def test_series_fallback_rejects_wrong_title_and_language(self):
        import trailers
        from unittest.mock import patch
        search=Mock(return_value=[{'title':t} for t in
            ('Other Show Trailer Deutsch','Dark Trailer English','Dark Teaser Deutsch',
             'Dark Trailer Deutsch')])
        resolver=Mock(return_value=({'url':'stream'},{}))
        module=types.SimpleNamespace(sources=types.SimpleNamespace(from_tmdb=lambda *a:[],from_youtube_search=search),
            api=types.SimpleNamespace(resolve_video_item=resolver), isa=types.SimpleNamespace(is_ready=lambda:True),
            filters=types.SimpleNamespace(is_fan_made=lambda *a:False))
        with patch.dict(sys.modules, {'multitrailer':module}):
            self.assertIsNotNone(trailers.resolve({'Type':'tv','TMDB':'70523','Title':'Dark'}))
            self.assertEqual(resolver.call_args.args[0]['title'],'Dark Trailer Deutsch')
    def test_auto_trailer_setting_delay_and_one_attempt(self):
        from unittest.mock import patch
        controller.spotlight_visible=lambda:True
        controller.prop('Page','home')
        item={'Title':'A','Type':'movie','TMDB':'1'}
        video=controller.SpotlightVideo()
        with patch.object(controller.xbmc,'getCondVisibility',return_value=True), patch.object(controller.threading,'Thread') as thread:
            video.dwell=time.monotonic()-10
            video.tick('home',item)
            thread.assert_not_called()
        with patch.object(controller.xbmc,'getCondVisibility',return_value=False), patch.object(controller.threading,'Thread') as thread:
            video.dwell=time.monotonic()-10
            video.tick('home',item)
            thread.assert_called_once()
            video.reset()
            video.tick('home',item)
            thread.assert_called_once()
    def test_empty_lookup_completes(self):
        controller.resolve_trailer=lambda item:None
        video=controller.SpotlightVideo();video.token='a';controller.prop('AutoToken','a')
        video.lookup('a',{})
        self.assertEqual(video.result,'')
    def test_multitrailer_preserves_manifest_and_windowed_playback(self):
        import trailers
        player=Mock()
        trailers.play(player, {'url':'https://example.test/a.mpd','isa_manifest_type':'mpd',
                              'http_headers':{'Referer':'https://example.test/'}},True)
        self.assertTrue(player.play.call_args.kwargs['windowed'])
        li=player.play.call_args.args[1]
        li.setProperty.assert_any_call('inputstream','inputstream.adaptive')
        li.setProperty.assert_any_call('inputstream.adaptive.stream_headers','Referer=https%3A%2F%2Fexample.test%2F')
    def test_multitrailer_disables_local_dash_server(self):
        import trailers
        from unittest.mock import patch
        source=Mock(return_value=[{'language':'de','type':'Trailer','id':'german'}])
        resolve=Mock(return_value=({'url':'https://example.test/trailer.m3u8'},{}))
        module=types.SimpleNamespace(sources=types.SimpleNamespace(from_tmdb=source),
            api=types.SimpleNamespace(resolve_video_item=resolve),filters=types.SimpleNamespace(is_fan_made=lambda *a:False))
        with patch.dict(sys.modules, {'multitrailer':module}):
            self.assertEqual(trailers.resolve({'TMDB':'155','Type':'movie'})['url'],'https://example.test/trailer.m3u8')
            self.assertFalse(resolve.call_args.kwargs['prefer_dash'])
            resolve.return_value=({'url':'http://127.0.0.1:52080/mpd/stalled.mpd'}, {})
            self.assertIsNone(trailers.resolve({'TMDB':'155','Type':'movie'}))
    def test_widget_sharing_violation_uses_backup(self):
        from unittest.mock import patch
        with patch.object(Path,'read_text',side_effect=[PermissionError(),PermissionError(),PermissionError(),'[1]']):
            self.assertEqual(library.read('row-602.json',[]),[1])
        with patch.object(Path,'read_text',side_effect=PermissionError()):
            self.assertEqual(library.read('row-602.json',[]),[])
    def test_error_uses_cache_and_retry(self):
        win=Window(); w=library.Widgets(None,win,controller.prop)
        w.generation=1
        w.rows[600]={'items':[],'busy':True,'source':'source','next':'','history':[],'top10':False}
        w.cache['source']={'time':0,'items':[{'Title':'Saved','Path':'saved'}],'next':''}
        w.publish=lambda cid,items,position=0:win.getControl(cid).addItems(items)
        w.results.put((1,600,'source',[],'','offline'))
        w.tick()
        self.assertEqual(win.getControl(600).items[0]['Title'],'Saved')
        self.assertTrue(win.getControl(600).items[-1]['Retry'])

if __name__=='__main__': unittest.main(verbosity=2)
