$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent))
$kodiRoot = Split-Path (Split-Path $root -Parent) -Parent
$settingsPath = Join-Path $kodiRoot 'userdata\guisettings.xml'
$settingsHash = (Get-FileHash -LiteralPath $settingsPath -Algorithm SHA256).Hash
& (Join-Path $PSScriptRoot 'validate.ps1')
[xml]$manifest=Get-Content -LiteralPath (Join-Path $root 'addon.xml') -Raw
$output = [IO.Path]::GetFullPath((Join-Path $kodiRoot 'My_Builds\Nebelflix'))
if(!$output.StartsWith($kodiRoot+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {throw 'Output outside Kodi workspace'}
[void][IO.Directory]::CreateDirectory($output)
$zipPath=Join-Path $output "skin.nebelflix-$($manifest.addon.version).zip"
$stagePath=Join-Path $output 'nebelflix-package.tmp.zip'
if(Test-Path -LiteralPath $stagePath) {Remove-Item -LiteralPath $stagePath}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$package=[IO.Compression.ZipFile]::Open($stagePath,[IO.Compression.ZipArchiveMode]::Create)
try {
 foreach($file in Get-ChildItem -LiteralPath $root -Recurse -File) {
  if($file.FullName -match '[\\/]__pycache__[\\/]' -or $file.Extension -eq '.pyc') {continue}
  $relative=$file.FullName.Substring($root.Length+1).Replace('\','/')
  [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($package,$file.FullName,"skin.nebelflix/$relative",[IO.Compression.CompressionLevel]::Optimal)
 }
} finally {$package.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($stagePath)
try {
 $names=@($archive.Entries | ForEach-Object {$_.FullName.Replace('\','/')})
 foreach($name in $names) {if(!$name.StartsWith('skin.nebelflix/') -or $name.Contains('../')) {throw "Invalid ZIP entry $name"}}
 foreach($required in @('addon.xml','xml/Home.xml','xml/Settings.xml','xml/Includes.xml','xml/DialogSettings.xml','xml/SkinSettings.xml','xml/Custom_1190_NebelflixSettings.xml','media/nebelflix/icon-home.png','resources/nebelflix-icon.png','validation.json')) {
  if("skin.nebelflix/$required" -notin $names) {throw "Missing packaged file $required"}
 }
 $addonEntry=$archive.Entries | Where-Object {$_.FullName.Replace('\','/') -eq 'skin.nebelflix/addon.xml'}
 $reader=[IO.StreamReader]::new($addonEntry.Open())
 try {[xml]$packagedManifest=$reader.ReadToEnd()} finally {$reader.Dispose()}
 if($packagedManifest.addon.id -ne 'skin.nebelflix'){throw 'Invalid packaged addon identity'}
 $entryCount=$archive.Entries.Count
} finally {$archive.Dispose()}
[IO.File]::Copy($stagePath,$zipPath,$true)
Remove-Item -LiteralPath $stagePath
$hash=(Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash
[IO.File]::WriteAllText("$zipPath.sha256","$hash  $([IO.Path]::GetFileName($zipPath))`n",[Text.UTF8Encoding]::new($false))
if((Get-FileHash -LiteralPath $settingsPath -Algorithm SHA256).Hash -ne $settingsHash){throw 'Kodi settings changed during packaging; inspect before reporting unchanged state'}
Write-Output "ZIP OK: $zipPath ($entryCount entries, $((Get-Item -LiteralPath $zipPath).Length) bytes)"
Write-Output "SHA256: $hash"
Write-Output 'guisettings.xml unchanged during validation and packaging. No add-on database writes or skin activation performed.'
