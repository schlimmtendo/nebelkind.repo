# Nebelflix 0.5.45 · Kodi 21

Nebelflix verwendet eine obere, horizontal navigierbare Reiterleiste, ein abgerundetes Spotlight und horizontale Kachelreihen. Keine Games und keine zusätzliche Profilauswahl beim Start. Die vollständigen Kodi-Einstellungen bleiben über das Zahnrad erreichbar.

## Eigene Reiter und Widgets

Zahnrad → Nebelflix Settings → Reiter & Widgets verwalten.

- Bis zu zwölf Reiter anlegen, umbenennen, verschieben oder entfernen.
- Pro Reiter bis zu sechzehn Reihen mit eigener Überschrift und Quelle verwalten.
- Bei „Quelle auswählen“ ein Video-Add-on öffnen, zum gewünschten Bereich navigieren und „Diesen Bereich verwenden“ wählen.
- „Add-on-Starter“ erstellt Icon-Reihen: Video- oder Musik-Add-ons auswählen, die Kachel startet das Add-on direkt und lädt nicht dessen Inhaltsverzeichnis.
- Auch Kodi-Bibliothek, PVR-Sendergruppen, Meine Liste, Weiterschauen und selbst eingegebene Verzeichnispfade sind möglich.
- Eine Reihe kann eine Sendergruppe darstellen. Ein Klick auf eine echte Kodi-PVR-Sendergruppe öffnet den nativen Kodi-TV-Guide für genau diese Gruppe. Ein Klick auf eine Vavoo-Gruppe öffnet die eigene Vollbild-EPG-Ansicht mit Senderlogo, aktueller Sendung, Fortschritt und Folgesendung; Vavoo-Sender werden dabei nicht als Kodi-PVR-Kanäle registriert.
- Die eigene Konfiguration liegt im aktiven Kodi-Profil unter addon_data/skin.nebelflix/layout.json. Updates überschreiben sie nicht. Ohne eigene Konfiguration gelten resources/default-layout.json und die Standardreiter.

Unterordner öffnen sich innerhalb ihrer Reihe; eine Zurück-Kachel führt zur vorherigen Ebene. „Weiter“ hängt die nächste Ergebnisseite an derselben Reihe an. Vorhandene Titel werden anhand ihrer Medienidentität dedupliziert. Die Funktion verwendet die von der Quelle gelieferten Weiter-/Mehr-/Nächste-Seite-Verknüpfungen. Quellen ohne solche Verknüpfungen können nicht künstlich paginiert werden.

Jede Reihe lädt unabhängig. Ergebnisse werden lokal zwischengespeichert; ein Quellfehler lässt andere Reihen weiterarbeiten und bietet einen erneuten Versuch an. Bei einem Fehler können bereits gespeicherte Inhalte weiter angezeigt werden. Top-10-Reihen enthalten maximal zehn Titel und sind als TMDB-Auswahl beschriftet.

## Spotlight und Trailer

Startseite: zufälliger Film oder zufällige Serie. Serien: nur Serien. Filme: nur Filme. Die Auswahl bleibt während des Kategorie-Besuchs unverändert. Ein Wechsel in einen anderen Reiter und zurück wählt neu; bei mehreren Kandidaten wird der vorige Titel vermieden. Keine Spotlight-Pfeile.

Es gibt kein Trailer-Autoplay. Der Trailer-Button im Spotlight startet oder stoppt die eingebettete Wiedergabe. Beim Wechsel zu den Reihen, in einen anderen Reiter oder in ein anderes Fenster wird dieser Trailer beendet. Verspätete Auflösungen verlieren ihre Startberechtigung. Die Videooberfläche hat dieselben abgerundeten Ecken wie das Spotlight; zum Ausfüllen wird das Bild passend beschnitten.

Der deutsche Trailer wird anhand der konkreten TMDB-ID und des Medientyps aus dem vorhandenen Helper-Videocache ausgewählt (Sprache de, Typ Trailer). Es gibt keinen englischen Ersatz und keine Übernahme des Trailers einer anderen Kachel. Ohne deutschen Treffer erscheint eine Meldung. Der Trailer-Button in der separaten Detailansicht verwendet weiterhin Vollbild. Bei Sendern und anderen Nicht-TMDB-Einträgen wird kein Trailer angeboten.

Nebelflix Hybrid und MultiTrailer müssen betriebsbereit sein. Der Skin benötigt TMDb Helper nicht für die Katalog- und Filmsuche. Ein Trailer kann je nach Auflösung weitere Wiedergabe-Komponenten benötigen. Es werden weder Helper-Dateien noch dessen Cache-Datenbank verändert.

## Meine Liste und Weiterschauen

„+ Meine Liste“ fügt den ausgewählten Film oder die Serie zu den Kodi-Favoriten hinzu. Ein erneuter Aufruf entfernt den vorhandenen Eintrag. Zusätzlich werden die Metadaten lokal gespeichert, damit die Reihe unter Mein Nebelflix sofort Titel, Bild und Beschreibung besitzt. Leere/null Favoritenlisten werden berücksichtigt.

Weiterschauen kombiniert Kodi-Bibliothekseinträge mit den vom Skin beobachteten Wiedergabefortschritten. Der Fortschritt wird alle fünf Sekunden im aktiven Profil gespeichert. Beim Start kann man fortsetzen oder von vorn beginnen; ab 95 Prozent gilt der Eintrag als beendet. Episoden werden getrennt nach Staffel und Folge behandelt. Trailer und Intro zählen nicht als gesehene Filme.

Die zuverlässige Zuordnung setzt voraus, dass ein Wiedergabe-Add-on Titel oder Medienidentität an Kodi übergibt. Seek/Fortsetzen setzt einen spulbaren Kodi-Stream voraus. Externe Player ohne diese Rückmeldung und Live-TV ohne feste Laufzeit können nicht zuverlässig fortgesetzt werden. Nebelflix erfindet dafür keinen Fortschritt. Die vorhandenen TMDB-Helper-Player bleiben unverändert.

## Suche und Intro

Die Lupe durchsucht direkt Nebelflix Hybrid. Im Film-Reiter nur Filme, im Serien-Reiter nur Serien und auf anderen Reitern beide gemeinsam. Die Ergebnisse und Folgeseiten werden direkt im Kodi-Katalog von Hybrid angezeigt. Kein TMDb Helper nötig.

Das eigene Full-HD-Intro zeigt NEBELFLIX gut lesbar, zieht die übrigen Buchstaben in das erste N, bewegt dieses in die Mitte und vergrößert es zum Zuschauer. Dauer: 6,5 Sekunden und stumm. In den Skin-Einstellungen lässt es sich ansehen oder beim Start überspringen.

## Entwicklung und Prüfung

- tools/build.ps1 generiert XML, Masken, Icons und Standardlayout; mit -RenderIntro auch das Video.
- tools/validate.ps1 prüft XML, lokale Ressourcen, Includes, Navigation und Python-Syntax.
- tools/test_runtime.py prüft Verhalten mit isolierten Kodi-Testdoubles; keine echten Profiländerungen.
- tools/package.ps1 erstellt das installierbare Skin-ZIP mit Prüfsumme.
- resources/controller.py steuert Auswahl, Aktionen, Trailer und Fortschritt.
- resources/library.py verwaltet Layout, unabhängige Abfragen und lokale Speicherung.
- resources/provider.py liefert die lokalen Widget-Snapshots über den im Skin registrierten Kodi-Plugin-Einstieg aus. Ein separates Hilfs-Add-on ist nicht notwendig.

Die konkreten Live-Nachweise und Grenzen stehen in RUNTIME_TEST.md. Native Kodi-Systemdialoge behalten ihre Estuary-Grundlage.

Technische Referenzen: [Kodi-Container](https://kodi.wiki/view/List_Container), [Kodi-Built-ins](https://kodi.wiki/view/List_of_built-in_functions), [Kodi-Python-ListItem](https://xbmc.github.io/docs.kodi.tv/master/kodi-dev-kit/group__python__xbmcgui__listitem.html).


Version 0.5.2: Trailer werden über das installierte MultiTrailer aufgelöst (exakte TMDB-ID, ausschließlich Deutsch). Die Filmkacheln zeigen verfügbare Clearlogos wieder im Fanart.
