# Nebelflix Skin / Hybrid Integration 2026-11-09

- Skin version: 0.5.45. Hybrid version: 2026.11.09.1.
- Search magnifier (Home): film and series results together, directly from Hybrid.
- Movies tab: films only. Series tab: series only. Other tabs: both.
- Optional Kodi search dialog also offers three Hybrid search modes.
- Hybrid root: Films, Series, New & Popular, Genres, Streaming Services,
  Hybrid Settings, Search, Tools. The duplicate Startseite directory was removed.
- Genres and Streaming Services widget tabs are added to the default skin layout.
  Existing customized `addon_data/skin.nebelflix/layout.json` is preserved:
  only missing tab IDs `genres`/`streaming` are appended, with a `.bak` copy.
  No existing tab or widget is rewritten or deleted. If 12 tabs already exist,
  the user must add them manually or make room through the skin widget editor.
- Provider category rows use dynamic TMDb watch-provider listing for Germany.
  Catalogue discovery does NOT guarantee available playable streams or rights.
- Widget catalogues query TMDb via Hybrid; MovieScout and provider scrapers are
  used only when playing an item. No MovieScout modules were modified.
- Install/update Hybrid ZIP first, then Skin ZIP. Restart Kodi once.
- No Kodi 21/iOS device is available in this environment; run on-device tests.
